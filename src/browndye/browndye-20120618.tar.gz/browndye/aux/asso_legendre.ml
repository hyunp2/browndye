(* 
Computes Associated Legendre polynomials.

Used internally.
Computes P_l^m( c) out to l = n, stores as p.(l).(m).
Computes and stores only non-negative m.

See interface file for description of exported function.
*)


let len = Array.length;;

(* floating point factorial *)
let dfactorial i =
  let even = (i mod 2) = 0 in
  let prod = ref 1 in
    for k = 1 to i do
      if even then (
	if((k mod 2) = 0) then
	  prod := !prod * k
      )
      else ( (* odd *)
	if((k mod 2) = 1) then
	  prod := !prod * k	    
      )
    done;
    float !prod
;;

let factorial i = 
  let prod = ref 1 in
    for k = 1 to i do
      prod := !prod * k
    done;
    float !prod
;;

(* powers of -1 *)
let m1pow n = 
  if (n mod 2) = 0 then
    1.0
  else
    -1.0
;;

let tri_array n a = 
  Array.init n (fun i -> Array.init (i+1) (fun k -> a))
;;

let associated_legendre ~n ~c =
  let ps = tri_array n nan in

  let s = sqrt (1.0 -. c*.c) in
  let n = len ps in
  let spows = Array.init n (fun i -> 0.0) in
    spows.(0) <- 1.0;
    for i = 1 to n-1 do
      spows.(i) <- spows.(i-1)*.s;
    done;

    for i = 0 to n-1 do
	ps.(i).(i) <- 
	  (m1pow i)*.(dfactorial (2*i - 1))*.spows.(i);
    done;
    
    for i = 0 to n-2 do
      let fi = float i in
	ps.(i+1).(i) <- c*.(2.0*.fi +. 1.0)*.ps.(i).(i);
    done;
    
    for k = 1 to n-2 do
      for m = 0 to k-1 do
	ps.(k+1).(m) <- 
	  ((float (2*k +1))*.c*.ps.(k).(m) -. (float (k+m))*.ps.(k-1).(m))/.
	  (float (k - m + 1));
      done;
    done;
    ps
;;

(* not currently used
let pi = 3.1415926;;

module C = Complex;;

let spherical_harmonics n theta phi =
  let c = cos theta in
   
  let ps = associated_legendre n c in
  let shs = tri_array n {C.re = nan; C.im = nan;} in
    
    let n = len shs in
      for k = 0 to n-1 do
	for m = 0 to k do
	  let factor = 
	    ps.(k).(m)*.(sqrt ((float (2*k + 1))*.(factorial (k-m))/.
				  ((factorial (k+m))*.4.0*.pi)))
	  in
	  let earg = {
	    C.re = 0.0; 
	    C.im = phi*.(float m);
	  }
	  in
	    shs.(k).(m) <- 
	      C.mul {C.re = factor; C.im = 0.0} (C.exp earg); 

	done;
      done;
      shs
;;
*)


(******************************************************************)
(* Testing Code *)


(*
let shs = spherical_harmonics 4  (pi/.2.0) 0.0;;

for i = 0 to 3 do
  for j = 0 to i do
    let sh = shs.(i).(j) in
      Printf.printf "%d %d %g %g\n" i j sh.C.re sh.C.im 
  done;
done
;;
*)  
  

(*
let ps = Array.init 4
  (fun i ->
    Array.init (i+1) (fun j -> 0.0))
;;

put_p 1.0 ps;;

for i = 0 to 3 do
  for j = 0 to i do
    Printf.printf "%d %d %g\n" i j ps.(i).(j)
  done;
done
;;
*)



