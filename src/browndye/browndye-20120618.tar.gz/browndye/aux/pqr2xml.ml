(* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*)


(* 
Convenience function.

Converts pqr file to xml file (as described in APBS documentation). Receives 
pqr file through standard input and sends xml file to standard output.
*)

let pr = Printf.printf;;

Arg.parse
  []
   (fun arg -> raise (Failure "no anonymous arguments"))
  "Converts pqr file to xml file (as described in APBS documentation). \nReceives pqr file through standard input and sends xml file to standard output."
;;

let buf = Scanf.Scanning.from_channel stdin;;

let test_eof line = 
  if
    (Scanf.sscanf line "%s" (fun s -> String.length s)) > 0 
  then
    raise (Scanf.Scan_failure "incomplete line")
;;
  
let do_nothing () = ();;

type atom = {
  rnum: int;
  rname: string;
  anum: int;
  aname: string;
  charge: float;
  radius: float;
  position: Vec3.t;
}
;;

let atom_from_line line =

  if not (String.length line = 0) then
    let head = 
      let hend = min 6 (String.length line) in
	String.sub line 0 hend
    in
      if not ((head = "REMARK") or (head = "END"))then (
	
	try
	  Scanf.sscanf line "%s %d %s %s %d %f %f %f %f %f"
	    (fun fnam anum anam rnam rnum x y z q r -> 
	      let atom = 
		{
		  aname = anam;
		  anum = anum;
		  rname = rnam;
		  rnum = rnum;
		  charge = q;
		  radius = r;
		  position = Vec3.v3 x y z;
		}
	      in
		Some atom

	    )
	  
	with ex -> (
	  match ex with
	    | Scanf.Scan_failure msg -> (
		
		(* has optional chain id *)
		try
		  Scanf.sscanf line "%s %d %s %s %s %d %f %f %f %f %f"
		    (fun fnam anum anam rnam cid rnum x y z q r ->

		      let atom = 
			{
			  aname = anam;
			  anum = anum;
			  rname = rnam;
			  rnum = rnum;
			  charge = q;
			  radius = r;
			  position = Vec3.v3 x y z;
			}
		      in
			Some atom
			  
		    );
		with ex -> (
		  
		  match ex with
		    | End_of_file -> 
			test_eof line;
			None
		    | _ -> raise ex
		)
	      )
	        
	    | End_of_file -> 
		test_eof line;
		None
		
	    | _ -> raise ex
		
	)
      )
      else
	None
  else
    None
;;



let next_atom buf = 
  let rec loop () = 
    if not (Scanf.Scanning.end_of_input buf) then
      let atom_opt = Scanf.bscanf buf "%s@\n" atom_from_line in
	match atom_opt with
	  | None -> loop ()
	  | Some atom -> Some atom, 0
    else
      None, 0
  in
    loop ()
	
;;

module Atom = 
  struct
    type t = atom
    type container = Scanf.Scanning.scanbuf
    type index = int
    let atom_name atom = atom.aname
    let atom_number atom = atom.anum
    let residue_name atom = atom.rname
    let residue_number atom = atom.rnum
    let position atom = atom.position
    let charge atom = atom.charge
    let radius atom = atom.radius
    let first_index atom = 0
    let next buf index = next_atom buf
	
  end
;;

module Outputter = Output_pqrxml.M( Atom);;

Outputter.f buf stdout;;

