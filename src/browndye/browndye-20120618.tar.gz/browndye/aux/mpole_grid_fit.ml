(* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*)

(*
Called by bd_top.  

This program generates an XML file containing information for a 
screened charge multipole expansion outside of the outermost 
electrostatic grid.  It fits the multipole coefficients to the
grid points on the outer surface of the grid.  (For now, it
uses a Cartesian expansion, but this could be improved.)

It takes the following arguments, with flags:
-xml : read in xml format (dx format otherwise)

-center : center of fitting sphere

-solvdi : solvent dielectric (default value 78)

-vperm : vacuum permitivity (default value assuming units of Angstroms, electron charge, and kT (298 K)

-debye : debye length (default infinity)
   
-error : only compute the fitting error (absolute and relative)

*)


(*************************************************************)
let debye_ref = ref max_float;;
let vperm_ref = ref 0.000142;;
let solvdi_ref = ref 78.0;;
let cx_ref, cy_ref, cz_ref = ref nan, ref nan, ref nan;;

let compute_error_ref = ref false;;
let do_xml_ref = ref false;;

Arg.parse
  [
   ("-xml",
   (Arg.Set do_xml_ref),
   ": read in xml format (dx format otherwise)"
   );

  ("-center",
   (Arg.Tuple [Arg.Set_float cx_ref; Arg.Set_float cy_ref; 
	       Arg.Set_float cz_ref;]),
   ": center of fitting sphere");

    ("-solvdi", Arg.Set_float solvdi_ref, " solvent dielectric (default value 78");

    ("-vperm", Arg.Set_float vperm_ref, " vacuum permitivity (default value assuming units of Angstroms, electron charge, and kT (298 K))");

   ("-debye",
   (Arg.Set_float debye_ref),
   ": debye length (default infinity)"
   );

   ("-error",
   (Arg.Set compute_error_ref),
   ": only compute fitting error"
   );
  ]
  (fun a -> ())
  "Generates a multipole fit from the electrostatic data, By default, reads in dx format file (from APBS)"
;;
  
let do_xml = !do_xml_ref;;
let debye = !debye_ref;;
let vperm = !vperm_ref;;
let solvdi = !solvdi_ref;;
let compute_error = !compute_error_ref;;
let cx,cy,cz = !cx_ref, !cy_ref, !cz_ref;; 


let len = Array.length;;

let min3 a b c = min (min a b) c;;

let some_of item = 
  match item with
    | Some obj -> obj
    | None -> raise (Failure "some_of")
;;

type gen_grid = 
    | Small of float array array array
    | Big of Grid_parser.data3d
;;

type ginfo_type = {
  corner: Vec3.t;
  spacing: float*float*float;
  data: gen_grid;
  ns: int*int*int;
};;

let ginfo = 
  if do_xml then
    let grid = Dgrid_parser.grid Scanf.Scanning.stdib in

    let data = grid.Dgrid_parser.data in
    let nx,ny,nz = len data, len data.(0), len data.(0).(0) in    
      {
	spacing = (let h = grid.Dgrid_parser.spacing in h,h,h);
	data = Small data;
	corner = grid.Dgrid_parser.corner;
	ns = nx,ny,nz;
      }
  else
    let grid = Grid_parser.new_grid Scanf.Scanning.stdib in
    let hx,hy,hz = grid.Grid_parser.h in
    let h = hx, hy, hz in
    let bdata = some_of grid.Grid_parser.data in
    let nx = Bigarray.Array3.dim1 bdata
    and ny = Bigarray.Array3.dim2 bdata
    and nz = Bigarray.Array3.dim3 bdata 
    in
      {
	spacing = h;
	corner = grid.Grid_parser.low;
	data = Big bdata;
	ns = nx,ny,nz;
      }
;;

let potential_opt pos = 
  let x,y,z = pos.Vec3.x, pos.Vec3.y, pos.Vec3.z in
  let lox,loy,loz = (let c = ginfo.corner in c.Vec3.x, c.Vec3.y, c.Vec3.z) in
  let dx,dy,dz = x -. lox, y -. loy, z -. loz in
  let data = ginfo.data in
  let hx,hy,hz = ginfo.spacing in
  let nx,ny,nz = ginfo.ns in
  let ix = int_of_float (dx/.hx)
  and iy = int_of_float (dy/.hy)
  and iz = int_of_float (dz/.hz)
  in
  let lamx = dx/.hx -. (float ix)
  and lamy = dy/.hy -. (float iy)
  and lamz = dz/.hz -. (float iz)
  in
  let inr i n = 
    0 <= i && i < (n-1)
  in
    if not ((inr ix nx) && (inr iy ny) && (inr iz nz)) then (
      None
    )
    else

      let lamcx, lamcy, lamcz = 1.0 -. lamx, 1.0 -. lamy, 1.0 -. lamz 
      in       	
      let g kx ky kz = 
	match data with
	  | Small sdata -> 
	      sdata.(ix+kx).(iy+ky).(iz + kz) 
	  | Big bdata -> 
	      Bigarray.Array3.get bdata (ix+kx) (iy+ky) (iz + kz) 
      in
      let v000 = g 0 0 0
      and v001 = g 0 0 1
      and v010 = g 0 1 0
      and v011 = g 0 1 1
      and v100 = g 1 0 0
      and v101 = g 1 0 1
      and v110 = g 1 1 0
      and v111 = g 1 1 1
      in
      let v00 = lamcz*.v000 +. lamz*.v001
      and v01 = lamcz*.v010 +. lamz*.v011
      and v10 = lamcz*.v100 +. lamz*.v101
      and v11 = lamcz*.v110 +. lamz*.v111
      in
      let v0 = lamcy*.v00 +. lamy*.v01
      and v1 = lamcy*.v10 +. lamy*.v11
      in
	Some (lamcx*.v0 +. lamx*.v1)
;;

let potential pos = 
  match potential_opt pos with
    | None -> raise (Failure "potential: out of range")
    | Some v -> v
;;

let nx,ny,nz = ginfo.ns;;
let hx,hy,hz = ginfo.spacing;;
  let h = max (max hy hy) hz;;
let lox,loy,loz = (let c = ginfo.corner in c.Vec3.x, c.Vec3.y, c.Vec3.z);;

let radius = 
  let hix = lox +. (float (nx-1))*.hx
  and hiy = loy +. (float (ny-1))*.hy
  and hiz = loz +. (float (nz-1))*.hz
  in
  let lx = cx -. lox
  and ly = cy -. loy
  and lz = cz -. loz
  in
  let hx = hix -. cx
  and hy = hiy -. cy
  and hz = hiz -. cz
  in
  let min3 x y z = min (min x y) z in
    0.99*.( min (min3 lx ly lz) (min3 hx hy hz))
;;


let ncoefs = 9;;

(* 1, x, y, z, xx, xy, xz, yy, yz, zz *)
let coefs pos = 
  let x,y,z = pos.Vec3.x -. cx, pos.Vec3.y -. cy, pos.Vec3.z -. cz in
  let r2 = x*.x +. y*.y +. z*.z in
  let r = sqrt r2 in
  let r3 = r2*.r in
  let v = (exp (-.r/.debye))/.r in
  let dvdr = -.v*.(1.0/.r +. 1.0/.debye) in
  let d2vdr2 = 
    v*.(2.0/.(r*.debye) +. 1.0/.(debye*.debye) +. 2.0/.(r*.r))
  in
    
  let drdp p = p/.r in
    
  let d2rdp2 p = 
    1.0/.r -. p*.p/.r3
  in
    
  let dvdp p =
    dvdr*.(drdp p)
  in
    
  let d2vdp2 p = 
    let dr = drdp p in
      d2vdr2*.dr*.dr +. dvdr*.(d2rdp2 p)
  in
    
  let d2rdpdq p q = 
    -.p*.q/.r3
  in
    
  let d2vdpdq p q = 
    d2vdr2*.(drdp p)*.(drdp q) +. dvdr*.(d2rdpdq p q)
  in
    
  let muxc, muyc, muzc = -.(dvdp x), -.(dvdp y), -.(dvdp z) in
  let qxxc, qyyc, qzzc = 
    0.5*.(d2vdp2 x), 0.5*.(d2vdp2 y), 0.5*.(d2vdp2 z) 
  in
  let qxyc, qxzc, qyzc = 
    0.5*.(d2vdpdq x y), 0.5*.(d2vdpdq x z), 0.5*.(d2vdpdq y z)
  in

  let c = Array.init ncoefs (fun i -> 0.0) in
    c.(0) <- v;
    c.(1) <- muxc;
    c.(2) <- muyc;
    c.(3) <- muzc;
    c.(4) <- qxxc -. qzzc;
    c.(5) <- qxyc;
    c.(6) <- qxzc;
    c.(7) <- qyyc -. qzzc;
    c.(8) <- qyzc;
    c
;;


let sphere_points r = 
  let center = Vec3.v3 cx cy cz in
  let order = 4 in
  let sphere = Sphere.made order r center in
    Sphere.icoso_vertices sphere
;;


let points, vs = 
  let lst, vlst = ref [], ref [] in
  let nx,ny,nz = ginfo.ns in
  let dx,dy,dz = ginfo.spacing in
  let lx,ly,lz = 
    let c = ginfo.corner in
      c.Vec3.x, c.Vec3.y, c.Vec3.z
  in
  let hx = lx +. (float nx)*.dx 
  and hy = ly +. (float ny)*.dy 
  and hz = lz +. (float nz)*.dz
  in

  let element ix iy iz = 
    match ginfo.data with
      | Small sdata -> 
	  sdata.(ix).(iy).(iz) 
      | Big bdata -> 
	  Bigarray.Array3.get bdata ix iy iz 
  in

  let put_pt x y z ix iy iz = 
    let pt = Vec3.v3 x y z in
    let v = element ix iy iz in
      lst := pt :: (!lst);
      vlst := v :: (!vlst);
  in

  let put_z_faces z iz = 
    for ix = 0 to nx-1 do
      let x = lx +. dx*.(float ix) in
	for iy = 0 to ny-1 do
	  let y = ly +. dy*.(float iy) in
	    put_pt x y z ix iy iz;
	done;
    done;

  and put_y_faces y iy = 
    for ix = 0 to nx-1 do
      let x = lx +. dx*.(float ix) in
	for iz = 1 to nz-2 do
	  let z = lz +. dz*.(float iz) in
	    put_pt x y z ix iy iz;
	done;
    done;

  and put_x_faces x ix = 
    for iy = 1 to ny-2 do
      let y = ly +. dy*.(float iy) in
	for iz = 1 to nz-2 do
	  let z = lz +. dz*.(float iz) in
	    put_pt x y z ix iy iz;
	done;
    done;
  in
    put_z_faces lz 0;
    put_z_faces hz (nz-1);
    put_y_faces ly 0;
    put_y_faces hy (ny-1);
    put_x_faces lx 0;
    put_x_faces hx (nx-1);

    Array.of_list !lst, Array.of_list !vlst
;;

let max_v = 
  Array.fold_left
    (fun res v -> max res (abs_float v))
    0.0
    vs
;;

let cs = Array.map coefs points;;

let b = 
  Array.init ncoefs
    (fun k ->
      let sum = ref 0.0 in
      let n = len vs in
	for i = 0 to n-1 do
	  sum := !sum +. vs.(i)*.cs.(i).(k)
	done;
	!sum/.(float n)
    )
;;

let array_init2 n f = 
  Array.init n
    (fun i ->
      Array.init n (fun j -> f i j)
    )
;;
	
let mat = 
  array_init2 ncoefs
    (fun j k ->
      let sum = ref 0.0 in
      let n = len vs in
	for i = 0 to n-1 do
	  sum := !sum +. cs.(i).(j)*.cs.(i).(k)
	done;
	!sum/.(float n)
    )
;;

let params = 
  let parray = Least_squares.f cs [| vs |] in
    parray.(0)
;;

let pi = 3.1415926;;

let sq x = x*.x;;

let q = params.(0)
and mx, my, mz = params.(1), params.(2), params.(3) 
and qxx, qyy = params.(4), params.(7)
and qxy, qxz, qyz = params.(5), params.(6), params.(8)
;;
let qzz = -.qxx -. qyy;;

let mpole_potential pt = 
  let c = coefs pt in
  let sum = ref 0.0 in
    for i = 0 to ncoefs-1 do
      sum := !sum +. params.(i)*.c.(i)
    done;
    !sum
;;

let rel_error, abs_error = 
  let vfit = Array.map mpole_potential points in
  let v_diff = ref 0.0 in
  let v_norm = ref 0.0 in
  let n = len points in
  let fn = float n in 
    for i = 0 to n-1 do (
      v_diff := !v_diff +. (sq (vs.(i) -. vfit.(i)));
      v_norm := !v_norm +. (sq vs.(i));
    )
    done;
    let ae = sqrt (!v_diff/.fn) in
    let nrm = sqrt (!v_norm/.fn) in
    let re = ae /. nrm in
      re, ae
;;

let rms_energy = 
  let sum = 
    Array.fold_left
      (fun sum v -> sum +. v*.v)
      0.0
      vs
  in
    sqrt (sum/.(float (len vs)))
;;

let full_potential pos = 
  match potential_opt pos with
    | Some v -> v
    | None -> mpole_potential pos
;;
	
let sphere_variation r = 
  let pts = sphere_points r in
  let n = len pts in
  let vs = Array.map full_potential pts in
  let avg = 
    let sum = Array.fold_left (+.) 0.0 vs in
      sum /. (float n)
  in
    Array.fold_left
      (fun res v -> 
	 let diff = abs_float (v -. avg) in
	   max diff res
      )
      0.0
      vs
;;

let smooth_radius =
  let spv = sphere_variation in

  let tol = 0.01 in
  let rec bisect rout fout rin fin = 
    let rmid = 0.5*.( rout +. rin) in
      if (rout -. rin) < 0.01*.radius then
	rmid
      else
	let fmid = spv rmid in
	  if fmid > tol then
	    bisect rout fout rmid fmid
	  else
	    bisect rmid fmid rin fin

  in
  let rec found_outer r =
    if (spv r) < tol then
      r
    else
      found_outer (2.0*.r)
  in
  let rout = found_outer radius
  in
  let rec found_inner r =  
    if (spv r) > tol or r < 1.0e-20*.radius then
      r
    else
      found_inner (0.5*.r)
  in
  let rin = found_inner radius 
  in
    bisect rout (spv rout) rin (spv rin)
;;


(* ********************************************************** *)
let ptag n tag value =
  for i = 1 to n do
    Printf.printf " "
  done;
  Printf.printf "<%s> %g </%s>\n" tag value tag
;;

let ptago n tag = 
  for i = 1 to n do
    Printf.printf " "
  done;
  Printf.printf "<%s>\n" tag
;;

let ptagc n tag = 
  for i = 1 to n do
    Printf.printf " "
  done;
  Printf.printf "</%s>\n" tag
;;



if compute_error then (
  Printf.printf "Fitting Error: absolute %g relative %g\n" abs_error rel_error;
)
else (
  let factor = (4.0*.pi*.vperm*.solvdi) in
  let f q = factor*.q in

  Printf.printf "<!-- Output of mpole_grid_fit -->\n";
  ptago 0 "multipole_field";

  ptago 2 "center";
  ptag 4 "x" cx;
  ptag 4 "y" cy;
  ptag 4 "z" cz;
  ptagc 2 "center";

  ptag 2 "charge" (f q);

  ptago 2 "dipoles"; 
  ptag 4 "x" (f mx);
  ptag 4 "y" (f my);
  ptag 4 "z" (f mz);
  ptagc 2 "dipoles"; 

  ptago 2 "quadrupoles";
  ptag 4 "xx" (f qxx);
  ptag 4 "xy" (f qxy);
  ptag 4 "xz" (f qxz);
  ptag 4 "yy" (f qyy);
  ptag 4 "yz" (f qyz);
  ptag 4 "zz" (f qzz);
  ptagc 2 "quadrupoles";

  ptag 2 "absolute-error" abs_error;
  ptag 2 "relative-error" rel_error;
  ptag 2  "rms-energy" rms_energy;

  ptag 2 "debye" debye;

  ptag 2 "vacuum-permittivity" vperm;
  ptag 2 "solvent-dielectric" solvdi;
  ptag 2 "fit-radius" radius;
  
  ptag 2 "smooth-radius" smooth_radius;

  ptagc 0 "multipole_field";
)



