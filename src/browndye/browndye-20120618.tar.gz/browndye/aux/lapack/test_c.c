#include <stdio.h>

void get_eigenvectors_c( double* a, long int n, double* evalues);

#define n 4

int main(){
  double a[n*n];
  double w[n];

  printf( "size %d\n", sizeof( double));

  int i,j;
  for (i = 0; i < n; i++)
    for (j = i; j < n; j++){
      int k = n*i + j;
      if (j == i)
	a[k] = 2.0;
      else if (j == i+1)
	a[k] = 1.0;
      else
	a[k] = 0.0;
    }

  get_eigenvectors_c( a, n, w);

  printf( "evalues\n");
  for (i=0; i<n; i++) printf( "%g ", w[i]);
  printf( "\n\n");
  
  for (i=0; i<n; i++){
    for (j=0; j<n; j++) printf( "%g ", a[n*i + j]);
    printf( "\n");
  }

  return 0;
}
