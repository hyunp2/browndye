#include <stdlib.h>
#include "f2c.h"

int dsyev_(char *jobz, char *uplo, integer *n, doublereal *a, 
	   integer *lda, doublereal *w, doublereal *work, integer *lwork, 
	   integer *info);

/* a is stored in fortran order; the lower triangle is used.
   columns of a are replaced by the eigenvectors
*/
void get_eigenvectors_c( double* a, long int n, double* evalues){
  
  char jobz[2];
  jobz[0] = 'V';
  jobz[1] = 0;

  char uplo[2];
  uplo[0] = 'L';
  uplo[1] = 0;

  long int lda = n;

  double work0[1];
  long int lwork = -1;
  long int info;

  dsyev_( jobz, uplo, &n, a, &lda, evalues, work0, &lwork, &info);
  
  lwork = work0[0];
  double* work1 = (double*)malloc( sizeof(double)*lwork);

  dsyev_( jobz, uplo, &n, a, &lda, evalues, work1, &lwork, &info);
  free( work1);
}




