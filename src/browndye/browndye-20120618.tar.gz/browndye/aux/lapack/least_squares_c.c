#include <stdlib.h>
#include <stdio.h>
#include "f2c.h"

int dgels_(char *trans, integer *m, integer *n, integer *nrhs, 
	   doublereal *a, integer *lda, doublereal *b, integer *ldb, 
	   doublereal *work, integer *lwork, integer *info);
  
void least_squares_c( long int m, long int n, long int nrhs, 
		      double* a, double* b){
  
  char trans[2];
  trans[0] = 'N';
  trans[1] = 0;
  long int lda = m;
  long int ldb = m;

  double work0[1];
  long int lwork = -1;
  long int info;


  dgels_( trans, &m, &n, &nrhs, a, &lda, b, &ldb, work0, &lwork, &info);
  if (info != 0)
    exit(0);

  lwork = work0[0];
  double* work1 = (double*)malloc( sizeof(double)*lwork);

  dgels_( trans, &m, &n, &nrhs, a, &lda, b, &ldb, work1, &lwork, &info);
  free( work1);
}
