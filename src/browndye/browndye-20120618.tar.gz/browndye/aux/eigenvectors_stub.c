#include <caml/mlvalues.h>
#include <caml/custom.h>
#include <caml/alloc.h>
#include <caml/memory.h>
#include <caml/callback.h>
#include <caml/fail.h>


void get_eigenvectors_c( double* a, long int n, double* evalues);

void get_eigenvectors( value mat, value evalues){
  CAMLparam2( mat, evalues);

  long int n = Wosize_val( mat);
  double* a = (double*)malloc( sizeof( double)*(n*n));
  double* w = (double*)malloc( sizeof( double)*n);

  int i,j;
  for( i = 0; i < n; i++){
    value row = Field( mat, i);
    for( j = 0; j < n; j++){
      double ele  = Double_field( row, j); 
      int k = i + n*j;
      a[k] = ele;
    }
  }
  
  get_eigenvectors_c( a, n, w);

  for( i = 0; i < n; i++){
    value row = Field( mat, i);
    for( j = 0; j < n; j++){
      int k = n*i + j;
      Store_double_field( row, j, a[k]); 
    }
  }

  for( i = 0; i < n; i++)
    Store_double_field( evalues, i, w[i]);

  free( w);
  free( a);

  CAMLreturn0;
}
