#include <stdio.h>
#include <caml/mlvalues.h>
#include <caml/custom.h>
#include <caml/alloc.h>
#include <caml/memory.h>
#include <caml/callback.h>
#include <caml/fail.h>


void least_squares_c( long int m, long int n, long int nrhs, 
		      double* a, double* b);

void get_least_squares( value mat, value rhss, 
			value dims, value result){
  CAMLparam3( mat, rhss, result);

  long int m = Int_val( Field( dims, 0));
  long int n = Int_val( Field( dims, 1));
  long int nrhs = Int_val( Field( dims, 2));
  
  double* a = (double*)malloc( sizeof( double)*(m*n));
  double* b = (double*)malloc( sizeof( double)*m*nrhs);

  int i,j;
  for( i = 0; i < m; i++){
    value row = Field( mat, i);
    for( j = 0; j < n; j++){
      double ele  = Double_field( row, j);
      int k = i + m*j;
      a[k] = ele;
    }
  }

  for( i = 0; i < nrhs; i++){
    value row = Field( rhss, i);
    for( j = 0; j < m; j++){
      double ele  = Double_field( row, j);
      int k = m*i + j;
      b[k] = ele;
    }
  }

  least_squares_c( m,n,nrhs, a,b);

  for( i = 0; i < nrhs; i++){
    value row = Field( result, i);
    for( j = 0; j < n; j++){
      int k = m*i + j;
      Store_double_field( row, j, b[k]); 
    }
  }

  free( b);
  free( a);

  CAMLreturn0;
}
