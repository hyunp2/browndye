(* Used internally: arguments (a bs) 
Solves the least squares problem
of minimizing (a*x - b)^2 for several vectors in bs; returns the 
corresponding x's.  Uses the LAPACK routine dgels.
*)

external lsq: float array array -> float array array -> (int*int*int)-> float array array -> unit = "get_least_squares"

let len = Array.length;;

let f mat rhss = 
  let nrhs = len rhss in
  let m = len mat in
  let n = len mat.(0) in

    (
      if not ((len rhss.(0)) = m) then
	raise (Failure "least_squares: dims do not match");
      
      if n > m then
	raise (Failure "number of equations is less than unknowns");
    );

  let result = 
    Array.init nrhs
      (fun i ->
	Array.init n
	  (fun j -> nan)
      )
  in
    lsq mat rhss (m,n,nrhs) result;
    result
