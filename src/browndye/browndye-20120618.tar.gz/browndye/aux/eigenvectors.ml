(* Used internally. Computes eigenvectors and eigenvalues of matrix. 
Makes use of CLAPACK routines *)

external get_vecs: float array array -> float array -> unit = "get_eigenvectors"

let f mat = 
  let n = Array.length mat in
  let evecs = 
    Array.init n
      (fun i ->
	Array.init n 
	  (fun j ->
	    mat.(i).(j)
	  )
      )
  in
  let evals = Array.init n (fun i -> nan) in
    get_vecs evecs evals;
    evecs, evals
