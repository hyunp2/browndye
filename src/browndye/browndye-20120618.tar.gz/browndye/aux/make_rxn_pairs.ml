(* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*)


(* 
Not called by bd_top.  Generates a list of reaction-defining pairs
from the structure of the bi-molecular complex and a file of 
complementary atoms (for example, hydrogen-bonding pairs.)  
It searches for contacts with a specified search radius.

It takes the following arguments, with tags:

-mol0 : pqrxml file of Molecule 0
-mol1 : pqrxml file of Molecule 1
-ctypes : file of contact types
-dist : search radius (default 4.5)
  
*)

let len = Array.length;;

let mol0_file_ref = ref "";;
let mol1_file_ref = ref "";;
let ctypes_file_ref = ref "";;
let search_distance_ref = ref 4.5;;

Arg.parse
  [("-mol0", Arg.Set_string mol0_file_ref, "xml file of Molecule 0");
   ("-mol1", Arg.Set_string mol1_file_ref, "xml file of Molecule 1");
   ("-ctypes", Arg.Set_string ctypes_file_ref, "file of contact types");
   ("-dist", Arg.Set_float search_distance_ref, "search radius (default 4.5)");
  ]
  (fun a -> raise (Failure "no anonymous arguments"))
  "outputs file of contact pairs between two molecules"
;;

let mol0_file = !mol0_file_ref;;
let mol1_file = !mol1_file_ref;;
let ctypes_file = !ctypes_file_ref;;
let search_distance = !search_distance_ref;;

type atom = {
  spos: Vec3.t;
  atom_type: string;
  residue_type: string;
  number: int;
};;

let atoms fname =
  let buf = Scanf.Scanning.from_file fname in
  let alist = ref [] in
  let i = ref 1 in
    Atom_parser.apply_to_atoms buf
      (fun ~rname:rname ~rnumber:rnumber ~aname:aname ~anumber:anumber 
	~x:x ~y:y ~z:z ~radius:r ~charge:q ->
	let new_atom = {
	  spos = Vec3.v3 x y z;
	  atom_type = aname;
	  residue_type = rname;
	  number = !i;
	}
	in
	  i := !i + 1;
	  alist := new_atom :: (!alist);
      );
    Array.of_list (List.rev (!alist))
;;

let atoms0 = atoms mol0_file;;
let atoms1 = atoms mol1_file;;


module JP = Jam_xml_ml_pull_parser;;

module Cont = 
  struct
    type t = string*string
    let compare x y = compare x y
  end

module Contact_Set = Set.Make( Cont);;

module H = Hashtbl;;
module NI = Node_info;;

let contacts = 
  let dict = H.create 1 in
  let parser = JP.new_parser (Scanf.Scanning.from_file ctypes_file) in
    JP.complete_current_node parser;
    let cnode = JP.current_node parser in
    let add_pair (c0: string*string) (c1: string*string) = 
      let c1s = 
	if H.mem dict c0 then
	  H.find dict c0 
	else
	  Contact_Set.empty
      in
      let new_c1s = Contact_Set.add c1 c1s in
	H.replace dict c0 new_c1s
    in
      
    let contact_of_node cnode = 
      let a = NI.string_of_child cnode "atom"
      and r = NI.string_of_child cnode "residue" in
	a,r
    in

    let pair_of_node pnode = 
      let cnode0 = NI.checked_child pnode "contact0"
      and cnode1 = NI.checked_child pnode "contact1"
      in
	contact_of_node cnode0, contact_of_node cnode1
    in

    let enode_opt = JP.child cnode "explicit" in
      (match enode_opt with
	| None -> ()
	| Some enode ->
	    let pnodes = JP.children enode "pair" in
	      List.iter
	      (fun pnode ->
		let c0,c1 = pair_of_node pnode in
		  add_pair c0 c1
	      )
		pnodes
      );

      let cmnodes = JP.children cnode "combinations" in
	List.iter
	  (fun cmnode -> 
	    let mnode0 = NI.checked_child cmnode "molecule0"
	    and mnode1 = NI.checked_child cmnode "molecule1"
	    in
	    let cnodes0_l = JP.children mnode0 "contact" 
	    and cnodes1_l = JP.children mnode1 "contact" 
	    in
	    let cnodes0 = Array.of_list cnodes0_l
	    and cnodes1 = Array.of_list cnodes1_l    
	    in
	    let cons0 = Array.map (fun node -> contact_of_node node) cnodes0
	    and cons1 = Array.map (fun node -> contact_of_node node) cnodes1
	    in

	    let n0,n1 = len cons0, len cons1 in
	      for i0 = 0 to n0-1 do
		let c0 = cons0.(i0) in
		  for i1 = 0 to n1-1 do
		    let c1 = cons1.(i1) in
		      add_pair c0 c1
		  done;
	      done
	  )
	  cmnodes;

	dict
;;


module IIS = Is_inside_spheres;;

let stree1 = IIS.search_tree 
  (fun sph -> sph.spos)
  (fun sph -> 0.0)
  atoms1
;;


let aname atom = 
  (atom.atom_type, atom.residue_type)
;;

let atom_pairs = 
  Array.fold_left
    (fun res atom0 ->
      let key0 = aname atom0 in
	if H.mem contacts key0 then
	  let contacts0 = 
	    H.find contacts key0
	  in	  
	  let pairs_opt = 
	    IIS.fold_tree_within_distance
	      (fun atom -> true)
	      atom0.spos
	      search_distance
	      (fun atom1 -> 
		  if Contact_Set.mem (aname atom1) contacts0 then (
		    [(atom0,atom1)]
		  )
		  else
		    []
	      )
	      List.rev_append
	      stree1
	  in
	    match pairs_opt with
	      | None -> res
	      | Some pairs -> List.rev_append pairs res
	else
	  res
    )
    []
    atoms0
;;

let pr = Printf.printf;;

pr "<rxn-pairs>\n";;
List.iter
  (fun pair ->
    let atom0, atom1 = pair in
      pr "  <pair> %d %d </pair>\n" atom0.number atom1.number
  )
  atom_pairs
;;
pr "</rxn-pairs>\n";;
