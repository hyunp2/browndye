(* This is not in the normal Browndye toolchain.  It can be used to 
compute effective charges using a similar method to that of Gabdoulline
and Wade, but using a penalty function to constrain the charge magnitudes
rather than by eliminating eigenvectors. It also fits the gradient of
the field rather than the potential. It takes the following arguments
with flags:

    -test : only compute errors for sites file;
   -debye : debye length (default infinity);
   -vperm : vacuum permittivity (default units of kT, Angstrom, and picosecond);
   -diel : dielectric (default 78);
   -field : dx file of electric potential;
   -sites : pqrxml file of sites;
   -dist : xml file of distances;
   -ins : xml file of insider points;
   -near : near bound on distance of fitting points from surface
   -far : far bound on distance of fitting points from surface
   -nfit : number of fitting points (default 10000);
   -out : output file of charges;
   -pqrxml : output charges as pqrxml file instead of charge xml format;
   -penalty : penalty parameter 
*)

let debye_ref = ref infinity;;
let vperm_ref = ref 0.000142;;
let diel_ref = ref 78.0;;
let field_file_ref = ref "";;
let site_file_ref = ref "";;
let ins_file_ref = ref "";;
let dist_file_ref = ref "";;
let near_ref = ref nan;;
let far_ref = ref nan;;
let bound_ref = ref infinity;;
let target_n_fit_ref = ref 10000;;
let test_only_ref = ref false;;
let out_file_ref = ref "";;
let do_pqrxml_ref = ref false;;
let penalty_ref = ref (-1.0);;

Arg.parse
  [
    ("-test", Arg.Set test_only_ref, "only compute errors for sites file");
   ("-debye", Arg.Set_float debye_ref, "debye length (default infinity)");
   ("-vperm", Arg.Set_float vperm_ref,
   "vacuum permittivity (default units of kT, Angstrom, and picosecond)");
   ("-diel", Arg.Set_float diel_ref, "dielectric (default 78)");
   ("-field", Arg.Set_string field_file_ref, "dx file of electric potential");
   ("-sites", Arg.Set_string site_file_ref, "pqrxml file of sites");
   ("-dist", Arg.Set_string dist_file_ref, "xml file of distances");
   ("-ins", Arg.Set_string ins_file_ref, "xml file of insider points");
   ("-near", Arg.Set_float near_ref, "near bound");
   ("-far", Arg.Set_float far_ref, "far bound");
   ("-bound", Arg.Set_float bound_ref, "bound around test charges (default infinity)");
   ("-nfit", Arg.Set_int target_n_fit_ref, "number of fitting points (default 10000)");
   ("-out", Arg.Set_string out_file_ref, "output file of charges");
   ("-pqrxml", Arg.Set do_pqrxml_ref, "output charges as pqrxml file instead of charge xml format");
   ("-penalty", Arg.Set_float penalty_ref, "penalty parameter; used instead of explicit bounds around the test charges");
  ]
  (fun arg -> raise (Failure "no anonymous arguments"))
  "Outputs effective charge density"
;;

let test_only = !test_only_ref;;
let do_pqrxml = !do_pqrxml_ref;;
let fit_gradient = true;;
let penalty_param = !penalty_ref;;

let target_n_fit = !target_n_fit_ref;;
let target_tol = 0.1;;

let vperm = !vperm_ref;;
let diel = !diel_ref;;
let debye = !debye_ref;;

let field_file = !field_file_ref;;
let site_file = !site_file_ref;;
let ins_file = !ins_file_ref;;
let dist_file = !dist_file_ref;;
let out_file = !out_file_ref;;

let near = !near_ref;;
let far = !far_ref;;
let tcbound = !bound_ref;;

let from_file = Scanf.Scanning.from_file;;
let len = Array.length;;

module IP = Igrid_parser;;
module V = Vec3;;

let igrid, low, (hx,hy,hz) = 
  let info = IP.grid true (from_file ins_file) in
  let corner = 
    let x,y,z = info.IP.corner in
      V.v3 x y z
  in
  let h = info.IP.spacing in
    info.IP.data, corner, (h,h,h)
;;

let dgrid = 
  let info = Dgrid_parser.grid (from_file dist_file) in
    info.Dgrid_parser.data
;;

let nx,ny,nz = len dgrid, len dgrid.(0), len dgrid.(0).(0);;

let high = 
  let xh = (float (nx-1))*.hx +. low.V.x
  and yh = (float (ny-1))*.hy +. low.V.y
  and zh = (float (nz-1))*.hz +. low.V.z
  in
    V.v3 xh yh zh
;;

let indices x y z = 
  let xr,yr,zr = x -. low.V.x, y -. low.V.y, z -. low.V.z in
  let ix = int_of_float (xr/.hx)
  and iy = int_of_float (yr/.hy)
  and iz = int_of_float (zr/.hz) 
  in
    ix,iy,iz
;;

let is_outside x y z = 
  let ix,iy,iz = indices x y z in
  let o000 = igrid.(ix  ).(iy  ).(iz  )
  and o001 = igrid.(ix  ).(iy  ).(iz+1)
  and o010 = igrid.(ix  ).(iy+1).(iz  )
  and o011 = igrid.(ix  ).(iy+1).(iz+1)
  and o100 = igrid.(ix+1).(iy  ).(iz  )
  and o101 = igrid.(ix+1).(iy  ).(iz+1)
  and o110 = igrid.(ix+1).(iy+1).(iz  )
  and o111 = igrid.(ix+1).(iy+1).(iz+1)
  in
  let o00 = o000 + o001
  and o01 = o010 + o011
  and o10 = o100 + o101
  and o11 = o110 + o111
  in
  let o0 = o00 + o01
  and o1 = o10 + o11
  in
  let o = o0 + o1 in
    o = 0
;;


module GP = Grid_parser;;

let pot_grid = 
  let info = GP.new_grid (from_file field_file) in
    match info.GP.data with
      | None -> raise (Failure "no potential grid")
      | Some grid -> grid
;;

let grid_value get pt =
  let x,y,z = pt.V.x, pt.V.y, pt.V.z in
  let xr,yr,zr = x -. low.V.x, y -. low.V.y, z -. low.V.z in
  let ix,iy,iz = indices x y z in

  let x0,y0,z0 = (float ix)*.hx, (float iy)*.hy, (float iz)*.hz in
  let lamx, lamy, lamz = (xr -. x0)/.hx, (yr -. y0)/.hy, (zr -. z0)/.hz in
  let clamx, clamy, clamz = 1.0 -. lamx, 1.0 -. lamy, 1.0 -. lamz in

    if lamz < 0.0 or lamz > 1.0 then
      raise (Failure "not get here");


  let d000 = get (ix  ) (iy  ) (iz  )
  and d001 = get (ix  ) (iy  ) (iz+1)
  and d010 = get (ix  ) (iy+1) (iz  )
  and d011 = get (ix  ) (iy+1) (iz+1)
  and d100 = get (ix+1) (iy  ) (iz  )
  and d101 = get (ix+1) (iy  ) (iz+1)
  and d110 = get (ix+1) (iy+1) (iz  )
  and d111 = get (ix+1) (iy+1) (iz+1)
  in
  let d00z = clamz*.d000 +. lamz*.d001
  and d01z = clamz*.d010 +. lamz*.d011
  and d10z = clamz*.d100 +. lamz*.d101
  and d11z = clamz*.d110 +. lamz*.d111
  in
  let d0y = clamy*.d00z +. lamy*.d01z
  and d1y = clamy*.d10z +. lamy*.d11z
  in
    clamx*.d0y +. lamx*.d1y
;;

let distance = grid_value (fun ix iy iz -> dgrid.(ix).(iy).(iz));;

module BA = Bigarray.Array3;;

let potential = grid_value (fun ix iy iz -> BA.get pot_grid ix iy iz);;


let pot_gradient pt = 
  let x,y,z = pt.V.x, pt.V.y, pt.V.z in

  let get ix iy iz = BA.get pot_grid ix iy iz in

  let rx,ry,rz = x -. low.V.x, y -. low.V.y, z -. low.V.z in
  let ix,iy,iz = indices x y z in

  let vmmm = get (ix  ) (iy  ) (iz  )
  and vmmp = get (ix  ) (iy  ) (iz+1)
  and vmpm = get (ix  ) (iy+1) (iz  )
  and vmpp = get (ix  ) (iy+1) (iz+1)
    
  and vpmm = get (ix+1) (iy  ) (iz  )
  and vpmp = get (ix+1) (iy  ) (iz+1)
  and vppm = get (ix+1) (iy+1) (iz  )
  and vppp = get (ix+1) (iy+1) (iz+1)
  in

  let ax = (rx -. (float ix)*.hx)/.hx
  and ay = (ry -. (float iy)*.hy)/.hy
  and az = (rz -. (float iz)*.hz)/.hz
  in
  let apx = 1.0 -. ax
  and apy = 1.0 -. ay
  and apz = 1.0 -. az
  in
    (* z component  *)
  let gzmm = (vmmp -. vmmm)/.hz
  and gzmp = (vmpp -. vmpm)/.hz
  and gzpm = (vpmp -. vpmm)/.hz
  and gzpp = (vppp -. vppm)/.hz
  in
  let gzm = apy*.gzmm +. ay*.gzmp
  and gzp = apy*.gzpm +. ay*.gzpp
  in
    
  let g2 = apx*.gzm +. ax*.gzp in
    
  (* y component *)
  let gymm = (vmpm -. vmmm)/.hy
  and gymp = (vmpp -. vmmp)/.hy
  and gypm = (vppm -. vpmm)/.hy
  and gypp = (vppp -. vpmp)/.hy
  in
  let gym = apz*.gymm +. az*.gymp
  and gyp = apz*.gypm +. az*.gypp
  in
  let g1 = apx*.gym +. ax*.gyp in
    
  (* x component *)
  let gxmm = (vpmm -. vmmm)/.hx
  and gxmp = (vpmp -. vmmp)/.hx
  and gxpm = (vppm -. vmpm)/.hx
  and gxpp = (vppp -. vmpp)/.hx
  in  
  let gxm = apz*.gxmm +. az*.gxmp 
  and gxp = apz*.gxpm +. az*.gxpp
  in
  let g0 = apy*.gxm +. ay*.gxp in
    V.v3 g0 g1 g2
      
;;

(* points are in fcc lattice,
returns number, list of points;
list is empty if give_pts if false
*)

let test_points give_pts scale = 
  let scale3 = scale ** (1.0/.3.0) in
  let pts = ref [] in

  let sum = ref 0 in
  let shx, shy, shz = scale3*.hx, scale3*.hy, scale3*.hz in
  let xl,yl,zl = low.V.x, low.V.y, low.V.z in
  let xh,yh,zh = high.V.x, high.V.y, high.V.z in
  
  let hhx,hhy,hhz = 0.5*.shx, 0.5*.shy, 0.5*.shz in

  let cinc x y z = 
    if x < xh && y < yh && z < zh then
      if is_outside x y z then
	let pt = V.v3 x y z in
	let r = distance pt in
	  if near <= r && r <= far then ( 
	    sum := !sum + 1;
	    if give_pts then
	      let pt = V.v3 x y z in
	      pts := pt :: (!pts);
	  )
	  
  in

  let x = ref xl in
    while !x < xh do
      let y = ref yl in
	while !y < yh do
	  let z = ref zl in
	    while !z < zh do
	      cinc !x !y !z;
	      cinc (!x +. hhx) (!y +. hhy)  !z;
	      cinc (!x +. hhx)  !y         (!z +. hhz);
	      cinc  !x         (!y +. hhy) (!z +. hhz);
	      z := !z +. shz;
	    done;
	    y := !y +. shy;
	done;
	x := !x +. shx;
    done;
    
    !sum, !pts
;;


let test_points = 
  let rec loop scale = 
    let n,pts = test_points false scale in
    let fn = float n in
    let ftarg = float target_n_fit in
    let diff = fn -. ftarg in
      if (abs_float diff) > target_tol*.ftarg
      then
	let new_scale = fn/.ftarg in
	  loop new_scale
      else
	scale
  in
  let scale = loop 1.0 in
  let n,pts = test_points true scale in
    Array.of_list pts
;;


let pi = 3.1415926;;

let factor = 1.0/.(4.0*.pi*.vperm*.diel);;

let gradient spt tpt =
  let d = V.vdiff tpt spt in
  let r = V.vnorm d in
  let x,y,z = d.V.x, d.V.y, d.V.z in
  let rv = -.factor*.(1.0/.debye +. 1.0/.r)*.(exp (-.r/.debye))/.(r*.r) in
    V.v3 (x*.rv) (y*.rv) (z*.rv)
;;

let greens spt tpt = 
  let d = V.vdiff tpt spt in
  let r = V.vnorm d in
    factor*.(exp (-.r/.debye))/.r
;;

type site_type = {
  pos: V.t;
  q: float;
  radius: float;
  rname: string;
  rnumber: int;
  aname: string;
  anumber: int;

  mutable fit_q: float;
};;

let site_spheres = 
  let lst = ref [] in
  let ftags = ["x"; "y"; "z"; "charge"]
  and itags = ["residue_number"]
  and stags = ["residue"]
  in
    Object_parser.apply_to_objects "point" (from_file site_file) 
      itags ftags stags 
      (fun int_res flt_res str_res ->
	let foundf tag =
	  try
	    List.assoc tag flt_res
	  with Not_found ->
	    raise (Failure ("tag " ^ tag ^ " not found"))
	      
	and foundi tag =
	  try
	    List.assoc tag int_res
	  with Not_found ->
	    raise (Failure ("tag " ^ tag ^ " not found"))
	      
	and founds tag =
	  try
	    List.assoc tag str_res
	  with Not_found ->
	    raise (Failure ("tag " ^ tag ^ " not found"))
	      
	in  
	let x = foundf "x"
	and y = foundf "y"
	and z = foundf "z"
	and rname = founds "residue" 
	and rnumber = foundi "residue_number"
	and q = foundf "charge" 	  
	in
	let site = {
	  pos = V.v3 x y z;
	  q = q;
	  radius = nan;
	  rname = rname;
	  rnumber = rnumber;
	  aname = "";
	  anumber = -1;
	  fit_q = nan;
	}
	in
	  lst := site :: (!lst);
	  
      );
    Array.of_list (List.rev (!lst))
;;

let ns = len site_spheres;;
let nt = len test_points;;

let sites = Array.map (fun sitesp -> sitesp.pos) site_spheres;;
let tcharges = Array.map (fun sitesp -> sitesp.q) site_spheres;;

let dot a b = 
  let sum = ref 0.0 in
    for i = 0 to (len a)-1 do
      sum := !sum +. a.(i)*.b.(i);
    done;
    !sum
;;

let matrix_scale mat = 
  let ns = len mat in
  let trace = 
    let sum = ref 0.0 in 
      for i = 0 to ns-1 do 
	sum := !sum +. mat.(i).(i);
      done;
      !sum
  in
    trace/.(float ns) 
;;

let matrix () =
  if fit_gradient then

    let mat = Array.init ns (fun i -> Array.init ns (fun j -> 0.0)) in
      for i = 0 to ns-1 do
	let sitei = sites.(i) in
	let row = 
	  Array.init nt
	    (fun k ->
	      let test_pt = test_points.(k) in
		gradient sitei test_pt
	    )
	in
	  for j = 0 to i do 
	    let sum = ref 0.0 in
	    let sitej = sites.(j) in
	      for k = 0 to nt-1 do
		let test_pt = test_points.(k) in
		let grad = gradient sitej test_pt in
		  sum := !sum +. (V.dot grad row.(k));
	      done;
	      mat.(i).(j) <- !sum;
	      mat.(j).(i) <- !sum;
	  done;
      done;
      mat
  else

    let mat = Array.init ns (fun i -> Array.init ns (fun j -> 0.0)) in
    let nmat = (ns*ns - ns)/2 + ns in
    let pcount = nmat/100 in
    let imat = ref 0 in
      Printf.printf "Constructing matrix\n"; flush stdout;
      for i = 0 to ns-1 do

	let sitei = sites.(i) in
	let row = 
	  Array.init nt
	    (fun k ->
	      let test_pt = test_points.(k) in
		greens sitei test_pt
	    )
	in
	  for j = 0 to i do

	    if (!imat mod pcount) = 0 then (
	      Printf.fprintf stdout "%3d%% \b\b\b\b\b\b" ((100 * !imat)/nmat); 
	      flush stdout;
	    );
	    imat := !imat + 1;
	    
	    let sum = ref 0.0 in
	    let sitej = sites.(j) in
	      for k = 0 to nt-1 do
		let test_pt = test_points.(k) in
		let v = greens sitej test_pt in
		  sum := !sum +. v*.row.(k);
	      done;
	      mat.(i).(j) <- !sum;
	      mat.(j).(i) <- !sum;
	  done;
      done;
      Printf.fprintf stdout "\n";
      mat

;;

let mat = matrix();;

let penalty = penalty_param*.(matrix_scale mat);;

if penalty_param > 0.0 then (
    for i = 0 to ns-1 do
      mat.(i).(i) <- mat.(i).(i) +. penalty;
    done;
);;


let bvector = 
  if fit_gradient then
    Array.init ns
      (fun i ->
	let site = sites.(i) in
	let sum = ref 0.0 in
	  for k = 0 to nt-1 do
	    let test_pt = test_points.(k) in
	    let fgrad = gradient site test_pt in
	    let rgrad = pot_gradient test_pt in
	      sum := !sum +. (V.dot fgrad rgrad)
	  done;
	  if penalty_param > 0.0 then
	    !sum +. penalty*.tcharges.(i)
	  else
	    !sum

      )
  else
    Array.init ns
      (fun i ->
	let site = sites.(i) in
	let sum = ref 0.0 in
	  for k = 0 to nt-1 do
	    let test_pt = test_points.(k) in
	    let fv = greens site test_pt in
	    let rv = potential test_pt in
	      sum := !sum +. fv*.rv
	  done;
	  if penalty_param > 0.0 then
	    !sum +. penalty*.tcharges.(i)
	  else
	    !sum	      
      )
;;

let qs = 	
  if not test_only then
      if penalty_param < 0.0 then (
	raise (Failure "fit_charges: use of explicit bounds is broken; use penalty parameter instead");
      )
      else
	(* ill-posed system, so do eigenvalue analysis *)
	let evecs, evals = Eigenvectors.f mat in
	let lub = Array.init ns 
	  (fun i ->
	    (dot evecs.(i) bvector)/.evals.(i)
	  )
	in
	  Array.init ns
	    (fun i ->
	      let sum = ref 0.0 in
		for j = 0 to ns-1 do
		  sum := !sum +. evecs.(j).(i)*.lub.(j)
		done;
		!sum
	    )
	   
  else
    tcharges
;;

let gradient_fit qs = 
  let real_norm = 
    let sum = ref 0.0 in
      for i = 0 to nt-1 do
	let grad = pot_gradient test_points.(i) in
	  sum := !sum +. (V.dot grad grad);	
      done;
      sqrt !sum
  in
  let diff_norm = 
    let sum = ref 0.0 in
      for i = 0 to nt-1 do
	let test_pt = test_points.(i) in
	let vsum = V.v3 0.0 0.0 0.0 in
	  for k = 0 to ns-1 do
	    let grad = gradient sites.(k) test_pt in
	    let q = qs.(k) in
	      vsum.V.x <- vsum.V.x +. q*.grad.V.x;
	      vsum.V.y <- vsum.V.y +. q*.grad.V.y;
	      vsum.V.z <- vsum.V.z +. q*.grad.V.z;
	  done;
	  let grad = pot_gradient test_points.(i) in
	  let diff = V.vdiff vsum grad in
	    sum := !sum +. (V.dot diff diff);
      done;
      sqrt !sum

  in
    diff_norm /. real_norm
;;

(* not used any more *)
let potential_fit qs =
  let mval = ref 0.0 in 

  let real_norm = 
    let sum = ref 0.0 in
      for i = 0 to nt-1 do
	let v = potential test_points.(i) in
	  sum := !sum +. v*.v;
	  mval := max !mval (abs_float v); 
      done;
      sqrt !sum
  in

  let max_error = ref 0.0 in
  let diff_norm = 
    let sum = ref 0.0 in
      for i = 0 to nt-1 do
	let test_pt = test_points.(i) in
	let vsum = ref 0.0 in
	  for k = 0 to ns-1 do
	    let v = greens sites.(k) test_pt in
	    let q = qs.(k) in
	      vsum := !vsum +. q*.v;
	  done;
	  let real_v = potential test_points.(i) in
	  let diff = real_v -. !vsum in
	    sum := !sum +. diff*.diff;
	    max_error := max !max_error (abs_float diff);
      done;
      sqrt !sum
  in
    diff_norm /. real_norm, real_norm /. (float nt), !mval, !max_error
;;


let pr = Printf.printf;;

let total_eq = Array.fold_left (+.) 0.0 qs;;

let total_tq = Array.fold_left (fun sum s -> sum +. s.q) 0.0 site_spheres;;

let perror, pnorm, maxv, max_error = potential_fit qs;;

let max_q_dev = 
  let res = ref 0.0 in
    for i = 0 to (len qs)-1 do
      res := max !res (abs_float (qs.(i) -. site_spheres.(i).q))
    done;
    !res
;;

pr "<root>\n";;
pr "  <error> %g </error>\n" perror;;
pr "  <rms-potential> %g </rms-potential>\n" pnorm;;
pr "  <max-potential> %g </max-potential>\n" maxv;;
pr "  <max-error> %g </max-error>\n" max_error;;
pr "  <max-charge-deviation> %g </max-charge-deviation>\n" max_q_dev;

pr "  <solvent>\n";;
pr "    <debye> %g </debye>\n" debye;;
pr "    <vacuum-permittivity> %g </vacuum-permittivity>\n" vperm;;
pr "    <dielectric> %g </dielectric>\n" diel;; 
pr "  </solvent>\n";;

pr "  <input-files>\n";;
pr "    <field> %s </field>\n" field_file;;
pr "    <sites> %s </sites>\n" site_file;;
pr "    <inside-points> %s </inside-points>\n" ins_file;;
pr "    <distances> %s </distances>\n" dist_file;;
pr "  </input-files>\n";;

pr "  <n-fit-points> %d </n-fit-points>\n" target_n_fit;;
pr "  <skin>\n";;
pr "    <near> %g </near>\n" near;
pr "    <far> %g </far>\n" far;
pr "  </skin>\n";;
pr "  <charge-bound> %g </charge-bound>\n" tcbound;;
pr "</root>\n";;


module Atom = 
    struct
      type t = site_type
      type container = site_type array
      type index = int
      let atom_name atom = atom.aname
      let atom_number atom = atom.anumber
      let residue_name atom = atom.rname
      let residue_number atom = atom.rnumber
      let position atom = atom.pos
      let charge atom = atom.fit_q
	
      let radius atom = atom.radius
      let first_index atom = 0
	
      let next atoms i =
	let n = len atoms in
	  if i < n then
	    Some atoms.(i), i+1
	  else
	    None, 0	    		
    end
;;


module Outputter = Output_pqrxml.M( Atom);;

if not test_only then (

  let ostr = if out_file = "" then stdout else open_out out_file in
    
    if do_pqrxml then (
      for i = 0 to ns-1 do
	site_spheres.(i).fit_q <- qs.(i);
      done;      
      Outputter.f site_spheres ostr;
    )
    else (
      let total_charge = Array.fold_left (+.) 0.0 qs in


      let prf = Printf.fprintf in
      prf ostr "<root>\n";
      prf ostr "  <total-charge> %g </total-charge>\n" total_charge;
      for i = 0 to ns-1 do
	let sitesp = site_spheres.(i) in
	let pos = sitesp.pos in
	  prf ostr "  <point>\n";
	  prf ostr "    <residue> %s </residue>\n" sitesp.rname;
	  prf ostr "    <residue_number> %d </residue_number>\n" sitesp.rnumber;
	  prf ostr "    <atom> %s </atom>\n" sitesp.aname;
	  prf ostr "    <atom_number> %d </atom_number>\n" sitesp.anumber;
	  prf ostr "    <x> %g </x> <y> %g </y> <z> %g </z>\n" 
	    pos.V.x pos.V.y pos.V.z;
	  prf ostr "    <charge> %g </charge>\n" qs.(i);
	  prf ostr "    <test_charge> %g </test_charge>\n" sitesp.q;
	  prf ostr "  </point>\n";
      done;
      prf ostr "</root>\n";
    )
)
;;
