let stem path = 
  let n = String.length path in
  let last_slash = 
    let rec loop i spos = 
      if i == n then
        spos
      else
        let new_spos = if path.[i] == '/' then i else spos in
          loop (i+1) new_spos
    in
      loop 0 0
  in
  String.sub path 0 last_slash
;;
        
let dir = Sys.getcwd();;
let libdir = (stem dir)^"/expat_lib";;

Sys.command ("./configure --prefix="^libdir);; 


