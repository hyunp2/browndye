/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/

/*
Various utility functions for extracting information from an
XML node. "Checked" implies that if a value is not found, an
exception is thrown. Those functions with a "tag" argument extract
information from a child node.

*/


#ifndef __NODE_INFO_HH__
#define __NODE_INFO_HH__

#include "jam_xml_pull_parser.hh"
#include "units.hh"

JAM_XML_Pull_Parser::Node* checked_child( JAM_XML_Pull_Parser::Node* node, 
					  const char* tag);

Jam_String::String< char> 
string_from_node( JAM_XML_Pull_Parser::Node* node, const char* tag);

Jam_String::String< char> string_from_node( JAM_XML_Pull_Parser::Node* node);

double double_from_node( JAM_XML_Pull_Parser::Node* node);
double double_from_node( JAM_XML_Pull_Parser::Node* node, const char* tag);

int int_from_node( JAM_XML_Pull_Parser::Node* node);
int int_from_node( JAM_XML_Pull_Parser::Node* node, const char* tag);

template< class Value>
void get_value_from_node( JAM_XML_Pull_Parser::Node* node, 
			  const char* tag, Value& value, bool& found){

  JAM_XML_Pull_Parser::Node* cnode = node->child( tag);  
  if (cnode == NULL)
    found = false;
  else{
    found = true;
    cnode->stream() >> value;
  }
}

#ifdef UNITS

template< class M, class L, class T, class Q, class Value>
void get_value_from_node( JAM_XML_Pull_Parser::Node* node, 
			  const char* tag, Unit< M,L,T,Q,Value>& value,
			  bool& found){
  
  double fvalue;
  get_value_from_node( node, tag, fvalue, found);
  if (found)
    value.value = fvalue;
}

#endif


template< class Value>
void get_value_from_node( JAM_XML_Pull_Parser::Node* node, 
			  const char* tag, Value& value){
  bool found;
  get_value_from_node( node, tag, value, found);
}


template< class Value>
void get_double_from_node( JAM_XML_Pull_Parser::Node* node, 
			   const char* tag, Value& value, bool& found){

  JAM_XML_Pull_Parser::Node* cnode = node->child( tag);  
  if (cnode == NULL)
    found = false;
  else{
    found = true;
    double fval;
    cnode->stream() >> fval;
    set_fvalue( value, fval);
  }
}

template< class Value>
void get_value_from_node( JAM_XML_Pull_Parser::Node* node, 
			  Value& value){
  node->stream() >> value;
}

inline
void get_double_from_node( JAM_XML_Pull_Parser::Node* node, 
			   double& value){
  node->stream() >> value;
}

template< class U>
void get_double_from_node( JAM_XML_Pull_Parser::Node* node, const char* tag, 
			   U& unit){

  double value;
  bool found;
  get_value_from_node( node, tag, value, found);
  if (found)
    set_fvalue( unit, value);
}

template< class U>
void get_checked_double_from_node( JAM_XML_Pull_Parser::Node* node, 
				   const char* tag, U& unit){

  double value;
  bool found;
  get_value_from_node( node, tag, value, found);
  if (found)
    set_fvalue( unit, value);
  else
    error( "tag \"", tag, "\" not found");
}

#endif
