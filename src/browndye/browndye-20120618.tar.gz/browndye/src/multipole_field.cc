/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/

// Implementation. Uses Cartesian formulation out to quadrupole level.

#include <math.h>
#include <fstream>
#include <limits>
#include "multipole_field.hh"
#include "node_info.hh"
#include "multipole_field.hh"

namespace Multipole_Field{
const double pi4 = 4.0*3.1415926;

namespace JP = JAM_XML_Pull_Parser;

EPotential Field::potential( const Vec3< Length>& pos) const{
  const Length x = pos[0] - cx;
  const Length y = pos[1] - cy;
  const Length z = pos[2] - cz;

  const Length2 r2 = x*x + y*y + z*z;
  const Length r = sqrt( r2);
  const Length3 r3 = r*r2;

  const Inv_Length eff_1or = 1.0/r + 1.0/debye;
  const Inv_Length2 eff_1or2 = 1.0/r2 + 1.0/(debye*r) + 1.0/(3.0*debye*debye);
  double expf = exp(-r/debye);

  typedef UQuot< Charge, Length>::Res QOR;

  const QOR vc = q*expf/r;
  const QOR vm = (1.0/r2)*eff_1or*expf*( x*mx + y*my + z*mz);
  const QOR vq = (0.5/r3)*eff_1or2*expf*
    ( qxx*x*x + 2.0*qxy*x*y + 2.0*qxz*x*z + qyy*y*y + 
      2.0*qyz*y*z + qzz*z*z);

  return (vc + vm + vq)/(pi4*vperm*solvdi);
}

void Field::
get_gradient( const Vec3< Length>& pos, 
	      Vec3< EPotential_Gradient>& grad) const{

  const Length x = pos[0] - cx;
  const Length y = pos[1] - cy;
  const Length z = pos[2] - cz;

  const Length2 r2 = x*x + y*y + z*z;
  const Length r = sqrt( r2);
  const Length3 r3 = r*r2;
  const Length4 r4 = r2*r2;
  const Length5 r5 = r*r4;
  const Length6 r6 = r*r5;
  const double expf = exp(-r/debye);

  const Inv_Length dexpf = -expf/debye;
 
  typedef UQuot< Charge, Length2>::Res QOR2;
 
  const QOR2 dceterm = q*(dexpf/r - expf/r2);
  
  const Inv_Length3 mterm = 1.0/r3 + 1.0/(debye*r2);
  const Inv_Length4 dmterm = -3.0/r4 - 2.0/(debye*r3);
  
  const Inv_Length3 meterm = expf*mterm;
  const Inv_Length4 dmeterm = dexpf*mterm + expf*dmterm;

  const Inv_Length5 qterm = 0.5/r5 + 0.5/(debye*r4) + 1.0/(6.0*debye*debye*r3);
  const Inv_Length6 dqterm = -2.5/r6 - 2.0/(debye*r5) - 0.5/(debye*debye*r4);

  const Inv_Length5 qeterm = expf*qterm;
  const Inv_Length6 dqeterm = expf*dqterm + dexpf*qterm;

  const double drdx = x/r;
  const double drdy = y/r;
  const double drdz = z/r;

  const EQuadrupole mv = mx*x + my*y + mz*z;
  const UProd< Length2, EQuadrupole>::Res qv = 
    qxx*x*x + 2.0*qxy*x*y + 2.0*qxz*z*z + qyy*y*y + 2.0*qyz*y*z + 
    qzz*z*z;

  Permittivity factor = pi4*vperm*solvdi;

  grad[0] = (drdx*dceterm + (drdx*dmeterm*mv + meterm*mx) +
    (drdx*dqeterm*qv + 2.0*qeterm*( qxx*x + qxy*y + qxz*z)))/factor;

  grad[1] = (drdy*dceterm + (drdy*dmeterm*mv + meterm*my) +
    (drdy*dqeterm*qv + 2.0*qeterm*( qxy*x + qyy*y + qyz*z)))/factor;

  grad[2] = (drdz*dceterm + (drdz*dmeterm*mv + meterm*mz) +
    (drdz*dqeterm*qv + 2.0*qeterm*( qxz*x + qyz*y + qzz*z)))/factor;
}

inline
JP::Node* child( JP::Node* node, const char* tag){
  JP::Node* cnode = checked_child( node, tag);
  if (cnode == NULL)
    error( "child: no node of ", tag);

  return cnode;
} 

template< class Value>
void get_v3_from_node( JP::Node* node, const char* tag, 
		       Value& x, Value& y, Value& z){

  JP::Node* cnode = child( node, tag);

  JP::Node* xnode = child( cnode, "x");
  JP::Node* ynode = child( cnode, "y");
  JP::Node* znode = child( cnode, "z");
  
  double val;
  xnode->stream() >> val; set_fvalue( x, val);
  ynode->stream() >> val; set_fvalue( y, val);
  znode->stream() >> val; set_fvalue( z, val);
}

void Field::get_m3_from_node( JP::Node* node, const char* tag, 
					   EQuadrupole& xx, EQuadrupole& xy, 
					   EQuadrupole& xz, EQuadrupole& yy, 
					   EQuadrupole& yz, EQuadrupole& zz){
  
  JP::Node* cnode = child( node, tag);

  JP::Node* xxnode = child( cnode, "xx");
  JP::Node* xynode = child( cnode, "xy");
  JP::Node* xznode = child( cnode, "xz");
  JP::Node* yynode = child( cnode, "yy");
  JP::Node* yznode = child( cnode, "yz");
  JP::Node* zznode = child( cnode, "zz");
  
  double val;
  xxnode->stream() >> val; set_fvalue( xx, val);
  xynode->stream() >> val; set_fvalue( xy, val);
  xznode->stream() >> val; set_fvalue( xz, val);
  yynode->stream() >> val; set_fvalue( yy, val);
  yznode->stream() >> val; set_fvalue( yz, val);
  zznode->stream() >> val; set_fvalue( zz, val);
}

Field::Field( const char* file){
  std::ifstream input( file);

  if (!input.is_open())
    error( "file ", file, " could not be opened");

  initialize( input);
}
   
Field::Field( std::ifstream& input){ 
  initialize( input);
}

Field::Field( JP::Parser& parser){
  initialize( parser);
}

void Field::initialize( std::ifstream& input){
  JP::Parser parser( input);
  initialize( parser);
}

void Field::initialize( JP::Parser& parser){

  set_fvalue( cx, NAN);
  set_fvalue( cy, NAN);
  set_fvalue( cz, NAN);

  set_fvalue( q, NAN);
  set_fvalue( mx, NAN);
  set_fvalue( my, NAN);
  set_fvalue( mz, NAN);
  set_fvalue( qxx, NAN);
  set_fvalue( qxy, NAN);
  set_fvalue( qxz, NAN);
  set_fvalue( qyy, NAN);
  set_fvalue( qyz, NAN);
  set_fvalue( qzz, NAN);
  set_fvalue( debye, NAN);
  
  parser.complete_current_node();
  JP::Node* node = parser.current_node();

  double val;
  val = double_from_node( node, "charge");
  set_fvalue( q, val);
  val = double_from_node( node, "debye");
  set_fvalue( debye, val);
  val = double_from_node( node, "vacuum-permittivity");
  set_fvalue( vperm, val);
  solvdi = double_from_node( node, "solvent-dielectric");

  get_v3_from_node( node, "center", cx,cy,cz);
  get_v3_from_node( node, "dipoles", mx,my,mz);
  get_m3_from_node( node, "quadrupoles", qxx,qxy,qxz,qyy,qyz,qzz);
}

}


