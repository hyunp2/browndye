/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/

/*
Defines the classes describing the two molecules.  There is a distinction
made between the "Large" molecule (or Molecule 0) and the "Small" molecule
(or Molecule 1).  Also, the molecules are split further into several
classes, since certain data are duplicated across threads.
The following classes are of note:

Molecule_Common - base class of information held in common by molecule
classes on all threads. One object for the whole simulation.

Small_Molecule_Common - Small Molecule information held in common by all 
threads

Large_Molecule_Common - Large Molecule information held in common by all 
threads

Small_Molecule_Thread - information held separately by each thread. One
object per thread

Molecule_State - base class of information held by each molecule individually.
One per molecule.

Small_Molecule_State - Small Molecule information held by each molecule.
Large_Molecule_State - Large Molecule information held by each molecule.

In general, the "Common" classes contain unchangeable, large things 
like electrostatic and desolvation grids.  The "Thread" classes contain
the data structures used to test for collisions, since they cannot be
shared across threads.  The "State" classes contain state information
such as position, rotation, force, and torque.
 
*/

#ifndef __MOLECULE_HH__
#define __MOLECULE_HH__

#include "molecule_pre.hh"

class Molecule_Pair_Common;
class Molecule_Thread;
class Large_Molecule_State;

typedef UQuot< Energy, Volume>::Res Vol_Potential;

class Molecule_Common{
public:
  typedef Vector< int>::size_type size_type;
  void initialize_super( JAM_XML_Pull_Parser::Node*, Vec3< Length>& offset); 

  Molecule_Common();
  ~Molecule_Common();

  void set_h_radius( const char* file);
  void set_ellipsoids( const char* file);
  void get_hydro_center( Vec3< Length>& c) const;
  bool charge_available() const;
  Charge charge() const;

  Length hydro_radius() const;

  Jam_String::String< char> parameter_file;
  const Near_Interactions::Parameter_Info* pinfo;
  bool soft_radii_from_param_file, hard_radii_from_param_file;

  Ellipsoid hydro_ellipsoid;
  Length h_radius;

  Field::Field< Born_Field_Interface>* born_field;
  double desolve_fudge;
  bool use_68;

  Molecule_Pair_Common* pair; 
};

class Small_Molecule_Common: public Molecule_Common{
public:
  Small_Molecule_Common();
  ~Small_Molecule_Common();
  void initialize( JAM_XML_Pull_Parser::Node*); 
  void set_electric_chebybox( const char* file, const Vec3< Length>& offset);

  Charge charge() const;

  typedef Blob_Interface< Col_Interface_Large, 
			  V_Field_Interface> Q_Blob_Interface;

  typedef Blob_Interface< Col_Interface_Large,
			  Born_Field_Interface> Q2_Blob_Interface;


  Charged_Blob::Blob< 4, Q_Blob_Interface>* q_blob; 
  Charged_Blob::Blob< 4, Q2_Blob_Interface>* q2_blob;
  
};


class Col_Interface_Large;
class Col_Interface_Small;

class Large_Molecule_Common: public Molecule_Common{
public:
  Large_Molecule_Common();
  ~Large_Molecule_Common();
  void set_desolvation_chebybox( const char* file, const Vec3< Length>& offset);
  void set_up_collision_structure();
  void initialize( JAM_XML_Pull_Parser::Node* node, 
		   Molecule_Pair_Common* pair);

  Charge charge() const;
  Atom_Large& atom( size_type i);
  const Atom_Large& atom( size_type i) const;

  typedef Blob_Interface< Col_Interface_Small, 
			  Born_Field_Interface> Q2_Blob_Interface;

  Field::Field< V_Field_Interface>* v_field;
  Vector< Atom_Large> atoms; 
  Collision_Detector::Structure< Col_Interface_Large>* collision_structure;
  Charged_Blob::Blob< 4, Q2_Blob_Interface>* q2_blob;
  Charge total_charge;

  // tether spring
  typedef UQuot< Force, Length>::Res Spring_Constant;
  Spring_Constant ks;
  Length equilib_len;
  const Atom_Large* spring_atom0; 
};

inline
void Molecule_Common::get_hydro_center( Vec3< Length>& c) const{
  Linalg3::copy( hydro_ellipsoid.center, c);
}

inline
Length Molecule_Common::hydro_radius() const{
  return h_radius;
}

class Small_Molecule_Thread{
public:
  typedef Vector< int>::size_type size_type;
  typedef UQuot< Energy, Volume>::Res Vol_Potential;

  Small_Molecule_Thread();
  ~Small_Molecule_Thread();
  void set_up_collision_structure();
  void get_atoms( const char* file);
  void initialize( const Small_Molecule_Common&, JAM_XML_Pull_Parser::Node*);

  Atom_Small& atom( size_type i);
  const Atom_Small& atom( size_type i) const;

  typedef Blob_Interface< Col_Interface_Large,
			  Born_Field_Interface> Q2_Blob_Interface;

  Vector< Atom_Small> atoms;
  Collision_Detector::Structure< Col_Interface_Small>* collision_structure; 
  const Near_Interactions::Parameter_Info* pinfo;

  const Atom_Small* spring_atom1;
};

inline
Atom_Small& Small_Molecule_Thread::atom( Vector< int>::size_type i){
  return atoms[i];
}

inline
const Atom_Small& Small_Molecule_Thread::atom( Vector< int>::size_type i) const{
  return atoms[i];
}

inline
Atom_Large& Large_Molecule_Common::atom( Vector< int>::size_type i){
  return atoms[i];
}

inline
const Atom_Large& Large_Molecule_Common::atom( Vector< int>::size_type i) const{
  return atoms[i];
}

class Molecule_State{
public:
  Molecule_State();

  Vec3< Force> force;
  Vec3< Torque> torque;

  void copy_from_super( const Molecule_State&);

};

class Large_Molecule_State: public Molecule_State{
public:
  void get_rotation( Mat3< double>& rot) const;
  void copy_from( const Large_Molecule_State&);

  typedef Blank_Transform Transform;

  Blank_Transform transform;
};

class Small_Molecule_State: public Molecule_State{
public:
  void get_rotation( Mat3< double>& rot) const;
  void copy_from( const Small_Molecule_State&);

  typedef ::Transform Transform;

  Transform transform;
};

inline
void Small_Molecule_State::get_rotation( Mat3< double>& rot) const{
  transform.get_rotation( rot);
}

inline
void Large_Molecule_State::get_rotation( Mat3< double>& rot) const{
  Linalg3::get_id_mat( rot);
}



inline
void set_position( 
		   Small_Molecule_State& mols, const Vec3< Length>& pos){

  mols.transform.set_translation( pos);
}

inline
void set_position( 
		   Large_Molecule_State& mols, const Vec3< Length>& pos){}

inline
void set_rotation( Small_Molecule_State& mol,
		   const Mat3< double>& rot){

  mol.transform.set_rotation( rot);  
}


inline
void get_position( const Small_Molecule_State& mols, Vec3< Length>& pos){

  mols.transform.get_translation( pos);
}

inline
void get_position( const Large_Molecule_State& mols, Vec3< Length>& pos){

  pos[0] = pos[1] = pos[2] = Length( 0.0);
}

void add_forces_and_torques( 
			    const Large_Molecule_Common& molc0,
			    Large_Molecule_State& mols0,
			    const Small_Molecule_Common& molc1,
			    Small_Molecule_Thread& molt1,
			    Small_Molecule_State& mols1,
			    bool& has_collision);

void compute_forces_and_torques(
				const Large_Molecule_Common& molc0,
				Large_Molecule_State& mols0,
				const Small_Molecule_Common& molc1,
				Small_Molecule_Thread& molt1,
				Small_Molecule_State& mols1,		   
				bool& has_collision,
				Length& violation,
				Atom_Large_Ref&, Atom_Small_Ref&
				);

void compute_forces_and_torques(
				const Large_Molecule_Common& molc0,
				Large_Molecule_State& mols0,
				const Small_Molecule_Common& molc1,
				Small_Molecule_Thread& molt1,
				Small_Molecule_State& mols1,		   
				bool& has_collision
				);

void get_potential_energy( 
			  const Large_Molecule_Common& molc0,
			  const Large_Molecule_State& mols0,
			  const Small_Molecule_Common& molc1,
			  Small_Molecule_Thread& molt1,
			  const Small_Molecule_State& mols1,
			  Energy& near, Energy& coul, Energy& des
			   );


Length molecule_gap( bool is_hydro, 		     
		     const Large_Molecule_Common& molc0,
		     const Large_Molecule_State& mols0,
		     const Small_Molecule_Common& molc1,
		     const Small_Molecule_Thread& molt1,
		     const Small_Molecule_State& mols1		       
		     );


Length hydro_gap( 
		 const Large_Molecule_Common& molc0,
		 const Large_Molecule_State& mols0,
		 const Small_Molecule_Common& molc1,
		 const Small_Molecule_Thread& molt1,
		 const Small_Molecule_State& mols1		 
		 );


#endif
