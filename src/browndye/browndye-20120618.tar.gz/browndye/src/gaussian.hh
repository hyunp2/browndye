/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/


#include <math.h>
#include <stdlib.h>

/*
This class is used to generate gaussian random numbers. It wraps
a uniform random number generator provided by the user.
The Interface class has the following types and functions:
Interface class

// type of seed
typedef seed_type; 

// uniform random number generator
typedef RNG; 

// uniform random number between 0 and 1
double uniform( RNG&);  

void set_seed( seed_type&, RNG&);

void copy_rng_to( const RNG&, RNG&);

*/

template< class Interface>
class Gaussian_Generator{
public:
  typedef typename Interface::RNG RNG;
  typedef typename Interface::seed_type seed_type;
  typedef typename Interface::State State;

  // zero mean, unit variance
  double gaussian();

  // uniform between 0 and 1
  double uniform(){
    return Interface::uniform( rng);
  }

  void set_seed( seed_type& seed){
    Interface::set_seed( rng, seed);
  }

  Gaussian_Generator( typename Interface::RNG& _rng){
    Interface::copy_rng_to( _rng, rng);
    has_next = false;
    owns_rng = false;
  }

  Gaussian_Generator(){
    has_next = false;
    Interface::get_new_rng( rng);
    owns_rng = true;
  }

  Gaussian_Generator( const Gaussian_Generator< Interface>&);
  Gaussian_Generator< Interface>& operator=( const Gaussian_Generator< Interface>&);
  
  ~Gaussian_Generator(){
    if (owns_rng)
      Interface::delete_rng( rng);
  }

  void set_state( const State& state){
    Interface::set_state( rng, state);
  }

  void get_state( State& state) const{
    Interface::get_state( rng, state);
  }

  RNG& base_rng(){
    return rng;
  }

private:
  void copy_from( const Gaussian_Generator< Interface>&);

  static const double pi2 = 6.2832;

  bool has_next;
  mutable bool owns_rng;
  double next_number;
  typename Interface::RNG rng;
};

template< class Interface>
void Gaussian_Generator< Interface>::
copy_from( const Gaussian_Generator< Interface>& gen){

  owns_rng = gen.owns_rng;
  gen.owns_rng = false;

  has_next = gen.has_next;
  next_number = gen.next_number;

  Interface::copy_rng_to( gen.rng, rng);
}

template< class Interface>
Gaussian_Generator< Interface>::
Gaussian_Generator( const Gaussian_Generator< Interface>& gen){
  copy_from( gen);
}

template< class Interface>
Gaussian_Generator< Interface>&
Gaussian_Generator< Interface>::
operator=( const Gaussian_Generator< Interface>& gen){

  if (owns_rng)
    Interface::delete_rng( rng);

  copy_from( gen);
  return *this;
}

template< class Interface>
double Gaussian_Generator< Interface>::gaussian(){

  double res;
  if (has_next){
    // reuse extra number from BM transform.
    has_next = false;
    res = next_number;
  }
  else{
    // use Box-Muller transform
    double u0 = Interface::uniform( rng);
    double u1 = Interface::uniform( rng);
    double lterm = sqrt(-2*log( u0));
    next_number = lterm*sin( pi2*u1);
    has_next = true;
    res = lterm*cos( pi2*u1);
  }
  return res;
}


