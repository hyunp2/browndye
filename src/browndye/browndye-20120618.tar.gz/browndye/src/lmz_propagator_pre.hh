/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/

/*
Various auxilliary classes used by the Propagator class. Included by
"lmz_propagator.hh".
*/

#include "spline.hh"
#include "sarfraz_spline.hh"
#include "browndye_rng.hh"
#include "node_info.hh"
#include "linalg3.hh"
#include "rotations.hh"


namespace LMZ{

namespace L = Linalg3;
namespace JP = JAM_XML_Pull_Parser;


//#######################################################################
class Theta_Distribution{
public:
  void initialize( JP::Node* node, const char* ioro_tag,
		   const Vector< double>& thetas);
  void get_sample( Browndye_RNG& rng, double& theta, Time& time) const;
  void get_sample_old( Browndye_RNG& rng, double& theta, Time& time) const;

private:
  typedef Vector< double>::size_type size_type;

  Sarfraz::Spline< double, double> cml_prob;
  Spline< double, Time> mean_time;
  Spline< double, Time> sdev_time;

  Vector< double> thetas, cml_prob_data;
  Vector< Time> mean_time_data, sdev_time_data;
  double max_theta;
};

//###########################################################################
enum In_Or_Out{In, Out};

class Shell_Distribution{
public:
  void propagate( Browndye_RNG& rng, double theta_in, double phi_in, 
		  double& theta, double& phi,
		  In_Or_Out& in_or_out, Time& t) const;

  void initialize( JP::Node* node);

private:
  typedef Vector< double>::size_type size_type;

  Theta_Distribution inner_dist, outer_dist;
  //Length rin, rb, rout;
  double prob_inner;
  Vector< double> thetas;
};

}
