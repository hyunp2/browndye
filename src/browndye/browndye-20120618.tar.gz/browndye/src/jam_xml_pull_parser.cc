/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/

/*
Top-level parsing classes used in the C++ code.
Implements a parser using the same model as the Ocaml version in
jam_xml_ml_pull_parser.ml. Implements two classes: the Parser and
the Node.  It wraps the Parser_1F class.
*/

#include "jam_xml_pull_parser.hh"

namespace JAM_XML_Pull_Parser{

const char* Node::tag() const{
  return ttag.c_str();
}

const JP::Attrs& Node::attributes() const{
  return attrs;
}

bool Node::is_traversed() const{
  return traversed;
}

JP::Str_Stream& Node::stream() const{
  return *(strm);
}

Node* Node::child( const char* ctag){
  String tag( ctag);
  Miterator itr = children.find( tag);

  if (itr == children.end())
    return NULL;
  else 
    return itr->second.get();
} 

Node* Node::child( const char* tag0, const char* tag1){
  Node* cnode = child( tag0);
  if (cnode == NULL)
    return NULL;
  else
    return cnode->child( tag1);
}

Node* Node::child( const char* tag0, const char* tag1, const char* tag2){
  Node* cnode = child( tag0, tag1);
  if (cnode == NULL)
    return NULL;
  else
    return cnode->child( tag2);
}

Node* Node::child( const char* tag0, const char* tag1, const char* tag2,
		   const char* tag3){
  Node* cnode = child( tag0, tag1, tag2);
  if (cnode == NULL)
    return NULL;
  else
    return cnode->child( tag3);
}

Node* Node::child( const char* tag0, const char* tag1, const char* tag2,
		   const char* tag3, const char* tag4){
  Node* cnode = child( tag0, tag1, tag2, tag3);
  if (cnode == NULL)
    return NULL;
  else
    return cnode->child( tag4);
}

Node* Node::child( const char* tag0, const char* tag1, const char* tag2,
		   const char* tag3, const char* tag4, const char* tag5){
  Node* cnode = child( tag0, tag1, tag2, tag3, tag4);
  if (cnode == NULL)
    return NULL;
  else
    return cnode->child( tag5);
}

Node* Node::child( const char* tag0, const char* tag1, const char* tag2,
		   const char* tag3, const char* tag4, const char* tag5,
		   const char* tag6){
  Node* cnode = child( tag0, tag1, tag2, tag3, tag4, tag5);
  if (cnode == NULL)
    return NULL;
  else
    return cnode->child( tag6);
}

void Node::get_children( const char* ctag, std::list< Node*>& tchildren){
  String tag( ctag);
  std::pair< Miterator, Miterator> rpair = children.equal_range( tag);
  Miterator begin = rpair.first;
  Miterator end = rpair.second;
  for( Miterator itr = begin; itr != end; ++itr){
    tchildren.push_back( itr->second.get());
  }
}

void Node::reset_streams(){
  strm->reset();
  for( Miterator itr = children.begin(); itr != children.end(); ++itr){
    (*itr).second->reset_streams();
  } 
}

// constructors
Node::Node( const Node& node):
  ttag( node.ttag),
  attrs( node.attrs),
  strm( node.strm),
  children( node.children),
  parent( node.parent),
  completed( node.completed),
  merged( node.merged)
{}

Node::Node( const String& _tag, const JP::Attrs& _attrs,
	    Node* _parent):
  ttag(_tag), attrs(_attrs){
  parent = _parent;
  completed = false;
  merged = false;
  traversed = false;
}

/******************************************************************/
bool Parser::done() const{
  return traversal_done;
}

bool Parser::is_current_node_tag( const char* tag) const{
  return (strcmp( tag, current_node()->tag()) == 0);
}

  /*
Node* Parser::completed_node(){
  complete_current_node();
  Node* node = current_node();
  node->merged = true;
  node->traversed = true;

  return node;
}
  */


  /*
const char* Parser::current_tag() const{
  return current_node()->tag();
}
  */

void Parser::skip_current_node(){
  
  size_type nlevel = entries.size();
  Node* node = current_node();

  while( (entries.size() > nlevel) || (current_node() == node))
    next();
}

void Parser::skip_to_parent_end(){
  Node* parent = current_node()->parent;
  do{
    next();
  }
  while (current_node() != parent);
}

  
  /*
Node* Parser::next_of_tag( const char* tag){

  fprintf( stderr, "next of tag %s %s\n", tag, current_node()->tag());

  if (!current_node()->traversed){
    Node *node = next_down_of_tag( tag);
    fprintf( stderr, "ctag %s\n", node->tag()); 
    return node;
  }

  else{
    Node* parent = current_node()->parent;
    size_type nlevel = entries.size();
    bool done = false;
    do{
      next();
      fprintf( stderr, "ctag %s\n", current_node()->tag());
      done = (is_current_node_tag( tag) && (entries.size() == nlevel)) ||
	(current_node() == parent);
    }
    while (!done);
    
    Node* node = current_node();
    if (node == parent)
      return NULL;
    else
      return node;
  }
}
  
  */


  /*
  
Node* Parser::next_down_of_tag( const char* tag){
  Node* parent = current_node();
  size_type nlevel = entries.size();
  bool done = false;
  do{
    next();
    done = (is_current_node_tag( tag) && (entries.size() == nlevel+1)) ||
      (current_node() == parent);
  }
  while (!done);

  Node* node = current_node();
  if (node == parent)
    return NULL;
  else
    return node;
}
 
  */


  /*
JP::Str_Stream& Parser::current_string_stream(){
  complete_current_node();
  //printf( "current node %p %d\n", current_node(), current_node()->completed); 
  return current_node()->stream();
}
  */

void begin_tag( State& state, const char* ctag, const JP::Attrs& attrs){

  String tag( ctag);

  RC_Ptr< Node> node( new Node( tag, attrs, state.node));

  if (state.parser.top_node.get() == NULL)
    state.parser.top_node = node;

  if (state.node != NULL){
    state.node->child_nodes.push( node);
  }
  state.node = node.get();
}

void end_tag( State& state, const char* ctag, JP::Str_Stream& stm){
  state.node->strm.reset( new JP::Str_Stream( stm));
  state.node->completed = true;
  state.node = state.node->parent;
}



Parser::Parser( std::ifstream& _stream): 
  stream( _stream),
  jparser( state, begin_tag, end_tag),
  state( *this)
{
  if (!stream.is_open())
  error( "Parser constructor: stream not open");

  parsing_done = false;
  traversal_done = false;
  jparser.parse_some( stream, parsing_done);

  while (top_node.get() == NULL){
    jparser.parse_some( stream, parsing_done);
  }
}

/*
bool Parser::current_node_traversed() const{
  return current_node()->traversed;
}
*/

void Parser::complete_node( Node* node) const{
  while (!node->child_nodes.empty()){
    RC_Ptr< Node> cnode = node->child_nodes.front();
    std::pair< String, RC_Ptr< Node> > tnpair( cnode->ttag, cnode);
    node->children.insert( tnpair);
    node->child_nodes.pop();
    complete_node( cnode.get());
  }
  node->merged = true;
  node->traversed = true;

}

void Parser::complete_current_node(){
  Node* node = current_node();

  while (!node->completed){
    jparser.parse_some( stream, parsing_done);
  }
  complete_node( node);
}

void Parser::read_node( Node* node){
  while (node->child_nodes.empty() && (!node->completed))
    jparser.parse_some( stream, parsing_done);
}

void Parser::next(){

  if (traversal_done)
    error( "Parser::next: all done");
  
  if (entries.empty()){

    /*
    while (top_node->child_nodes.empty() && (!parsing_done)){
      jparser.parse_some( stream, parsing_done);
    }
    */
    read_node( top_node.get());

    if (top_node->child_nodes.empty()){
      traversal_done = true;
      top_node->completed = true;
    }
    else{
      entries.push( &(top_node->child_nodes));
    }

  }
  else{
    Entry entry = entries.top();
    Node* node = entry->front().get();

    /*
    while (node->child_nodes.empty() && (!node->completed)){
      jparser.parse_some( stream, parsing_done);
    }
    */
    read_node( node);

    if ((!(node->child_nodes.empty())) && (!node->merged)){ // go down
      entries.push( &(node->child_nodes));
      Node* cnode = entries.top()->front().get();
      /*
      while (cnode->child_nodes.empty() && (!cnode->completed)){
	jparser.parse_some( stream, parsing_done);
      } 
      */
      read_node( cnode);
    }
    else{ // go over

      Node* parent = entry->front()->parent;
      entries.top()->pop();

      if (parent->child_nodes.empty()){
	/*
	while( (parent->child_nodes.empty()) &&
	       !(parent->completed) && (!parsing_done)){
	  jparser.parse_some( stream, parsing_done);
	}
	*/
	read_node( parent);
      }

      if (parent->child_nodes.empty()){ // go back up
	entries.pop();
	parent->traversed = true;

	if (entries.empty()){
	  top_node->completed = true;
	  traversal_done = true;
	}
      }
    }
  }
}

void Parser::go_up(){
  if (entries.empty())
    error( "Parser::go_up: already at top");

  Entry entry = entries.top();
  Node* parent = entry->front()->parent;
  parent->child_nodes.pop();
  entries.pop(); 
}

void Parser::find_next_tag( const char* tag){
  do {
    if (traversal_done)
      error( "find_next_tag: ", tag, " not found");
    next();
  }
  while (strcmp( current_node()->tag(), tag) != 0);

}


}

