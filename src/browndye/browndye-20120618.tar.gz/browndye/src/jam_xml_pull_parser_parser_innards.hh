/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/

/*
Private portion of JAM_XML_Pull_Parser::Parser class; included by
"jam_xml_pull_parser.hh"

 */

  friend
  void begin_tag( State& state, const char* ctag, const JP::Attrs& attrs);

  std::ifstream& stream;
  JP::Parser_1F< State> jparser;
  State state;
  bool parsing_done;
  bool traversal_done;
  RC_Ptr< Node> top_node;
  
  typedef std::queue< RC_Ptr< Node> >* Entry;
  std::stack< Entry> entries;
  bool just_completed;

  void complete_node( Node*) const;
  void read_node( Node*);

  typedef std::stack< Entry>::size_type size_type;
