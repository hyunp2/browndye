/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/


#ifndef __JAM_XM_PULL_PARSER_HH__
#define __JAM_XM_PULL_PARSER_HH__

/*
Top-level parsing classes used in the C++ code.
Implements a parser using the same model as the Ocaml version in
jam_xml_ml_pull_parser.ml. Implements two classes: the Parser and
the Node.  It wraps the Parser_1F class.
*/

#include <map>
#include <list>
#include <memory>
#include <queue>
#include "jam_xml_1f_parser.hh"
#include "rc_ptr.hh"

namespace JAM_XML_Pull_Parser{

/*************************************************************/
namespace JP = JAM_XML_Parser;
typedef JP::String String;

class State;
class Parser;

typedef JP::Attrs Attrs;
typedef JP::Str_Stream Str_Stream;

class Node{
public:
  const char* tag() const;
  const Attrs& attributes() const;
  Str_Stream& stream() const;
  bool is_traversed() const;

  Node* child( const char* tag);
  Node* child( const char*, const char*);
  Node* child( const char*, const char*, const char*);
  Node* child( const char*, const char*, const char*, const char*);
  Node* child( const char*, const char*, const char*, const char*, 
	       const char*);
  Node* child( const char*, const char*, const char*, const char*, 
	       const char*, const char*);
  Node* child( const char*, const char*, const char*, const char*, 
	       const char*, const char*, const char*);

  void get_children( const char* tag, std::list< Node*>& children); 

  Node( const String& tag, const JP::Attrs&, Node* parent);
  Node( const Node&);

  void reset_streams();

  /*****************************************************************/

private:
#include "jam_xml_pull_parser_node_innards.hh"
};

#include "jam_xml_pull_parser_state.hh"

/******************************************************/
class Parser{
public:
  Parser( std::ifstream&);

  void next();
  void skip_current_node();
  void skip_to_parent_end();
  bool done() const;
  void go_up();
  
  void complete_current_node();
  bool is_current_node_tag( const char*) const;

  Node* current_node();
  const Node* current_node() const;

  // throws exception if not found
  void find_next_tag( const char*);

  template< class Function>
  void apply_to_nodes_of_tag( const char* tag, Function& f);

private: 
#include "jam_xml_pull_parser_parser_innards.hh"
};

#include "jam_xml_pull_parser_impl.hh"

}

#endif
