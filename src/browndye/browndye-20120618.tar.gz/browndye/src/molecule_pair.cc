/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/

/*
Contains code for molecular movement, initialization, and
implementations of interfaces.

*/

#include "molecule_pair.hh"
#include "step_near_absorbing_sphere.hh"
#include "linalg3.hh"
#include "node_info.hh"
#include "rotations.hh"

namespace L = Linalg3;


//**************************************************************
/*
De-dimensionalizing constants for BD step with HI

R - radius of larger sphere
mu - viscosity
kT

dx - R
dt - mu R^3/kT
F - kT/R
T - kT 
M - 1/R (translational mobility coef)
Mt - 1/R^3 (rotational mobility coef)

*/

const double pi = 3.1415926;
const double pi6 = 6*pi;

// kludge
void get_3x3_inverse( const Mat3< double>& rot, Mat3< double>& inv_rot){
  Transform trans, inv_trans;
  trans.set_rotation( rot);
  trans.get_inverse( inv_trans);
  inv_trans.get_rotation( inv_rot);
} 

//********************************************************************
// Interface for Mover class

class Mover_Interface{
public:
  typedef Molecule_Pair Spheres;

  static
  void put_positions( const Vec3< double>& rsc0, const Vec3< double>& rsc1, 
		      Spheres& spheres){

    const Length R = spheres.common.mol0.hydro_radius();
    Vec3< Length> r0, r1;

    L::get_scaled( R, rsc0, r0);    
    L::get_scaled( R, rsc1, r1);
    Vec3< Length> r;
    L::get_diff( r1, r0, r);

    set_position( spheres.state.mol1, r);
  }

  static
  void put_rotations( const Mat3< double>& rot0, const Mat3< double>& rot1, 
		      Spheres& spheres){

    Mat3< double> inv_rot0, rel_rot;
    get_3x3_inverse( rot0, inv_rot0);
    L::get_mm_prod( inv_rot0, rot1, rel_rot);

    set_rotation( spheres.state.mol1, rel_rot);
  }

  static
  void get_positions( const Spheres& spheres, 
		      Vec3< double>& r0, Vec3< double>& r1){

    const Length R = spheres.common.mol0.hydro_radius();
    Vec3< Length> r;

    r0[0] = r0[1] = r0[2] = 0.0;

    get_position( spheres.state.mol1, r);
    L::get_scaled( 1.0/R, r, r1);
  }
  
  static
  void get_rotations( const Spheres& spheres, 
		      Mat3< double>& rot0, Mat3< double>& rot1){

    L::get_id_mat( rot0);
    spheres.state.mol1.get_rotation( rot1);
  }
  
  static
  void get_forces( const Spheres& spheres,
		   Vec3< double>& f0, Vec3< double>& f1){

    const URecip< Force>::Res factor = 
      spheres.common.mol0.hydro_radius()/spheres.common.kT;

    L::get_scaled( factor, spheres.state.mol0.force, f0);
    L::get_scaled( factor, spheres.state.mol1.force, f1);
  }

  static
  void get_torques( const Spheres& spheres,
		    Vec3< double>& t0, Vec3< double>& t1){

    const URecip< Torque>::Res factor = 1.0/spheres.common.kT;

    L::get_scaled( factor, spheres.state.mol0.torque, t0);
    L::get_scaled( factor, spheres.state.mol1.torque, t1);
  }

  static
  double gap( const Spheres& spheres){

    if (!spheres.common.no_hi){
      const Length R = spheres.common.mol0.hydro_radius();
      
      return hydro_gap( spheres.common.mol0, spheres.state.mol0,  
			spheres.common.mol1, spheres.thread.mol1, spheres.state.mol1)/R;
    }
    else
      return 0.0;
  }
};

//************************************************************
// Interface for function in "step_near_absorbing_sphere.hh"

/*
De-dimensionalizing constants for boundary step

R - outer NAM radius
D - diffusivity
kT

x - R
F - kT/R
dt - R R/D

*/

class Boundary_Step_Interface{
public:
  typedef Browndye_RNG RNG;

  static
  double uniform( RNG& rng){
    return rng.uniform();
  }

  static
  double gaussian( RNG& rng){
    return rng.gaussian();
  }

};

//************************************************************
// part of interface for "pathways.hh"

Length Rxn_Interface::distance( const Molecule_Pair& mpair, 
				size_type i0, size_type i1){

  const Atom_Large& atom0 = mpair.common.mol0.atom( i0);
  Atom_Small& atom1 = mpair.thread.mol1.atom( i1);
  
  Vec3< Length> tpos0, tpos1;

  atom0.get_transformed_position( mpair.state.mol0.transform, tpos0);
  atom1.get_transformed_position( mpair.state.mol1.transform, tpos1);
  atom1.clear_transformed();

  Length result = L::distance( tpos0, tpos1);

  return result;
}

// returns minimum of successor reaction coordinates
Length Molecule_Pair::reaction_coordinate(){
  const Pathways::Pathway< Rxn_Interface>* pathway = common.pathway;

  size_type n = pathway->n_reactions_from( state.current_rxn_state);
  Length coord = Length( INFINITY);
  for( size_type i=0; i<n; i++){
    size_type irxn = pathway->reaction_from( state.current_rxn_state, i);
    Length rc = pathway->reaction_coordinate( *this, irxn);
    coord = min( coord, rc);
  }  

  return coord;
}

//************************************************************
// Following code carries out movement of the molecules, given
// the forces and torques.

void reset_molecule( Small_Molecule_State& state,
		     const Vec3< Length>& pos, 
		     const Mat3< double>& rot,
		     const Vec3< Force>& force, 
		     const Vec3< Torque>& torque){
  
  set_position( state, pos);
  set_rotation( state, rot);
  L::copy( force, state.force);
  L::copy( torque, state.torque);
}

void reset_molecule( Large_Molecule_State& state,
		     const Vec3< Length>& pos, 
		     const Mat3< double>& rot,
		     const Vec3< Force>& force, 
		     const Vec3< Torque>& torque){
  
  L::copy( force, state.force);
  L::copy( torque, state.torque);
}

void save_molecule(const Small_Molecule_State& state,
		   Vec3< Length>& pos, Mat3< double>& rot, 
		   Vec3< Force>& force,  Vec3< Torque>& torque){

  get_position( state, pos); 
  state.get_rotation( rot);
  L::copy( state.force, force);
  L::copy( state.torque, torque);  
}

void save_molecule(const Large_Molecule_State& state,
		    Vec3< Length>& pos,  Mat3< double>& rot,
		    Vec3< Force>& force, Vec3< Torque>& torque){

  pos[0] = pos[1] = pos[2] = Length( 0.0);
  L::get_id_mat( rot);
  L::copy( state.force, force);
  L::copy( state.torque, torque);  
}

double angle_from_succ_rots( const Mat3< double>& rot0, 
			     const Mat3< double>& rot1){
  SVec< double, 4> quat0, quat1;
  mat_to_quat( rot0, quat0);
  mat_to_quat( rot1, quat1);
  SVec< double,4> inv_quat0;
  invert_quat( quat0, inv_quat0);
  SVec< double, 4> dquat;
  multiply_quats( quat1, inv_quat0, dquat);
  return 0.5*acos( dquat[0]);
}

Length Molecule_Pair::minimum_rxn_coord() const{
  Length mc( DBL_MAX);
  
  const Pathways::Pathway< Rxn_Interface>* pathway = 
    common.pathway;
  size_type cur_irxn = state.current_rxn_state;
  size_type nrxns = pathway->n_reactions_from( cur_irxn);
  for( size_type i = 0; i < nrxns; i++){
    size_type irxn = pathway->reaction_from( cur_irxn, i);
    Length coord = pathway->reaction_coordinate( *this, irxn);
    if (coord < mc)
      mc = coord;
  }    
  return mc;
}

const double otol = 1.0/(2*3*3);

Time Molecule_Pair::time_step_guess() const{

  Length min_rxn_coord = minimum_rxn_coord();
  
  state.min_rxn_coord = min( state.min_rxn_coord, min_rxn_coord);

  const Length gap = hydro_gap( common.mol0, state.mol0, 
				common.mol1, thread.mol1, state.mol1);

  const Length r = mol_mol_distance();
  const Length q_radius = common.q_radius;
  const Diffusivity diff = common.diff;

  const Length mid_radius = 0.5*(q_radius + common.b_radius);
  Length outer_gap;
  if (r > mid_radius)
    outer_gap = q_radius - mid_radius;
  else
    outer_gap = q_radius - r;

  Time dto = otol*outer_gap*outer_gap/diff;
  Time dtg = common.gtol*gap*gap/diff;
  Time dtr = sq( min_rxn_coord)*common.rtol/diff;

  Time dtmax = sq(10.0*pi/180.0)/(2.0*common.max_rdiff);

  return min( dtmax, min( max( common.dt_min, min( dtg, dto)),
			  max( common.dtr_min, dtr)));  
}

template< class Molecule_State>
bool Molecule_Pair_Common::
backstep_due_to_force( 
		      const Vec3< Force>& old_force, 
		      const Vec3< Torque>& old_torque, 
		      const Vec3< Length>& old_pos, 
		      const Mat3< double>& old_rot,
		      const Molecule_State& state) const{

  Vec3< Force> new_force;
  Vec3< Torque> new_torque;
  Vec3< Length> new_pos;
  Mat3< double> new_rot;

  save_molecule( state, new_pos, new_rot, new_force, new_torque);
  
  Force df = L::distance( new_force, old_force);
  Length dx = L::distance( new_pos, old_pos);
  if (df*dx/kT > ftol)
    return true;
  else {
    Torque dtq = L::distance( new_torque, old_torque);
    double angle = fabs( angle_from_succ_rots( new_rot, old_rot));
    return (dtq*angle/kT > ftol);
  }
}
			    
// adds to n_steps
// Goes through a complete step as given by Wiener::Process in "wiener.hh"
void Molecule_Pair::do_real_step( unsigned long int& n_steps){

  Wiener::Process< Wiener_Interface>& wprocess = state.wprocess;
  
  bool must_backstep;

  // assume that state is consistent at start of loop
  do {   

    if (wprocess.in_chain())
      while (wprocess.time_step() > state.natural_dt){
	wprocess.backstep();
	state.just_backstepped = true;
      }
    
    ++n_steps;
    must_backstep = false;

    if (state.just_backstepped)
      state.just_backstepped = false;
    else
      wprocess.step_forward( state.natural_dt);
    
    Time dt = wprocess.time_step();
    const Sqrt_Time sqdt = sqrt( 2.0*dt);
    
    SVec< double,12> dw;
    const Sqrt_Time* dwc = wprocess.dW();
    for( unsigned int i=0; i<12; i++)
      dw[i] = dwc[i]/sqdt;
    
    Vec3< Length> pos0, pos1;
    Mat3< double> rot0, rot1;
    Vec3< Force> force0, force1; 
    Vec3< Torque> torque0, torque1;
    Diffusivity old_diff = separation_diffusivity();
    Time old_time;

    old_time = state.time;
    Time old_natural_dt = state.natural_dt;
    save_molecule( state.mol0, pos0, rot0, force0, torque0);
    save_molecule( state.mol1, pos1, rot1, force1, torque1);

    const Length R0 = common.mol0.hydro_radius();
    const Energy kT = common.kT;
    const double dtau = dt*kT/(R0*R0*R0*common.viscosity);
    
    common.mover->move_spheres( dtau, dw, *this);
    state.time += dt;

    bool has_collision;
    
    Atom_Large_Ref aref0;
    Atom_Small_Ref aref1;
    Length violation;
    compute_forces_and_torques( common.mol0, state.mol0, 
				common.mol1, thread.mol1, state.mol1,
				has_collision,
				violation, aref0, aref1
				);

    if (has_collision){
      ++state.n_succ_collisions;
      must_backstep = true;
    }
    else {      
      state.n_succ_collisions = 0;
      state.natural_dt = time_step_guess();
      
      if (state.natural_dt < dt)
	must_backstep = true;	
      
      else if (common.backstep_due_to_force( force0, torque0, 
					     pos0, rot0, state.mol0))
	must_backstep = true;

      else if (common.backstep_due_to_force( force1, torque1, 
					     pos1, rot1, state.mol1))
	must_backstep = true;

      else if (fabs( separation_diffusivity() - old_diff)/old_diff > 
	       common.ftol)
	must_backstep = true;		      
    }
  
    bool at_min = (dt <= common.dt_min);

    const unsigned long int nrejects = 10;

    //must_backstep = false;   
    if (must_backstep){

      // If enough steps in a row are rejected due to collisions,
      // back the molecules away from each other.
      if (has_collision && state.n_succ_collisions > nrejects){
	Vec3< Length> new_pos0, new_pos1;
	get_position( state.mol0, new_pos0);
	get_position( state.mol1, new_pos1);

	Vec3< Length> laxis;
	L::get_diff( new_pos1, new_pos0, laxis);
	Vec3< double> axis;
	L::get_normed( laxis, axis);
	Length new_gap =  violation;
	Length old_distance = L::distance( new_pos0, new_pos1);
	Length new_distance = new_gap + old_distance;
		
	// if needed, keep backing away until no more collision
	bool still_has_collision;
	do {
	  Vec3< Length> corr_pos1;
	  Vec3< Length> diff;
	  L::get_scaled( new_distance, axis, diff);
	  L::get_sum( new_pos0, diff, corr_pos1);
	  set_position( state.mol1, corr_pos1);
	  	  
	  compute_forces_and_torques( common.mol0, state.mol0, 
				      common.mol1, thread.mol1, state.mol1,
				      still_has_collision
				      );
	  
	  if (still_has_collision)
	    new_distance += common.dx_min;	  
	}
	while (still_has_collision);
	state.n_succ_collisions = 0;      	
	state.natural_dt = time_step_guess();
      }

      else if (!at_min){
	wprocess.backstep();
	state.just_backstepped = true;
	reset_molecule( state.mol0, pos0, rot0, force0, torque0);
	reset_molecule( state.mol1, pos1, rot1, force1, torque1);
	state.natural_dt = old_natural_dt;
	state.time = old_time;

      }
      else{
	must_backstep = false;
	if (has_collision){
	  reset_molecule( state.mol0, pos0, rot0, force0, torque0);
	  reset_molecule( state.mol1, pos1, rot1, force1, torque1);
	  state.natural_dt = old_natural_dt;	  
	}

      }      
    }   
  }
  while (must_backstep == true);
}

void Molecule_Pair::get_mol_mol_diff( Vec3< Length>& diff) const{
  Vec3< Length> pos0, pos1;
  get_position( state.mol0, pos0);
  get_position( state.mol1, pos1);
  L::get_diff( pos1, pos0, diff);
}

Length Molecule_Pair::mol_mol_distance() const{
  Vec3< Length> diff;
  get_mol_mol_diff( diff);
  return L::norm( diff);
}

void Molecule_Pair::rescale_separation( double scale){
  Vec3< Length> pos0, pos1;
  Vec3< Length> diff, new_diff;

  get_position( state.mol0, pos0);
  get_position( state.mol1, pos1);
  L::get_diff( pos1, pos0, diff);

  L::get_scaled( scale, diff, new_diff);
  L::get_sum( pos0, new_diff, pos1);

  
  set_position( state.mol1, pos1);
  
  bool has_collision;
  compute_forces_and_torques( common.mol0, state.mol0,  
			      common.mol1, thread.mol1, state.mol1,  
			      has_collision);
  if (has_collision){
    printf( "separation: diff %g new_diff %g\n", fvalue( L::norm( diff)), 
	    fvalue( L::norm( new_diff)));
    error( "Molecule_Pair::do_step: should not have collision here");

  }
}

bool Molecule_Pair::has_collision( const Mat3< double>& rot, 
				   const Vec3< Length>& trans){
  
  set_position( state.mol1, trans);
  set_rotation( state.mol1, rot);
  
  bool has_collision;
  compute_forces_and_torques( common.mol0, state.mol0, 
			      common.mol1, thread.mol1,
			      state.mol1, has_collision);
  return has_collision;
}

void Molecule_Pair::outer_propagate( Molecule_Pair_Fate& fate){

  Vec3< Length> r0b, r1b;
  Vec3< Length> r1;
  Time time;
  Mat3< double> rot0b, rot1b;
  Mat3< double> rot0, rot1;
  bool escaped;
  
  Large_Molecule_State& state0 = state.mol0;
  Small_Molecule_State& state1 = state.mol1;

  state0.get_rotation( rot0b);
  state1.get_rotation( rot1b);

  get_position( state0, r0b);
  get_position( state1, r1b);

  common.outer_propagator.propagate( thread.rng, r0b, rot0b, r1b, rot1b,
				     escaped, rot0, r1, rot1, time);
    
  if (escaped){
    fate = Escaped;
  }
  else{
    state.time += time;
    Mat3< double> inv_rot0, rel_rot;
    get_3x3_inverse( rot0, inv_rot0);

    L::get_mm_prod( inv_rot0, rot1, rel_rot);
    Vec3< Length> rel_r;
    L::get_mv_prod( inv_rot0, r1, rel_r);

    set_position( state1, rel_r);
    set_rotation( state1, rel_rot);
    fate = In_Action;

    bool collision;
    compute_forces_and_torques( common.mol0, state.mol0, 
				common.mol1, thread.mol1, state.mol1,
				collision					
				);
    if (collision)
      error( "outer_propagate: should not have collision");    
  } 
}

Diffusivity Molecule_Pair::separation_diffusivity() const{
  const Length r = mol_mol_distance();
  if (r != r)
    error( "Molecule_Pair::do_step: NaN encountered");

  const Length R = common.mol0.hydro_radius();
  return common.mover->separation_mobility( r/R)*common.kT/(R*common.viscosity);
}

// Does a complete step as defined in "wiener.hh", and also takes
// care of propagation beyond the b-sphere.
// assumes that molecules have force and torque already computed
// but ensures that molecule has new force and torque upon completion
// enhanced LMZ
// Adds number of substeps to n_steps
void Molecule_Pair::do_step( Molecule_Pair_Fate& fate, 
			     unsigned long int& n_steps){

  if (state.had_reaction){
    state.min_rxn_coord = Length( INFINITY);
    state.had_reaction = false;
  }

  fate = In_Action;

  const Length r = mol_mol_distance();
  if (r != r)
    error( "Molecule_Pair::do_step: NaN encountered");
  
  const Diffusivity Dr = separation_diffusivity();

  Length q_radius = common.q_radius;

  if (common.building_bins){
    do_real_step( n_steps);
    
    const Length new_r = mol_mol_distance();
    if ((new_r > q_radius) && common.building_bins){
      rescale_separation( q_radius/new_r);
    }    
  }

  else{ //not building bins for weighted-ensemble simulation
    const Time dt = state.natural_dt;

    const Length mid_radius = 0.5*( q_radius + common.b_radius);

    if (mid_radius < r && r < q_radius){ // simplify
      Vec3< Length> diff;
      get_mol_mol_diff( diff);
      
      const Force Fr0 = L::dot( state.mol1.force, diff)/r;
      const double old_rs = r/q_radius;  // old r scaled
      const double Fr = Fr0*q_radius/common.kT;
      const double t = dt*Dr/(q_radius*q_radius);
      double new_rs; // new r scaled
      bool survives;
      typedef Boundary_Step_Interface BSI;
      step_near_absorbing_sphere< BSI>( thread.rng, old_rs, Fr, t, 
					survives, new_rs); 
      if (survives){
	rescale_separation( new_rs/old_rs);
	state.time = state.time + q_radius*q_radius*t/Dr;
      }
      else {
	outer_propagate( fate);      
      }
    }
   
    // not near q-boundary; r < mid_radius // q_radius - r >= 3*mean_dr
    else{  
      do_real_step( n_steps);
 
      Length r = mol_mol_distance();
      if (r > q_radius){
	// small chance, but can happen
	outer_propagate( fate);      
      }
      else{
	size_type next_rxn;
	bool completed = false;
	const Pathways::Pathway< Rxn_Interface>* pathway = common.pathway;

	pathway->get_next_completed_reaction( state.current_rxn_state, *this,
					      completed, next_rxn);

	if (completed && (!common.building_bins)){
	  state.current_rxn_state = pathway->state_after_reaction( next_rxn);
	  state.last_rxn = next_rxn;
	  state.had_reaction = true;
	  if (pathway->n_reactions_from( state.current_rxn_state) == 0){
	    fate = Final_Rxn;
	  }
	  else
	    fate = In_Action;
	}
	else 
	  fate = In_Action;      
      }
    }
  }
  ++state.n_steps;  
}
  
//************************************************************
// constructor
Molecule_Pair_Common::Molecule_Pair_Common(){
  b_radius = Length( NAN);
  q_radius = Length( NAN);
  dt_min = Time( NAN);
  dtr_min = Time( NAN);
  kT = Energy( 1.0);
  water_viscosity = Viscosity( 0.243); // units of kT ps / A^3
  relative_viscosity = 1.0;
  viscosity = water_viscosity;
  debye_length = Length( NAN);
  vacuum_permittivity = Permittivity( 0.000142);
  dielectric = 78.0;

  mover = NULL;
  pathway = NULL;
  building_bins = false;
  ftol = 0.02;
  gtol = 0.05; // 1.0/(2*3*3);
  rtol = 1.0/(2*10*10);
  
  dx_min = Length( 1.0);
  dxr_min = Length( 1.0);
  diff = Diffusivity( NAN);
  max_rdiff = Inv_Time( NAN);
  start_at_site = false;

  no_hi = false;
}

// constructor
Molecule_Pair_State::Molecule_Pair_State(){
  current_rxn_state = std::numeric_limits< size_type>::max();
  last_rxn = std::numeric_limits< size_type>::max();
  had_reaction = false;
  escaped = false;
  wprocess.set_gaussian_generator( NULL);
  just_backstepped = false;
  natural_dt = Time( NAN);
  n_steps = 0;
  n_succ_collisions = 0;
  weight = NAN;
  min_rxn_coord = Length( INFINITY);
  time = Time( 0.0);
}

// destructor
Molecule_Pair_Common::~Molecule_Pair_Common(){
  if (mover != NULL)
    delete mover;
  if (pathway != NULL)
    delete pathway;
}


//************************************************************
// Initialization code

namespace JP = JAM_XML_Pull_Parser;
typedef Jam_String::String< char> String;

void Molecule_Pair_Thread::initialize( Molecule_Pair_Common& common,
				       JAM_XML_Pull_Parser::Node* node){
 

  pthread_mutex_lock( &common.mutex);
  node->reset_streams();

  printf( "molecule pair thread initialize\n"); fflush( stdout);
  
  JP::Node* mol1_node = checked_child( node, "molecule1");
  mol1.initialize( common.mol1, mol1_node); 

  printf( "end molecule pair thread initialize\n"); fflush( stdout);
  pthread_mutex_unlock( &common.mutex);
}

const double pi8 = pi*8;

template< class T>
inline
typename UProd< typename UProd< T, T>::Res, T>::Res
cube( T x){
  return x*x*x;
}

// assume node is completed
void Molecule_Pair_Common::initialize( JP::Node* node, 
				       const char* solvent_file){
  
  pthread_mutex_init( &mutex, NULL);

  if (solvent_file != NULL){
    std::ifstream sinput( solvent_file);
    
    JP::Parser parser( sinput);
    parser.complete_current_node();
    JP::Node* snode = parser.current_node();

    get_double_from_node( snode, "relative-viscosity", 
			 relative_viscosity);
    get_double_from_node( snode, "water-viscosity", 
			 water_viscosity);
    viscosity = relative_viscosity*water_viscosity;

    get_double_from_node( snode, "kT", kT);
    get_double_from_node( snode, "debye-length", debye_length);
    get_double_from_node( snode, "dielectric", dielectric);
    get_double_from_node( snode, "vacuum-permittivity", vacuum_permittivity);
  }

  printf(  "initialize molecule 0\n");
  JP::Node* mol0_node = checked_child( node, "molecule0");
  mol0.initialize( mol0_node, this);

  printf(  "initialize molecule 1\n");
  JP::Node* mol1_node = checked_child( node, "molecule1");
  mol1.initialize( mol1_node);

  printf(  "get reaction-file\n");
  String rxn_file = string_from_node( node, "reaction-file");
  pathway = new Pathways::Pathway< Rxn_Interface>;
  pathway->initialize( rxn_file.c_str());
  
  printf(  "get HI-file\n");
  String hydro_file;
  get_value_from_node( node, "HI-file", hydro_file);
  mover = new Two_Sphere_Brownian::Mover< Mover_Interface>;
  mover->set_radius( mol1.hydro_radius()/mol0.hydro_radius());
  if (hydro_file.has_value())
    mover->read_mobility_info( hydro_file.c_str());

  printf( "get BD propagation file\n");
  String lmz_file = string_from_node( node, "BD-propagation-file");
  {
    std::ifstream input( lmz_file.c_str());
    JP::Parser parser( input);
    parser.complete_current_node();
    outer_propagator.initialize( parser.current_node());
  }

  printf ("get radii\n");
  b_radius = Length( double_from_node( node, "b-radius"));
  q_radius = qb_factor*b_radius;


  printf(  "get dt data\n");

  JP::Node* tnode = node->child( "time-step-tolerances");
  if (tnode != NULL){
    bool found;
    get_double_from_node( tnode, "force", ftol, found);
    get_double_from_node( tnode, "reaction", rtol, found);
    get_double_from_node( tnode, "collision", gtol, found);
    get_double_from_node( tnode, "minimum-dx", dx_min, found);
    dxr_min = dx_min;
    get_double_from_node( tnode, "minimum-reaction-dx", dxr_min, found);
  }

  {
    Diffusivity diff0 = kT/(pi6*viscosity*mol0.hydro_radius());
    Diffusivity diff1 = kT/(pi6*viscosity*mol1.hydro_radius());
    diff = diff0 + diff1;
    dt_min = dx_min*dx_min/(2.0*diff);  
    dtr_min = dxr_min*dxr_min/(2.0*diff);
  }
  {
    Inv_Time rdiff0 = kT/(pi8*viscosity*cube( mol0.hydro_radius()));
    Inv_Time rdiff1 = kT/(pi8*viscosity*cube( mol1.hydro_radius()));
    max_rdiff = max( rdiff0, rdiff1); 
  }


  JP::Node* stnode = node->child( "start-at-site");
  if (stnode != NULL){
    String res = string_from_node( stnode);
    if (res == String( "true") || res == String( "True") || 
	res == String( "TRUE")){
      
      start_at_site = true;
      const Vec3< Length>& pos0 = mol0.hydro_ellipsoid.center;
      const Vec3< Length>& pos1 = mol1.hydro_ellipsoid.center;
      L::get_diff( pos1, pos0, starting_site_offset);
    }
  }

  JP::Node* nhnode = node->child( "hydrodynamic-interactions");
  if (nhnode != NULL){
    String res = string_from_node( nhnode);
    
    if (res == String( "false") || res == String( "False") || 
	res == String( "FALSE")){
      mover->set_no_hi();
      no_hi = true;
    }    
  }

  JP::Node* dnode = node->child( "desolvation-parameter");
  if (dnode != NULL){
    double fudge = double_from_node( dnode);
    mol0.desolve_fudge = fudge;
    mol1.desolve_fudge = fudge;
  }

  JP::Node* node68 = node->child( "use-6-8-force");
  if (node68 != NULL){
    String res = string_from_node( node68);
    if (res == String( "true") || res == String( "True") || 
	res == String( "TRUE")){      
      mol0.use_68 = true;
      mol1.use_68 = true;
    }
  }
}

// puts mol 0 in its orginal spot, and mol 1 relative to it
void Molecule_Pair::set_initial_state( Length radius){

  Vec3< Length> pos1;
  Mat3< double> rot1;
  Browndye_RNG& rng = thread.rng;

  if (common.start_at_site){
    state.mol0.transform.set_zero();
    state.mol1.transform.set_zero(); 
    state.mol1.transform.set_translation( common.starting_site_offset);    
  }
  else{

    Vec3< double> udisp;
    get_random_unit_vector( rng, udisp);
    L::get_scaled( radius, udisp, pos1);
    
    get_random_rotation( rng, rot1);
    
    set_position( state.mol1, pos1);
    set_rotation( state.mol1, rot1);
  }
    
  bool has_collision;
  compute_forces_and_torques( common.mol0, state.mol0,
			      common.mol1, thread.mol1, state.mol1,
			      has_collision);
  if (has_collision)
    error( "Molecule_Pair::set_initial_state: collision");
  
  state.current_rxn_state = common.pathway->first_state();
  state.natural_dt = time_step_guess();
  state.n_steps = 0;
  state.min_rxn_coord = Length( INFINITY);
  state.had_reaction = false;
  state.time = Time( 0.0);
}

void Molecule_Pair::set_initial_state(){
  set_initial_state( common.b_radius);
}

void Molecule_Pair::set_initial_state_for_bb(){
  set_initial_state( qb_factor*common.b_radius);
}

Molecule_Pair_Common::size_type 
Molecule_Pair_Common::n_reactions() const{
  return pathway->n_reactions();
}

Molecule_Pair_Common::size_type 
Molecule_Pair_State::current_reaction_state() const{
  return current_rxn_state;
}

void Molecule_Pair_State::copy_from( const Molecule_Pair_State& state){
  current_rxn_state = state.current_rxn_state;
  last_rxn = state.last_rxn;
  had_reaction = state.had_reaction;
  escaped = state.escaped;
  wprocess = state.wprocess;
  mol0.copy_from( state.mol0);
  mol1.copy_from( state.mol1);
}
