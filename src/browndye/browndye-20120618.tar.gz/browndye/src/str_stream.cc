#include "str_stream.hh"

// Implements input stream for XML node contents.

namespace JAM_XML_Parser{

  Str_Stream::Str_Stream( const XML_Parser& _parser, 
			  const char* _tag, const char* str): 
    parser(_parser), tag( _tag), sdata( str){
    if (strlen( str) > 0)
      super = new Super( str);
    else
      super = NULL;
    is_reset = true;
  }
  
  // new copy is reset
  Str_Stream::Str_Stream( const Str_Stream& stm): 
    parser( stm.parser), tag( stm.tag), sdata( stm.sdata){
    if (sdata.has_value())
      super = new Super( stm.sdata.c_str());
    else
      super = NULL;
    is_reset = true;
  }

  Str_Stream& Str_Stream::operator>>( Str& str){
    is_reset = false;

    if (super != NULL){
      //std::stringstream ss; need to fix potential danger      
      char data[100];      
      (*super) >> data;
      str.copy_from( data);     
    }    

    return *this;
  }

  void Str_Stream::reset(){
    if (!is_reset){
      delete super;
      if (sdata.has_value())
	super = new Super( sdata.c_str());
      else
	super = NULL;
      is_reset = true;
    }
  }
}
