/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/


#ifndef __MOLECULE_PAIR_HH__
#define __MOLECULE_PAIR_HH__

/*
The Molecule_Pair classes contain the functions that carry out
the Brownian dynamics moves of the molecule pair.

The following classes are defined:

Molecule_Pair_Common - contains commmon data; one copy
for the whole simulation

Molecular_Pair_Thread - contains data that is specific to
different threads; one copy per thread

Molecule_Pair_State - contains data for a particular copy of
the bimolecular system; one copy per system copy.

Molecule_Pair - lightweight object temporarily created whenever
the system is stepped forward in time.


 */

#include "molecule_pair_pre.hh"


class Molecule_Pair_Common;
class Molecule_Pair_Thread;
class Molecule_Pair_State;
enum Molecule_Pair_Fate {In_Action, Escaped, Final_Rxn, Stuck};

class Mover_Interface;

class Molecule_Pair_Common{
public:
  typedef Vector< int>::size_type size_type;

  Viscosity water_viscosity, viscosity; 
  double relative_viscosity; 
  Energy kT; 
  Length debye_length;
  double dielectric;
  Permittivity vacuum_permittivity;


  Length b_radius, q_radius;  
  bool building_bins;  

  // assume mol0 radius > mol1 radius
  Large_Molecule_Common mol0;
  Small_Molecule_Common mol1;

  Molecule_Pair_Common();
  ~Molecule_Pair_Common();

  void initialize( JAM_XML_Pull_Parser::Node* node, const char* solvent_file);

  template< class Molecule_State>
  bool backstep_due_to_force(const Vec3< Force>&, const Vec3< Torque>&, 
			     const Vec3< Length>&, const Mat3< double>&, 
			     const Molecule_State&) const;

  size_type n_reactions() const;

  Time maximum_dt() const;
  Time minimum_dt() const;

  Time dt_min, dtr_min; 

  Two_Sphere_Brownian::Mover< Mover_Interface>* mover; 
  Pathways::Pathway< Rxn_Interface>* pathway; 
  LMZ::Propagator outer_propagator; 

  pthread_mutex_t mutex;
  double ftol, gtol, rtol;
  Length dx_min, dxr_min;

  Diffusivity diff;
  Inv_Time max_rdiff;

  // starting place of Molecule 1 relative to 0
  bool start_at_site;
  Vec3< Length> starting_site_offset;

  bool no_hi;
};

const double qb_factor = 1.1;

class Molecule_Pair_Thread{
public:
  void initialize( Molecule_Pair_Common& common,
		   JAM_XML_Pull_Parser::Node* node
		   );

  Small_Molecule_Thread mol1;
  unsigned int n;
  Browndye_RNG rng; 
};

class Molecule_Pair_State{
public:
  typedef Vector< Atom_Small>::size_type size_type;

  Molecule_Pair_State();
  size_type current_reaction_state() const;
  // puts molecule 0 at origin
  void copy_from( const Molecule_Pair_State&);

  Large_Molecule_State mol0;
  Small_Molecule_State mol1;

  Wiener::Process< Wiener_Interface> wprocess; 
  size_type current_rxn_state; 
  size_type last_rxn; 
  bool had_reaction;
  bool escaped;
  Time natural_dt;
  bool just_backstepped;
  unsigned long int n_steps;
  unsigned long int n_succ_collisions;
  
  double weight;
  Length min_rxn_coord;
  Time time;
};

class Molecule_Pair{
public:


  Molecule_Pair( Molecule_Pair_Common& _common, Molecule_Pair_Thread& _thread,
		 Molecule_Pair_State& _state):
    common(_common), thread(_thread), state(_state){

    number = std::numeric_limits< unsigned int>::max();
    state.wprocess.set_gaussian_generator( &(_thread.rng));
  }

  void set_initial_state();
  void do_step( Molecule_Pair_Fate& fate, unsigned long int&);
  void set_initial_state_for_bb();
  Length reaction_coordinate();

  Molecule_Pair_Common& common;
  Molecule_Pair_Thread& thread;
  Molecule_Pair_State& state;
  unsigned int number;

private:

  void do_real_step( unsigned long int&);
  void rescale_separation( double scale);
  void outer_propagate( Molecule_Pair_Fate& fate);
  void set_initial_state( Length radius);
  void get_mol_mol_diff( Vec3< Length>& diff) const;
  Length mol_mol_distance() const;
  Length minimum_rxn_coord() const;
  Diffusivity separation_diffusivity() const;
  Time time_step_guess() const;
  bool has_collision( const Mat3< double>& rot, const Vec3< Length>& trans);

  typedef Vector< int>::size_type size_type;
};


inline
Time Molecule_Pair_Common::minimum_dt() const{
  return dt_min;
}

/* 
Input:

files for both molecules

b radius

Time step size parameters
  inner distance
  inner value
  outer distance
  outer value

file for reaction criteria
file for HI interactions

viscosity
kT

*/
 

#endif
