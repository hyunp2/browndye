#ifndef __MERSENNE_HH__
#define __MERSENNE_HH__
// See mersenne.cc for copyright

/*
Modification of Mersenne Twister random number generator, from C to C++.
This is the core of the random number generator used in Browndye.
 */

#include <stdint.h>
#include "vector.hh"

namespace Mersenne{

  struct State{
    Vector< uint32_t> mt;
    int mti;
  };

class Generator{
public:

  Generator(){
    mti = N+1;
    mt.resize( N);
    fprintf( stderr, "generator constructor N %d\n", N);
  }

  Generator( const Generator&);

  /* initializes mt[N] with a seed */
  void init_genrand(uint32_t s);
  
  /* initialize by an array with array-length */
  /* init_key is the array for initializing keys */
  /* key_length is its length */
  /* slight change for C++, 2004/2/26 */
  void init_by_array(uint32_t init_key[], int key_length);

  /* generates a random number on [0,0xffffffff]-interval */
  uint32_t genrand_int32(void);

  /* generates a random number on [0,0x7fffffff]-interval */
  long genrand_int31(void);
  
/* generates a random number on [0,1]-real-interval */
  double genrand_real1(void);
  
  /* generates a random number on [0,1)-real-interval */
  double genrand_real2(void);
  
/* generates a random number on (0,1)-real-interval */
  double genrand_real3(void);
  
  /* generates a random number on [0,1) with 53-bit resolution*/
  double genrand_res53(void);

  /* These real versions are due to Isaku Wada, 2002/01/09 added */

  uint32_t state_size() const{
    return N;
  }

  /*
  void get_state( Vector< uint32_t>& state, 
		  uint32_t& counter) const;

  void set_state( const Vector< uint32_t>& state,
		  uint32_t counter);
  */
  void get_state( State& state) const;
  void set_state( const State& state);

  Generator& operator=( const Generator&);

private:

/* Period parameters */  
  static const uint32_t N = 624;
  static const uint32_t M = 397;
  static const uint32_t MATRIX_A = 0x9908b0dfUL;   /* constant vector a */
  static const uint32_t UPPER_MASK = 0x80000000UL; /* most significant w-r bits */
  static const uint32_t LOWER_MASK = 0x7fffffffUL; /* least significant r bits */
  
  Vector< uint32_t> mt; /* the array for the state vector  */
  int mti; /* mti==N+1 means mt[N] is not initialized */

};

  void init_genrands( uint32_t seed0, Vector< Generator*>& gens);

}



#endif
