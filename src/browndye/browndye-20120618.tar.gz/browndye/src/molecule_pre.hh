/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/

/*
Contains various classes used in those defined in "molecule.hh".

Blank_Transform - used in "Large_Molecule_State" since its position
and rotation are normalized after each step. Placeholder in case  
we decide to make the Large Molecule move.

Atom_Large, Atom_Small - atoms of the Large and Small molecules.

Ellipsoid - contains the ellipsoid shape information of the molecules.

The other classes are interface classes for the collision tester and
charged blob classes.

Included by "molecule.hh".
 */

#include "vector"
#include "linalg3.hh"
#include "transform.hh"
#include "field.hh"
#include "charged_blob_simple.hh"
#include "parameter_info.hh"
#include "collision_detector.hh"

class Blank_Transform{
  
public:
  void get_translation( Vec3< Length>& x) const{
    x[0] = x[1] = x[2] = Length( 0.0);
  }

  void get_translated( const Vec3< Length>& before, Vec3< Length>& after) const{
    Linalg3::copy( before, after);
  }

  template< class U>
  void get_rotated( const Vec3< U>& before, Vec3< U>& after) const{
    Linalg3::copy( before, after);
  }

  template< class U>
  void get_transformed( const Vec3< U>& before, Vec3< U>& after) const{
    Linalg3::copy( before, after);
  }  
  
  void get_inverse( Blank_Transform& ) const {}

  void set_zero(){}
};

inline
void get_product( const Blank_Transform&, const Transform& trans1,
		  Transform& trans01){
  trans01.copy_from( trans1);
}

inline
void get_product( const Transform& trans0, const Blank_Transform&,
		  Transform& trans01){
  trans01.copy_from( trans0);
}

struct Atom_Large{

  Atom_Large();

  void get_transformed_position( const Blank_Transform&, 
				 Vec3< Length>&_pos) const{
    Linalg3::copy( pos, _pos);
  }

  void translate( const Vec3< Length>& trans){
    Linalg3::get_sum( pos, trans, pos);
  }

  void get_position( Vec3< Length>& _pos) const{
    Linalg3::copy( pos, _pos);
  }

  void set_position( const Vec3< Length>& _pos){
    Linalg3::copy( _pos, pos);
  }

  Length interaction_radius() const;

  typedef Vector< int>::size_type size_type;

  Length hard_radius, soft_radius, interac_radius;
  Vec3< Length> pos;
  bool soft;
  unsigned int number;
  size_type type;
};

struct Atom_Small: public Atom_Large{
public:
  Atom_Small();

  void get_transformed_position( const Transform&, Vec3< Length>&) const;

  bool transform_is_cleared() const{
    return !is_transformed;
  }

  void clear_transformed();

private: 
  mutable Vec3< Length> tpos;
  mutable bool is_transformed;
};

inline
Length Atom_Large::interaction_radius() const{
  return interac_radius;
}

inline
void Atom_Small::clear_transformed(){
  is_transformed = false;
}

inline
void Atom_Small::get_transformed_position( const Transform& tform, Vec3< Length>& _tpos) const{
  if (!is_transformed){
    tform.get_transformed( pos, tpos);
    is_transformed = true; 
  }  
  Linalg3::copy( tpos, _tpos);
}

// constructor
inline
Atom_Large::Atom_Large(){
  pos[0] = pos[1] = pos[2] = Length( NAN);
  hard_radius = Length( NAN);
  soft_radius = Length( NAN);
  soft = false;
  number = std::numeric_limits< unsigned int>::max();
  type = std::numeric_limits< size_type>::max();

}

// constructor
inline
Atom_Small::Atom_Small(){
  tpos[0] = tpos[1] = tpos[2] = Length( NAN);
  is_transformed = false;
}

struct Ellipsoid{
  
  Vec3< Vec3< double> > axes;
  Vec3< Length> distances;
  Vec3< Length> center;

  Ellipsoid();
};


typedef Vector< Atom_Large> Atoms_Large;
typedef Atoms_Large::iterator Atom_Large_Ref;
typedef Atoms_Large::const_iterator Atom_Large_Const_Ref;
typedef Vector< Atom_Large_Ref> Atom_Large_Refs;

typedef Vector< Atom_Small> Atoms_Small;
typedef Atoms_Small::iterator Atom_Small_Ref;
typedef Atoms_Small::const_iterator Atom_Small_Const_Ref;
typedef Vector< Atom_Small_Ref> Atom_Small_Refs;

inline
Ellipsoid::Ellipsoid(){
  for( int i=0; i<3; i++)
    Linalg3::fill_with_nan( axes[i]);
  Linalg3::fill_with_nan( distances);
}


template< class CInterface, class FInterface>
class Blob_Interface;

class Col_Interface_Large;
class Col_Interface_Small;

template< class CInterface, class FInterface>
struct Field_For_Blob{
  Field::Field< FInterface>* field;
  Collision_Detector::Structure< CInterface>* 
    collision_structure;

  Field_For_Blob(){
    field = NULL;
    collision_structure = NULL;
  }
};

class V_Field_Interface{
public:
  typedef EPotential Potential;
  typedef ::Charge Charge;
  typedef ::Permittivity Permittivity;
  typedef ::EPotential_Gradient Potential_Gradient;
};


class Born_Field_Interface{
public:
  typedef UProd< ::Charge, ::Charge>::Res Charge2;
  typedef UQuot< Energy, Charge2>::Res Potential;
  typedef Charge2 Charge;
  typedef UProd< Charge2, Charge2>::Res Charge4;
  typedef UQuot< Charge4, UProd< Length, Energy>::Res >::Res Permittivity;
  typedef UQuot< Potential, Length>::Res Potential_Gradient;
};



