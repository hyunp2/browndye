/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/

/*
These functions, involving the classes defined in "molecule.hh", 
include those concerned with initializing, 
computing forces, and estimating the hydrodynamic distance.
It implements the interface classes for the electrostatic and
desolvation forces and the collision tester.  It also implements
the short-ranged L-J forces.
*/

#include "molecule.hh"
#include "ellipsoid_distances.hh"
#include "node_info.hh"
#include "molecule_pair.hh"

static const double collision_pad = 1.2; // for 1/r^12 interaction

typedef Jam_String::String< char> String;

//***************************************************************************
// Ellipsoid functions

template< class Tform>
void rotate_ellipsoid( const Ellipsoid& ellipsoid,
		       const Tform& transform,
		       SVec< Vec3< double>, 3>& axes){

  for( int i=0; i<3; i++)
    transform.get_rotated( ellipsoid.axes[i], axes[i]);
}


Length hydro_gap(      
		 const Large_Molecule_Common& molc0,
		 const Large_Molecule_State& mols0,
		 const Small_Molecule_Common& molc1,
		 const Small_Molecule_Thread& molt1,
		 const Small_Molecule_State& mols1		       
		 ){
  
  Vec3< Length> center0, center1;
  SVec< Vec3< double>, 3> axes0, axes1;
  
  const Ellipsoid& ell0 = molc0.hydro_ellipsoid;  
  const Ellipsoid& ell1 = molc1.hydro_ellipsoid;
  
  mols0.transform.get_translation( center0);
  mols1.transform.get_translation( center1);

  rotate_ellipsoid( ell0, mols0.transform, axes0);
  rotate_ellipsoid( ell1, mols1.transform, axes1);
  

  return
    ellipsoid_distance( axes0, ell0.distances, center0,
			axes1, ell1.distances, center1);
  
}
//**********************************************************
namespace L = Linalg3;

const unsigned int max_per_cell = 8; 

template< class CInterface> 
class Distance_Finder{
public:
  typedef typename CInterface::Atom Atom;
  typedef typename CInterface::Atoms Atoms;
  typedef typename CInterface::Transform Transform;
  typedef typename CInterface::Ref  Ref;
  typedef typename CInterface::Refs Refs;
  typedef typename Atoms::size_type size_type;

  bool operator()( const Atoms&, const Refs& arefs, 
		   Length r, const Vec3< Length>& pos) const{

    const size_type n = arefs.size();
    for( size_type i = 0; i<n; i++){
      Ref aref = arefs[i];
      Vec3< Length> tpos;
      aref->get_position( tpos);

      if (L::distance( tpos, pos) < r + aref->hard_radius)
	return true;
    }
    return false;
  }
};

// CInterface refers to collision structure of field
template< class CInterface, class FInterface>
class Blob_Interface{
public:
  typedef typename FInterface::Charge Charge;
  typedef typename FInterface::Potential Potential;
  typedef ::Transform Transform;
  typedef Field_For_Blob< CInterface, FInterface> Field;

  static
  void translate( const Transform& trans, const Vec3< Length>& before, Vec3< Length>& after){
    trans.get_translated( before, after);
  }

  template< class U>
  static
  void rotate( const Transform& trans, const Vec3< U>& before, Vec3< U>& after){
    trans.get_rotated( before, after);
  }

  static
  Potential value( const Field& field, const Vec3< Length>& pos){
    return field.field->potential( pos);
  }

  typedef typename UQuot< Potential, Length>::Res Potential_Gradient;

  static
  void get_gradient( const Field& field, const Vec3< Length>& pos, 
		     Vec3< Potential_Gradient>& grad){
    field.field->get_gradient( pos, grad);
  } 

  static
  bool distance_less_than( const Field& field, Length r, 
			   const Vec3< Length>& pos){

    Distance_Finder< CInterface> df;
    return field.collision_structure->is_within( df, r, pos);
  }
};

//*********************************************************************************
// Interface classes for the collision tester

template< class F, class Interface>
void partition_contents_ext( 
			 const typename Interface::Refs& refs, const F& f, 
			 typename Interface::Refs& refs0, 
			 typename Interface::Refs& refs1){
  
  typedef typename Interface::size_type size_type;

  const size_type n = refs.size();
  size_type n1 = 0;
  for( size_type i = 0; i<n; i++){
    Vec3< Length> pos;
    refs[i]->get_position( pos);
    if (f( pos))
      ++n1;
  }
  refs1.resize( n1);
  refs0.resize( n-n1);

  size_type i0 = 0;
  size_type i1 = 0;
  for( size_type i = 0; i<n; i++){
    Vec3< Length> pos;
    refs[i]->get_position( pos);
     if (f( pos)){
       refs1[i1] = refs[i];
      ++i1;
     }
     else{
       refs0[i0] = refs[i];
      ++i0;
     }
  }
}

template< class Interface>
class Col_Interface_Gen{
public:
  typedef typename Interface::Atom Atom;
  typedef Vector< Atom> Atoms;
  typedef Atoms Container;
  typedef typename Vector< Atom>::iterator Ref;
  typedef typename Interface::Refs Refs;
  typedef typename Interface::Transform Transform;
  typedef typename Atoms::size_type size_type;
  typedef typename Atoms::difference_type difference_type;

  static
  void copy_references( Atoms& atoms, Refs& arefs){
    const size_type n = atoms.size();
    arefs.resize( n);
    for( size_type i=0; i<n; i++)
      arefs[i] = atoms.begin() + i;
  }

  static
  void copy_references( const Atoms& atoms, const Refs& arefs0,
			Refs& arefs1){
    const size_type n = arefs0.size();
    arefs1.resize( n);
    for( size_type i=0; i<n; i++)
      arefs1[i] = arefs0[i];
  }

  static
  size_type size( const Atoms& atoms){
    return atoms.size();
  }

  static
  size_type size( const Atoms& atoms, const Refs& refs){
    return refs.size();
  }

  static
  void get_position( const Atoms&, const Refs& refs, size_type i, Vec3< Length>& pos){
    refs[i]->get_position( pos);
  }

  static
  Length radius( const Atoms&, const Refs& refs, size_type i){
    return refs[i]->interaction_radius();
  }

  template< class F>
  static
  void partition_contents( const Atoms&, const Refs& refs, const F& f,
			   Refs& refs0, Refs& refs1){
    partition_contents_ext< F, Interface>( refs, f, refs0, refs1);
  }

  static
  void empty_container( Atoms&, Refs& refs){
    refs.resize( 0);
  }

  static
  void swap( Atoms&, Refs& refs, size_type i, size_type j){
    typename Refs::value_type ref = refs[i];
    refs[i] = refs[j];
    refs[j] = ref;
  }
};

class Col_Interface_Small_Interface{
public:
  typedef Atom_Small Atom;
  typedef Vector< Atom_Small> Atoms;
  typedef Atoms::iterator Ref;
  typedef Vector< Ref> Refs;
  typedef Atoms::size_type size_type;
  typedef ::Transform Transform; 
};

class Col_Interface_Large_Interface{
public:
  typedef ::Atom_Large Atom;
  typedef Vector< Atom_Large> Atoms;
  typedef Atoms::iterator Ref;
  typedef Vector< Ref> Refs;
  typedef Atoms::size_type size_type;
  typedef Blank_Transform Transform;
};

class Col_Interface_Small: public Col_Interface_Gen< Col_Interface_Small_Interface>{
public:
  static const bool is_changeable = true;

  static
  void get_transformed_position( const Vec3< Length>& pos, const Transform& trans,
				 Vec3< Length>& tpos){
    trans.get_transformed( pos, tpos);
  }
 
  static
  void clear_transform( Atoms_Small&, Atom_Small_Refs& refs){
    for( size_type i = 0; i < refs.size(); ++i){
      refs[i]->clear_transformed();
    }
  }
};

class Col_Interface_Large: public Col_Interface_Gen< Col_Interface_Large_Interface>{
public:
  static const bool is_changeable = false;

  static
  void get_transformed_position( const Vec3< Length>& pos, const Blank_Transform& trans,
				 Vec3< Length>& tpos){
    L::copy( pos, tpos);
  }
 
  static
  void clear_transform( Atoms&, Refs& refs){}
};


class Col_Interface{
public:
  typedef Col_Interface_Large Interface0;
  typedef Col_Interface_Small Interface1;

};

//******************************************************************
// Class member functions

template< class Obj>
void cdelete( Obj* obj){
  if (obj != NULL){
    delete obj;
  }
}

// destructor
Molecule_Common::~Molecule_Common(){
  cdelete( born_field);
}

// destructor
Small_Molecule_Common::~Small_Molecule_Common(){
  cdelete( q_blob);
  cdelete( q2_blob);
}

Large_Molecule_Common::~Large_Molecule_Common(){
  cdelete( v_field);
  cdelete( q2_blob);
  cdelete( collision_structure);
}

// destructor
Small_Molecule_Thread::~Small_Molecule_Thread(){
  cdelete( collision_structure);
}

void set_desolvation_field( Molecule_Common& molc, 
			    const Vector< const char*>& files){

  molc.born_field = new Field::Field< Born_Field_Interface>();
  molc.born_field->initialize( files);  
}

// constructor
Molecule_Common::Molecule_Common(){

  pinfo = NULL;
  h_radius = Length( NAN);
  born_field = NULL;

  soft_radii_from_param_file = true; 
  hard_radii_from_param_file = false;
  desolve_fudge = 1.0;
  use_68 = false;
  pair = NULL;
}

// constructor
Large_Molecule_Common::Large_Molecule_Common(){
  v_field = NULL;
  collision_structure = NULL;
  q2_blob = NULL;
  total_charge = Charge( NAN);

  ks = Spring_Constant( NAN);
  equilib_len = Length( NAN);
  spring_atom0 = NULL;
}

// constructor
Small_Molecule_Common::Small_Molecule_Common(){
  q_blob = NULL;
  q2_blob = NULL;
}


// constructor
Small_Molecule_Thread::Small_Molecule_Thread(){
  collision_structure = NULL;
  pinfo = NULL;
  spring_atom1 = NULL;
}

// constructor
Molecule_State::Molecule_State(){
  L::fill( Force( 0.0), force);
  L::fill( Torque( 0.0), torque);
}


//******************************************************************
// Interface for charge blob


void Small_Molecule_Common::set_electric_chebybox( const char* file, const Vec3< Length>& offset){

  typedef Blob_Interface< Col_Interface_Large,  
                          V_Field_Interface> Q_Blob_Interface;
  
  q_blob = new Charged_Blob::Blob< 4, Q_Blob_Interface>();
  q_blob->initialize( file);
  q_blob->shift_position( offset);
}

template< class Mol>
void set_desolvation_chebybox( Mol& mol, const char* file, const Vec3< Length>& offset){
  printf( "set desolvation chebybox %s\n", file); fflush( stdout);
  mol.q2_blob = new Charged_Blob::Blob< 4, typename Mol::Q2_Blob_Interface>();
  mol.q2_blob->initialize( file);
  mol.q2_blob->shift_position( offset);
}

namespace JP = JAM_XML_Pull_Parser;

template< class Mol>
void set_desolvation_chebybox_from_node( Mol& mol, JP::Node* node, const Vec3< Length>& offset){

  bool found;
  String cbox_file;
  get_value_from_node( node, "charge-squared", cbox_file, found);
  if (found){
    printf( "get eff-volumes\n");
    set_desolvation_chebybox( mol, cbox_file.c_str(), offset);
  }    
}

template< class C0, class FI, class Mol0, class Mol1>
Energy cheby_and_grid_energy( 
	     const Field_For_Blob< C0, FI>& field0, 
             const Charged_Blob::Blob< 4, Blob_Interface< C0, FI> >& blob1,
	     const Mol0& mol0, const Mol1& mol1){

  typedef typename Mol0::Transform Transform0;
  typedef typename Mol1::Transform Transform1;
  
  Transform0 inv_tform0;
  mol0.transform.get_inverse( inv_tform0);
  Transform rel_tform;
  get_product( inv_tform0, mol1.transform, rel_tform);
  
  return blob1.potential_energy( rel_tform, field0);
}

// remember hydro center of molecule 0 sits at origin, cheby torques are about origin,
// and rotation is of blob relative to field
template< class C0, class FI, class Mol0, class Mol1>
void add_cheby_and_grid_forces( 
	     const Field_For_Blob< C0, FI>& field0, 
             const Charged_Blob::Blob< 4, Blob_Interface< C0, FI> >& blob1,
	     Mol0& mol0, Mol1& mol1, double factor){

  typedef typename Mol0::Transform Transform0;
  typedef typename Mol1::Transform Transform1;
  
  Transform0 inv_tform0;
  mol0.transform.get_inverse( inv_tform0);
  Transform rel_tform;
  get_product( inv_tform0, mol1.transform, rel_tform);

  Vec3< Force> force1_fm0;
  Vec3< Torque> torque1_ori_fm0;
  blob1.get_force_and_torque( rel_tform, field0, force1_fm0, torque1_ori_fm0);

  Vec3< Force> force1;
  mol0.transform.get_rotated( force1_fm0, force1);

  Vec3< Torque> torque1_ori;
  mol0.transform.get_rotated( torque1_ori_fm0, torque1_ori);

  Vec3< Torque> torque0_ori;
  L::get_scaled( -1.0, torque1_ori, torque0_ori);

  Vec3< Force> force0;
  L::get_scaled( -1.0, force1, force0);

  Vec3< Torque> torque1;
  {  
    Vec3< Length> r1;
    mol1.transform.get_translation( r1);
    Vec3< Torque> torque_corr;
    L::get_cross( force1, r1, torque_corr);
    L::get_sum( torque1_ori, torque_corr, torque1);
  }

  Vec3< Torque> torque0;
  {  
    Vec3< Length> r0;
    mol0.transform.get_translation( r0);
    Vec3< Torque> torque_corr;
    L::get_cross( force0, r0, torque_corr);
    L::get_sum( torque0_ori, torque_corr, torque0);
  }

  L::get_scaled( factor, force0, force0);
  L::get_scaled( factor, force1, force1);
  L::get_scaled( factor, torque0, torque0);
  L::get_scaled( factor, torque1, torque1);


  L::get_sum( force0, mol0.force, mol0.force);
  L::get_sum( force1, mol1.force, mol1.force);
  
  L::get_sum( torque0, mol0.torque, mol0.torque);
  L::get_sum( torque1, mol1.torque, mol1.torque);  
}
 
typedef Vec3< Length> Length_Vec3;

typedef Near_Interactions::Parameter_Info PInfo;


//********************************************************************
// Short-ranged forces

class Local_Force_Computer_Base{
public:
  Local_Force_Computer_Base( const Length_Vec3& _center1, const Molecule_Common& _mol0, const Molecule_Common& _mol1):
    center1(_center1), mol0(_mol0), mol1(_mol1)
  {
    L::zero( force1);
    L::zero( torque1);
  }

  Vec3< Force> force1;
  Vec3< Torque> torque1;
  const Length_Vec3& center1;
  const Molecule_Common &mol0, &mol1;
};

template< class Pair_Computer>
class Local_Force_Computer: public Local_Force_Computer_Base{
public:

  Local_Force_Computer( const Length_Vec3& center1, const Molecule_Common& mol0, const Molecule_Common& mol1):
    Local_Force_Computer_Base( center1, mol0, mol1){}

  void operator()( const Blank_Transform& tform0, Atoms_Large& atoms0, Atom_Large_Refs& refs0,
		   const Transform& tform1, Atoms_Small& atoms1, Atom_Small_Refs& refs1,
		   bool& has_collision) const;    

  void operator()( 
		  const Blank_Transform& tform0, Atoms_Large& atoms0, Atom_Large_Refs& refs0,
		  const Transform& tform1, Atoms_Small& atoms1, Atom_Small_Refs& refs1,
		  bool& has_collision, 
		  Atom_Large_Ref& aref0, Atom_Small_Ref& aref1, Length& viol);

  typedef Atoms_Large::size_type size_type;
  Pair_Computer pc;
};

template< class Pair_Computer>
void Local_Force_Computer< Pair_Computer>::
operator()( 
	   const Blank_Transform& tform0, Atoms_Large& atoms0, Atom_Large_Refs& refs0,
	   const Transform& tform1, Atoms_Small& atoms1, Atom_Small_Refs& refs1,
	   bool& has_collision, 
	   Atom_Large_Ref& aref0, Atom_Small_Ref& aref1, Length& viol){
  
  has_collision = false;
  for( Atom_Large_Refs::iterator it0 = refs0.begin(); it0 != refs0.end(); it0++){
    Atom_Large& atom0 = *(*it0);

    Vec3< Length> tpos0;
    atom0.get_transformed_position( tform0, tpos0);

    size_type itype0 = atom0.type;

    Energy eps0( NAN);
    if (atom0.soft){
#ifdef DEBUG
      if (mol0.pinfo == NULL)
	error( "Local_Force_Computer: mol0.pinfo is null");
#endif
      eps0 = mol0.pinfo->parameters( itype0).epsilon;
    }

    for( Atom_Small_Refs::iterator it1 = refs1.begin(); it1 != refs1.end(); it1++){
      Atom_Small& atom1 = *(*it1);

      Vec3< Length> tpos1;
      atom1.get_transformed_position( tform1, tpos1);

      size_type itype1 = atom1.type;
      
      Vec3< Length> diff;
      L::get_diff( tpos1, tpos0, diff);

      Length d = L::norm( diff);

      if (d != d)
	error( "nan encountered");
      
      if (atom0.soft && atom1.soft){
#ifdef DEBUG
      if (mol1.pinfo == NULL)
	error( "Local_Force_Computer: mol1.pinfo is null");
#endif

	Length sigma = atom0.soft_radius + atom1.soft_radius;
	Energy eps1 = mol1.pinfo->parameters( itype1).epsilon;
	Energy eps = sqrt( eps0*eps1);
	Vec3< Force> f;
	
	pc( sigma, eps, diff, d, f);

	L::get_sum( f, force1, force1);
	Vec3< Length> rpos1;
	L::get_diff( tpos1, center1, rpos1);
	Vec3< Torque> tq;
	L::get_cross( rpos1, f, tq);
	L::get_sum( tq, torque1, torque1);
      }
      else{ 
	Length sigma = atom0.hard_radius + atom1.hard_radius;
	if (d < sigma){
	  viol = sigma - d;
	  has_collision = true;

	  goto loop_end;
	}
      }      
    }
  }
 loop_end:
  return;
}

class Pair_Force_Computer_6_12{
public:
  void operator()( Length sigma, Energy eps, 
		   Vec3< Length>& diff, Length d, Vec3< Force>& f) const{    
    double r = d/sigma;
    double r2 = r*r;
    double r4 = r2*r2;
    double r6 = r2*r4;
    double r12 = r6*r6;
    L::get_scaled( 12.0*eps*(1.0/r12 - 1.0/r6)/(d*d), diff, f);
  }
};

class Pair_Force_Computer_6_8{
public:
  void operator()( Length sigma, Energy eps, 
		   Vec3< Length>& diff, Length d, Vec3< Force>& f) const{    
    double r = d/sigma;
    double r2 = r*r;
    double r4 = r2*r2;
    double r6 = r2*r4;
    double r8 = r6*r2;
    L::get_scaled( 24.0*eps*(1.0/r8 - 1.0/r6)/(d*d), diff, f);
  }
};

class Local_Potential_Computer_Base{
public:
  Local_Potential_Computer_Base( const Molecule_Common& _mol0, const Molecule_Common& _mol1):
    mol0(_mol0), mol1(_mol1), potential( 0.0){}

  typedef Atoms_Large::size_type size_type;  
  const Molecule_Common &mol0, &mol1;
  Energy potential;
};

template< class Pair_Computer>
class Local_Potential_Computer: public Local_Potential_Computer_Base{
public:

  Local_Potential_Computer( const Molecule_Common& mol0, const Molecule_Common& mol1):
    Local_Potential_Computer_Base( mol0, mol1){}

  void operator()( const Blank_Transform& tform0, Atoms_Large& atoms0, Atom_Large_Refs& refs0,
		     const Transform& tform1, Atoms_Small& atoms1, Atom_Small_Refs& refs1) const;    

  
  void operator()( 
		  const Blank_Transform& tform0, Atoms_Large& atoms0, Atom_Large_Refs& refs0,
		  const Transform& tform1, Atoms_Small& atoms1, Atom_Small_Refs& refs1,
		  bool& has_collision, 
		  Atom_Large_Ref& aref0, Atom_Small_Ref& aref1, Length& viol);
  
  Pair_Computer pc;
};

template< class Pair_Computer>
void Local_Potential_Computer< Pair_Computer>::
operator()( 
	   const Blank_Transform& tform0, Atoms_Large& atoms0, Atom_Large_Refs& refs0,
	   const Transform& tform1, Atoms_Small& atoms1, Atom_Small_Refs& refs1,
	   bool& has_collision, 
	   Atom_Large_Ref& aref0, Atom_Small_Ref& aref1, Length& viol){
  

  has_collision = false;

  for( Atom_Large_Refs::iterator it0 = refs0.begin(); it0 != refs0.end(); it0++){
    Atom_Large& atom0 = *(*it0);

    Vec3< Length> tpos0;
    atom0.get_transformed_position( tform0, tpos0);


    size_type itype0 = atom0.type;

    Energy eps0( NAN);
    if (atom0.soft){

#ifdef DEBUG
      if (mol0.pinfo == NULL)
	error( "Local_Potential_Computer: mol0.pinfo is null");
#endif

      eps0 = mol0.pinfo->parameters( itype0).epsilon;
    }


    for( Atom_Small_Refs::iterator it1 = refs1.begin(); it1 != refs1.end(); it1++){
      Atom_Small& atom1 = *(*it1);

      Vec3< Length> tpos1;
      atom1.get_transformed_position( tform1, tpos1);

      size_type itype1 = atom1.type;
      
      Vec3< Length> diff;
      L::get_diff( tpos1, tpos0, diff);

      Length d = L::norm( diff);

      if (d != d)
	error( "nan encountered");

      if (atom0.soft && atom1.soft){

#ifdef DEBUG
      if (mol1.pinfo == NULL)
	error( "Local_Potential_Computer: mol1.pinfo is null");
#endif

	Length sigma = atom0.soft_radius + atom1.soft_radius;
	Energy eps1 = mol1.pinfo->parameters( itype1).epsilon;
	Energy eps = sqrt( eps0*eps1);
	potential += pc( sigma, eps, d);	
      }

      else{ 
	Length sigma = atom0.hard_radius + atom1.hard_radius;
	if (d < sigma){
	  viol = sigma - d;
	  has_collision = true;
	  potential = Energy( INFINITY);
	  goto loop_end;
	}
      }      
    }
  }
 loop_end:

  return;
}

class Pair_Potential_Computer_6_12{
public:
  Energy operator()( Length sigma, Energy eps, Length d) const{    
    double r = d/sigma;
    double r2 = r*r;
    double r4 = r2*r2;
    double r6 = r2*r4;
    double r12 = r6*r6;
    return eps*(1.0/r12 - 2.0/r6);
  }
};

class Pair_Potential_Computer_6_8{
public:
  Energy operator()( Length sigma, Energy eps, Length d) const{    
    double r = d/sigma;
    double r2 = r*r;
    double r4 = r2*r2;
    double r6 = r2*r4;
    double r8 = r6*r2;
    return eps*(3.0/r8 - 4.0/r6);
  }
};

//********************************************************************************
// All forces

// mol0 has vgrid; forces and torques about hydro centers
void add_forces_and_torques( 
			    const Large_Molecule_Common& molc0,
			    Large_Molecule_State& mol0,
			    const Small_Molecule_Common& molc1,
			    Small_Molecule_Thread& molt1,
			    Small_Molecule_State& mol1,
			    
			    bool& has_collision,
			    Length& violation,
			    Atom_Large_Ref& aref0,
			    Atom_Small_Ref& aref1
			    ){

  typedef Blob_Interface< Col_Interface_Large, V_Field_Interface> Q_Blob_Interface;
  typedef Blob_Interface< Col_Interface_Small, Born_Field_Interface> Q2_Blob0_Interface;
  typedef Blob_Interface< Col_Interface_Large, Born_Field_Interface> Q2_Blob1_Interface;
 
  Vec3< Length> center0, center1;
  molc0.get_hydro_center( center0);
  {
    Vec3< Length> bcenter0, bcenter1;
    molc0.get_hydro_center( bcenter0);
    molc1.get_hydro_center( bcenter1);
    mol0.transform.get_transformed( bcenter0, center0);
    mol1.transform.get_transformed( bcenter1, center1);
  }  
 
  Local_Force_Computer< Pair_Force_Computer_6_12> lfc6_12( center1, molc0, molc1);
  Local_Force_Computer< Pair_Force_Computer_6_8>  lfc6_8( center1, molc0, molc1);

  Local_Force_Computer_Base* lfc;

  if (molc0.use_68){
    lfc = &lfc6_8;
    Collision_Detector::
      compute_interaction< Col_Interface>( lfc6_8, 
					   *(molc0.collision_structure), Blank_Transform(),
					   *(molt1.collision_structure), mol1.transform, 
					   has_collision,
					   aref0, aref1, violation);
  }
  else{
    lfc = &lfc6_12;
    Collision_Detector::
      compute_interaction< Col_Interface>( lfc6_12, 
					   *(molc0.collision_structure), Blank_Transform(),
					   *(molt1.collision_structure), mol1.transform, 
					   has_collision,
					   aref0, aref1, violation);
  }

  if (has_collision){
    return;
  }
  else{
    {
      Vec3< Force> force0;
      L::get_scaled( -1.0, lfc->force1, force0);
      Vec3< Torque> torque0_abt_1;
      L::get_scaled( -1.0, lfc->torque1, torque0_abt_1);
      Vec3< Length> r01;
      L::get_diff( center1, center0, r01);
      Vec3< Torque> torque_shift;
      L::get_cross( r01, force0, torque_shift);
      Vec3< Torque> torque0;
      L::get_sum( torque0_abt_1, torque_shift, torque0);
            
      L::get_sum( force0, mol0.force, mol0.force);
      L::get_sum( torque0, mol0.torque, mol0.torque);
      L::get_sum( lfc->force1, mol1.force, mol1.force);
      L::get_sum( lfc->torque1, mol1.torque, mol1.torque);      
    }

    Field_For_Blob< Col_Interface_Large, V_Field_Interface> v_field_for_blob;
    v_field_for_blob.field = molc0.v_field;
    v_field_for_blob.collision_structure = molc0.collision_structure;

    add_cheby_and_grid_forces( v_field_for_blob, *(molc1.q_blob), mol0, mol1, 1.0);

    if (molc0.born_field != NULL && molc1.born_field != NULL){

    // desolvation forces
      Field_For_Blob< Col_Interface_Small, Born_Field_Interface> born_field_for_blob1;
      born_field_for_blob1.field = molc1.born_field;
      born_field_for_blob1.collision_structure = molt1.collision_structure;

      Field_For_Blob< Col_Interface_Large, Born_Field_Interface> born_field_for_blob0;
      born_field_for_blob0.field = molc0.born_field;
      born_field_for_blob0.collision_structure = molc0.collision_structure;

      add_cheby_and_grid_forces( born_field_for_blob0, *(molc1.q2_blob), mol0, mol1, molc1.desolve_fudge);
      add_cheby_and_grid_forces( born_field_for_blob1, *(molc0.q2_blob), mol1, mol0, molc0.desolve_fudge);
    }     
  }
  // tether force
  if ((molc0.spring_atom0 != NULL) && (molt1.spring_atom1 != NULL)){
    Vec3< Length> tpos0, tpos1;
    molc0.spring_atom0->get_transformed_position( Blank_Transform(), tpos0);
    molt1.spring_atom1->get_transformed_position( mol1.transform, tpos1);

    Vec3< Length> diff;
    L::get_diff( tpos1, tpos0, diff);
    Length d = L::norm( diff);
    Force f = molc0.ks*( molc0.equilib_len - d);
    Vec3< Force> F1, F0;
    L::get_scaled( (f/d), diff, F1);
    L::get_scaled( -1.0, F1, F0);

    Vec3< Length> larm0, larm1;
    L::get_diff( tpos0, center0, larm0);
    L::get_diff( tpos1, center1, larm1);
    Vec3< Torque> T0, T1;
    L::get_cross( larm0, F0, T0);
    L::get_cross( larm1, F1, T1);

    L::get_sum( F0, mol0.force, mol0.force);
    L::get_sum( F1, mol1.force, mol1.force);
    L::get_sum( T0, mol0.torque, mol0.torque);
    L::get_sum( T1, mol1.torque, mol1.torque);
  }
}


void add_forces_and_torques( 
			    const Large_Molecule_Common& molc0,
			    Large_Molecule_State& mol0,
			    const Small_Molecule_Common& molc1,
			    Small_Molecule_Thread& molt1,
			    Small_Molecule_State& mol1,			    
			    bool& has_collision
			    ){

  Length violation;
  Atom_Large_Ref aref0;
  Atom_Small_Ref aref1;
  add_forces_and_torques( molc0, mol0, molc1, molt1, mol1, has_collision, violation, aref0, aref1);
}

void get_potential_energy( 
			  const Large_Molecule_Common& molc0,
			  const Large_Molecule_State& mol0,
			  const Small_Molecule_Common& molc1,
			  Small_Molecule_Thread& molt1,
			  const Small_Molecule_State& mol1,
			  Energy& vnear, Energy& vcoul, Energy& vdesolv
			   ){
 
  Local_Potential_Computer< Pair_Potential_Computer_6_12> lpc6_12( molc0, molc1);
  Local_Potential_Computer< Pair_Potential_Computer_6_8> lpc6_8( molc0, molc1);
  Local_Potential_Computer_Base* lpc;

  bool has_collision;

  {
    Length violation;
    Atom_Large_Ref aref0;
    Atom_Small_Ref aref1;

    if (molc0.use_68){
      lpc = &lpc6_8;
      Collision_Detector::
	compute_interaction< Col_Interface>( lpc6_8, 
					     *(molc0.collision_structure), Blank_Transform(),
					     *(molt1.collision_structure), mol1.transform, 
					     has_collision, aref0, aref1, violation);    
    }
    else{
      lpc = &lpc6_12;
      Collision_Detector::
	compute_interaction< Col_Interface>( lpc6_12, 
					     *(molc0.collision_structure), Blank_Transform(),
					     *(molt1.collision_structure), mol1.transform, 
					     has_collision, aref0, aref1, violation);    
    }
  }
 
  if (has_collision){
    vnear = Energy( INFINITY);
  }
  else {
    vnear = lpc->potential;

    Field_For_Blob< Col_Interface_Large, V_Field_Interface> v_field_for_blob;
    v_field_for_blob.field = molc0.v_field;
    v_field_for_blob.collision_structure = molc0.collision_structure;

    vcoul = cheby_and_grid_energy( v_field_for_blob, *(molc1.q_blob), mol0, mol1);
    
    vdesolv = Energy( 0.0);
    if (molc0.born_field != NULL && molc1.born_field != NULL){
      // desolvation forces

      Field_For_Blob< Col_Interface_Small, Born_Field_Interface> born_field_for_blob1;
      born_field_for_blob1.field = molc1.born_field;
      born_field_for_blob1.collision_structure = molt1.collision_structure;

      Field_For_Blob< Col_Interface_Large, Born_Field_Interface> born_field_for_blob0;
      born_field_for_blob0.field = molc0.born_field;
      born_field_for_blob0.collision_structure = molc0.collision_structure;

      vdesolv = 
	molc1.desolve_fudge*cheby_and_grid_energy( born_field_for_blob0, *(molc1.q2_blob), mol0, mol1) 
	+
	molc0.desolve_fudge*cheby_and_grid_energy( born_field_for_blob1, *(molc0.q2_blob), mol1, mol0);
    }
  }
}

void compute_forces_and_torques(
				const Large_Molecule_Common& molc0,
				Large_Molecule_State& mol0,
				const Small_Molecule_Common& molc1,
				Small_Molecule_Thread& molt1,
				Small_Molecule_State& mol1,		   
				bool& has_collision){
  L::zero( mol0.force);
  L::zero( mol0.torque);
  L::zero( mol1.force);
  L::zero( mol1.torque);
  add_forces_and_torques( molc0, mol0, 
			  molc1, molt1, mol1, 
			  has_collision);

}

void compute_forces_and_torques(
				const Large_Molecule_Common& molc0,
				Large_Molecule_State& mol0,
				const Small_Molecule_Common& molc1,
				Small_Molecule_Thread& molt1,
				Small_Molecule_State& mol1,		   
				bool& has_collision,
				Length& violation,
				Atom_Large_Ref& aref0, Atom_Small_Ref& aref1
				){
  L::zero( mol0.force);
  L::zero( mol0.torque);
  L::zero( mol1.force);
  L::zero( mol1.torque);
  add_forces_and_torques( molc0, mol0, 
			  molc1, molt1, mol1, 
			  has_collision, violation, aref0, aref1);

}

//***********************************************************************
// Initialization code

template< class U>
void get_vector3( JP::Node* node, Vec3< U>& a){
  JP::Str_Stream& stm = node->stream();
  double val;
  stm >> val; 
  set_fvalue( a[0], val);
  stm >> val; 
  set_fvalue( a[1], val);
  stm >> val; 
  set_fvalue( a[2], val);
}

void get_ecenter( JP::Node* top_node, const char* name, Ellipsoid& ellipsoid){
  JP::Node* node = checked_child( top_node, name);
  get_vector3( node, ellipsoid.center);
} 

void get_edistances( JP::Node* top_node, const char* name, Ellipsoid& ellipsoid){
  JP::Node* node = checked_child( top_node, name);
  get_vector3( node, ellipsoid.distances);
} 

void Molecule_Common::set_h_radius( const char* file){
  std::ifstream input( file);
  if (!input.is_open())
    error( "file ", file, " could not be opened");

  JP::Parser parser( input);

  parser.complete_current_node();
  JP::Node* top_node = parser.current_node();
  h_radius = Length( double_from_node( top_node));
}

void Molecule_Common::set_ellipsoids( const char* file){
  std::ifstream input( file);

  if (!input.is_open())
    error( "file ", file, " could not be opened");

  JP::Parser parser( input);

  parser.complete_current_node();
  JP::Node* top_node = parser.current_node();

  get_ecenter( top_node, "hydro-center", hydro_ellipsoid);
  get_edistances( top_node, "hydro-radii", hydro_ellipsoid);  

  JP::Node* anode = checked_child( top_node, "axes");
  std::list< JP::Node* > vnodes;
  anode->get_children( "axis", vnodes);
  std::list< JP::Node* >::iterator iter = vnodes.begin();
  for( int i = 0; i<3; i++){
    get_vector3( *iter, hydro_ellipsoid.axes[i]);
    ++iter;
  }
}

namespace JP = JAM_XML_Pull_Parser;

void get_char_arrays_from_strings( const Vector< String>& strs,
				   Vector< const char*>& carrays){
  
  typedef Vector< String>::size_type size_type;
  const size_type n = strs.size();
  carrays.resize( n);
  for( size_type i=0; i<n; i++){
    size_type ns = strs[i].size();
    char* carray = new char [ns+1];
    strcpy( carray, strs[i].c_str());
    carrays[i] = carray;
  }
}

void get_strings( JP::Node* node, const char* tag, 
		  Vector< const char*>& carrays){

  typedef Vector< String>::size_type size_type;

  Vector< String> strs;
  std::list< JP::Node*> cnodes;
  node->get_children( tag, cnodes);
  size_type n = cnodes.size();
  strs.resize( n);

  std::list< JP::Node*>::iterator itr = cnodes.begin();
  for( size_type i=0; i<n; i++){
    JP::Node* cnode = *itr;
    cnode->stream() >> strs[i];
    ++itr;
  }

  get_char_arrays_from_strings( strs, carrays);
}

void set_electric_field( Large_Molecule_Common& molc,  
			 const Vector< const char*>& files){
  typedef Field::Field< V_Field_Interface> FD;
  molc.v_field = new FD();
  molc.v_field->initialize( files);
}


template< class Interface>
void initialize_field( JP::Node* enode, 
		       Field::Field< Interface>*& field){
  if (enode != NULL){

    JP::Node* mpnode = enode->child( "multipole-field");
    
    // fields listed starting with outer
    Vector< const char*> grid_files;

    get_strings( enode, "grid", grid_files);

    field = new Field::Field< Interface>();
    
    if (mpnode != NULL){
      String mpfile = string_from_node( mpnode);
      field->initialize( mpfile.c_str(), grid_files);
    }
    else { // mpnode == NULL
      field->initialize( grid_files);
    }

    typedef Vector< const char*>::size_type size_type;
    for (size_type i=0; i<grid_files.size(); i++)
      delete [] grid_files[i];
  }
}

// Interface for reading in atoms and parameter information
template< class Atom>
class Pinfo_Interface{
public:
  typedef Vector< Atom> Spheres;
  typedef typename Spheres::size_type size_type;

  static 
  void put_position( Spheres& atoms, size_type i, const Vec3< Length>& pos){
    atoms[i].set_position( pos);
  }

  static
  void put_hard_radius( Spheres& atoms, size_type i, Length r){
    atoms[i].hard_radius = r;
  }

  static
  void put_soft_radius( Spheres& atoms, size_type i, Length r){
    atoms[i].soft_radius = r;
  }

  static
  void put_interaction_radius( Spheres& atoms, size_type i, Length r){
    atoms[i].interac_radius = r;
  }

  static
  void put_charge( Spheres& atoms, size_type i, Charge q){
    // atom charge not used this time
  }

  static
  void put_type( Spheres& atoms, size_type i, size_type type){
    atoms[i].type = type;
  }

  static
  void put_number( Spheres& atoms, size_type i, size_type number){
    atoms[i].number = number;
  } 

  static
  void resize( Spheres& atoms, size_type n){
    atoms.resize( n);
  }

  static
  void make_soft( Spheres& atoms, size_type i){
    atoms[i].soft = true;
  }  
};


template< class Atom>
void check_for_param_file( const Vector< Atom>& atoms,
			   const Near_Interactions::Parameter_Info* pinfo,
			   int i){
  for (typename Vector< Atom>::const_iterator itr = atoms.begin();
       itr != atoms.end(); ++itr){
    const Atom& atom = *itr;
    if (atom.soft && pinfo == NULL)
      error( "molecule ", i, 
	     " must have a LJ parameter file since is has soft atoms");
  }
  
}

template< class Atom>
const Atom* atom_of_number( const Vector< Atom>& atoms, unsigned int number){
  for( typename Vector< Atom>::const_iterator itr = atoms.begin(); itr != atoms.end(); ++itr){
    const Atom& atom = *itr;
    if (atom.number == number){
      return &atom;
    }
  }
  error( "atom number ", number, " for tether not found");
  return NULL;
}

namespace JP = JAM_XML_Pull_Parser;

template< class Atom>
void get_atoms_from_file( const Near_Interactions::Parameter_Info* pinfo, 
			  const char* file, Vector< Atom>& atoms, 
			  bool hard_radii_from_param, bool soft_radii_from_param,
			  bool use_68){
  
  typedef Pinfo_Interface< Atom> Interface;
  Near_Interactions::get_atoms_from_file< Interface>( pinfo, file,
						      atoms, false, hard_radii_from_param, 
						      soft_radii_from_param, use_68);
}

void Small_Molecule_Thread::initialize( const Small_Molecule_Common& molc, 
					JP::Node* node){

  printf( "molecule thread initialize %p\n", &molc); fflush( stdout);

  pinfo = molc.pinfo;
  String atom_file = string_from_node( node, "atoms");
  get_atoms_from_file( pinfo, atom_file.c_str(), atoms, 
		       molc.hard_radii_from_param_file, 
		       molc.soft_radii_from_param_file,
		       molc.use_68);

  // shift molecule hydro center to origin
  Vec3< Length> offset;
  {
    Vec3< Length> center;
    L::copy( molc.hydro_ellipsoid.center, center);
    L::get_scaled( -1.0, center, offset);
  }

  for( size_type i = 0; i < atoms.size(); i++){
    Atom_Small& atom = atoms[i];
    atom.translate( offset);
  }

  collision_structure = 
    new Collision_Detector::Structure< Col_Interface_Small>( atoms);

  collision_structure->set_max_number_per_cell( max_per_cell);
  collision_structure->load_objects();

  check_for_param_file( atoms, pinfo, 1);

  JP::Node* tether_node = node->child( "tether");
  if (tether_node != NULL){
    JP::Node* a1_node = checked_child( tether_node, "atom1");
    unsigned int num = int_from_node( a1_node);
    spring_atom1 = atom_of_number( atoms, num);
  }
}

Near_Interactions::Parameter_Info* initialized_param_info( JP::Node* node){
  JP::Node* pnode = node->child( "short-ranged-force-parameters");

  Near_Interactions::Parameter_Info* res;
  if (pnode != NULL){
    String file_name = string_from_node( pnode);
    res =  new Near_Interactions::Parameter_Info( file_name.c_str());
  }
  else
    res =  NULL;
  return res;
}

void Large_Molecule_Common::initialize( JP::Node* node, 
					Molecule_Pair_Common* _pair){

  pair = _pair;
  Vec3< Length> offset; 
  initialize_super( node, offset);

  String atom_file = string_from_node( node, "atoms");
  get_atoms_from_file( pinfo, atom_file.c_str(), atoms, 
		       hard_radii_from_param_file, soft_radii_from_param_file,
		       use_68);

  // shift molecule hydro center to origin
  for( size_type i = 0; i < atoms.size(); i++){
    Atom_Large& atom = atoms[i];
    atom.translate( offset);
  }

  collision_structure = 
    new Collision_Detector::Structure< Col_Interface_Large>( atoms);

  collision_structure->set_max_number_per_cell( max_per_cell);
  collision_structure->load_objects();

  JP::Node* enode = node->child( "electric-field");
  if (enode != NULL){
    printf( "get electric-field\n");
    initialize_field( enode, v_field);
    v_field->shift_position( offset);
  }

  set_desolvation_chebybox_from_node( *this, node, offset);
  get_checked_double_from_node( node, "total-charge", total_charge);

  check_for_param_file( atoms, pinfo, 0);

  JP::Node* tether_node = node->child( "tether");
  if (tether_node != NULL){
    JP::Node* el_node = checked_child( tether_node, "resting-length");
    equilib_len = Length( double_from_node( el_node));

    JP::Node* ed_node = checked_child( tether_node, "length-deviation");
    Length dl = Length( double_from_node( ed_node));
    ks = pair->kT/(dl*dl);

    JP::Node* a0_node = checked_child( tether_node, "atom0");
    unsigned int num = int_from_node( a0_node);
    spring_atom0 = atom_of_number( atoms, num);
  }
}

void Small_Molecule_Common::initialize( JP::Node* node){
  Vec3< Length> offset; 
  initialize_super( node, offset);

  bool found;
  String cbox_file;
  get_value_from_node( node, "eff-charges", cbox_file, found);
  if (found){
    printf( "get eff-charges\n"); 
    set_electric_chebybox( cbox_file.c_str(), offset);
  }
  set_desolvation_chebybox_from_node( *this, node, offset); 
}

void Molecule_Common::initialize_super( JP::Node* node, Vec3< Length>& offset){
  printf( "molecule common initialize %p\n", this);
  printf( "get ellipsoids\n");
  String ellipsoid_file = string_from_node( node, "ellipsoids");
  set_ellipsoids( ellipsoid_file.c_str());

  printf( "get hydro-radius\n");
  String hradius_file = string_from_node( node, "hydro-radius");
  set_h_radius( hradius_file.c_str());

  L::get_scaled( -1.0, hydro_ellipsoid.center, offset);

  JP::Node* dnode = node->child( "desolvation-field");
  if (dnode != NULL){
    printf( "get desolvation-field\n");
    initialize_field( dnode, born_field);
    born_field->shift_position( offset);
  }  

  pinfo = initialized_param_info( node);

  JP::Node* rnode = node->child( "radii");
  if (rnode != NULL){
    JP::Node* hnode = rnode->child( "hard");
    if (hnode != NULL){
      String hstring = string_from_node( hnode);
      if (hstring == String( "parameter-file"))
	hard_radii_from_param_file = true;
      else if (hstring == String( "pqrxml-file"))
	hard_radii_from_param_file = false;
      else
	error( "radii hard tag: ", hstring.c_str(), 
	       " not an option: must be either \"parameter-file\" or \"pqrxml-file\"");
    }
    JP::Node* snode = rnode->child( "soft");
    if (snode != NULL){
      String sstring = string_from_node( snode);
      if (sstring == String( "parameter-file"))
	soft_radii_from_param_file = true;
      else if (sstring == String( "pqrxml-file"))
	soft_radii_from_param_file = false;
      else
	error( "radii soft tag: ", sstring.c_str(), 
	       " not an option: must be either \"parameter-file\" or \"pqrxml-file\"");
    }

    if (pinfo == NULL && (hard_radii_from_param_file || soft_radii_from_param_file))
      error( "initializing molecule: radii tag: must have parameter file");
	
  }
}

Charge Small_Molecule_Common::charge() const{
  if (q_blob == NULL)
    error( "Molecule::charge: info not available");

  return q_blob->total_charge();
}

Charge Large_Molecule_Common::charge() const{
  return total_charge;
}

void Molecule_State::copy_from_super( const Molecule_State& state){
  L::copy( state.force, force);
  L::copy( state.torque, torque);
}


void Small_Molecule_State::copy_from( const Small_Molecule_State& state){
  copy_from_super( state);
  transform.copy_from( state.transform);
}


void Large_Molecule_State::copy_from( const Large_Molecule_State& state){
  copy_from_super( state);
}
