/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/

#ifndef __SIMULATOR_HH__
#define __SIMULATOR_HH__

/*
Simulator is the base class for NAM_Simulator and WE_Simulator.
It holds the molecule data and provides code for reading in 
data from the XML file input to "nam_simulation", we_simulation",
and "build_bins".

*/

#include <set>
#include "molecule_pair.hh"

class Simulator{
public:
  typedef JAM_XML_Pull_Parser::Node Node;
  typedef Vector< int>::size_type size_type;

  Node* initialized_node( JAM_XML_Pull_Parser::Parser&);
  Simulator();
  ~Simulator();
  void initialize_rngs( uint32_t);

  std::ofstream& output_stream();
  void input_rng_states( Node*); 

  void output_rng_states( std::ofstream&, unsigned int n_spaces) const;

protected:
  void input_rng_state( Node*, size_type); 
  void output_rng_state( std::ofstream&, size_type irng, unsigned int n_spaces) const;

  typedef std::list< Node*> NList;

  void begin_output( std:: ofstream&);

  template< class U>
  void outtag( std::ofstream&, const char*, U) const;

  template< class U>
  void outtag( std::ofstream&, const char*, U, int) const;

  void renormalize_reactions();

  Molecule_Pair_Common common;
  Vector< Molecule_Pair_Thread> mthreads;
  std::set< Molecule_Pair_State*> states;
  std::list< Molecule_Pair> pairs;
  
  Jam_String::String< char> output_name;

  Permittivity vacuum_permittivity;
  double solvent_dielectric;
  Length debye_length;
};

//***********************************************************
template< class T>
T output_value( const T& t){
  return t;
}

#ifdef UNITS
template< class M, class L, class T, class Q, class VType>
VType output_value( const Unit< M,L,T,Q,VType>& u){
  return fvalue( u);
}
#endif

template< class U>
inline
void Simulator::outtag( std::ofstream& output, const char* tag, U value) const{
  output << "    <" << tag << "> " << output_value( value) 
	 << " </" << tag << ">\n"; 
}

template< class U>
inline
void Simulator::outtag( std::ofstream& output, const char* tag, U value, int ident) const{
  for( int i = 0; i < ident; i++)
    output << " ";
  
  output << "<" << tag << "> " << output_value( value) << " </" << tag << ">\n"; 
}

#endif
