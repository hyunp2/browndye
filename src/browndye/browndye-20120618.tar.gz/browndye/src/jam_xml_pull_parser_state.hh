/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/

/*
Used internally by JAM_XML_Pull_Parser::Parser; it is the the State template
argument provided to the internal Parser_1F object.
*/

/******************************************************/
class State{
public:
  State( Parser& _parser):
    parser( _parser){
    node = NULL;
  }

  Parser& parser;
  Node* node;
};

