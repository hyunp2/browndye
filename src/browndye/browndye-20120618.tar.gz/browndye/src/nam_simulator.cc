/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/

/*
Implementation of NAM_Simulator
*/

#include <limits>
#include <time.h>
#include "nam_simulator.hh"
#include "node_info.hh"
#include "trajectory_outputter.hh"

namespace L = Linalg3;

// constructor
NAM_Simulator::NAM_Simulator(){
  n_trajs = 0;
  n_trajs_completed = 0;
  n_trajs_started = 0;
  n_stuck = 0;
  n_escaped = 0;
  max_n_steps = std::numeric_limits< unsigned int>::max();
  n_steps_per_output = std::numeric_limits< unsigned int>::max();
  n_trajs_per_output = 1;
  do_output_rng_state = false;
}

//**************************************************************
// Outputting code

void print_molecule_state( std::ofstream& traj_file, 
			   const Small_Molecule_State& state){
  const Transform& tform = state.transform;
  Vec3< Length> trans;
  Mat3< double> rot;

  tform.get_translation( trans);
  tform.get_rotation( rot);

  traj_file << "      <translation> " << fvalue( trans[0]) << " " <<
    fvalue( trans[1]) << " " << fvalue( trans[2]) << " </translation>\n";

  traj_file << "      <rotation>\n";
  traj_file << "        <row> " 
	    << rot[0][0] << " " << rot[0][1] << " " << rot[0][2] 
	    << " </row>\n";

  traj_file << "        <row> " 
	    << rot[1][0] << " " << rot[1][1] << " " << rot[1][2] 
	    << " </row>\n";

  traj_file << "        <row> " 
	    << rot[2][0] << " " << rot[2][1] << " " << rot[2][2] 
	    << " </row>\n";

  traj_file << "      </rotation>\n";
}

void NAM_Simulator::print_state( const Molecule_Pair& mpair, 
				 std::ofstream& traj_file, 
				 bool state_change) const{

  traj_file << "    <state>\n";
  if (state_change)
    traj_file << "      <new-rxn-state> " << mpair.state.current_rxn_state << 
      " </new-rxn-state>\n";
  traj_file << "      <n-state> " << mpair.state.n_steps << " </n-state>\n";

  Energy vnear, vcoul, vdes;
  get_potential_energy( mpair.common.mol0, mpair.state.mol0,  
			mpair.common.mol1, mpair.thread.mol1, 
			mpair.state.mol1,
			vnear, vcoul, vdes
			);
  Energy pe = vnear + vcoul + vdes;

  traj_file << "      <potential-energy>\n";
  traj_file << "        <near-field> " << fvalue( vnear) << " </near-field>\n";
  traj_file << "        <coulombic> " << fvalue( vcoul) << " </coulombic>\n";
  traj_file << "        <desolvation> " << fvalue( vdes) << " </desolvation>\n";
  traj_file << "        <total> " << fvalue( pe) << " </total>\n";
  traj_file << "      </potential-energy>\n";

  print_molecule_state( traj_file, mpair.state.mol1);

  traj_file << "    </state>\n";
  traj_file.flush();
}

typedef Jam_String::String< char> String;

Jam_String::String< char> uitoa( unsigned int i){
  std::ostringstream stm;
  stm << i;
  Jam_String::String< char> res( stm.str().c_str());
  return res;
}

void output_state( const Molecule_Pair& mpair, 
		   Trajectory_Outputter& outputter){

	  
  Energy vnear, vcoul, vdes;
  get_potential_energy( mpair.common.mol0, mpair.state.mol0,  
			mpair.common.mol1, mpair.thread.mol1, 
			mpair.state.mol1,
			vnear, vcoul, vdes
			);
  
  Time time = mpair.state.time;
  const Transform& tform = mpair.state.mol1.transform; 
  Vec3< Length> trans;
  Mat3< double> rot;
  
  tform.get_translation( trans);
  tform.get_rotation( rot);
  
  outputter.output_state( time, trans, rot, vnear, vcoul, vdes);
}

//************************************************************************
// Movement code

void NAM_Simulator::run(){

  const size_type nrxns = common.n_reactions();

  completed_rxns.resize( nrxns+1);
  std::fill( completed_rxns.begin(), completed_rxns.end(), 0);
  n_trajs_completed = 0;
  n_trajs_started = 0;

  multi_mover.do_moves();

}

void NAM_Simulator::run_individual( Molecule_Pair& mpair){

  unsigned int istep = 0;

  Trajectory_Outputter outputter;

  std::ofstream traj_file, index_file;
  bool output_trajectories = traj_file_name.has_value();

  if (output_trajectories){

    Jam_String::String< char> number( uitoa( mpair.thread.n));
    Jam_String::String< char> suffix( ".xml");
    Jam_String::String< char> itext( ".index");

    traj_file.open( (traj_file_name + number + suffix).c_str());
    index_file.open( (traj_file_name + number + itext + suffix).c_str());

    if (!(traj_file.is_open()))
      error( "trajectory file ", traj_file_name.c_str(), " not opened\n");

    outputter.initialize( traj_file, mpair.common.mol0.hydro_ellipsoid.center, 
			  mpair.common.mol1.hydro_ellipsoid.center,
			  index_file);     
  }

  unsigned int n_steps_tot = 0;
  while (true){

    pthread_mutex_lock( &mutex);
    if (n_trajs_started >= n_trajs){
      pthread_mutex_unlock( &mutex);
      break;
    }
    else
      ++n_trajs_started;

    pthread_mutex_unlock( &mutex);

    mpair.set_initial_state();
    size_type istate = mpair.state.current_reaction_state();

    if (output_trajectories){
      outputter.start_trajectory();
      outputter.start_subtrajectory( mpair.common.pathway->state_name( istate));
    }
    

    unsigned long int n_steps = 0;
    Molecule_Pair_Fate fate;
    // stays in loop for one trajectory
    while (true){

      if (output_trajectories && 
	  (mpair.state.n_steps % n_steps_per_output == 0)){
	output_state( mpair, outputter);
      }

      mpair.do_step( fate, n_steps);
      ++istep;
      
      size_type new_istate = mpair.state.current_reaction_state();

      if (new_istate != istate){
	if (output_trajectories && 
	    (fate == In_Action) && (mpair.state.n_steps <= max_n_steps)){
	  outputter.end_subtrajectory( fate, 
				       mpair.common.pathway->reaction_name( mpair.state.last_rxn), 
				       mpair.common.pathway->state_name( new_istate)
				       );
	  outputter.start_subtrajectory( mpair.common.pathway->state_name( new_istate));
	}

	if (output_trajectories)
	  output_state( mpair, outputter);
	
	istate = new_istate;       

	pthread_mutex_lock( &mutex);	
	++completed_rxns[ mpair.state.last_rxn];	
	pthread_mutex_unlock( &mutex);
      }

      if (fate != In_Action){
	pthread_mutex_lock( &mutex);

	++n_trajs_completed;

	if (fate == Escaped)
	  ++n_escaped;

	pthread_mutex_unlock( &mutex);
	break;
      }

      if (mpair.state.n_steps > max_n_steps){
	fate = Stuck;
	pthread_mutex_lock( &mutex);

	++n_stuck;
	++n_trajs_completed;

	pthread_mutex_unlock( &mutex);
	break;
      }

    } // end trajectory

    n_steps_tot += n_steps;
    
    if (output_trajectories){
      const String reaction_name = fate == Final_Rxn ?  
	mpair.common.pathway->reaction_name( mpair.state.last_rxn) :
	String( " ");

      outputter.end_subtrajectory( fate, 
				   reaction_name,
				   mpair.common.pathway->state_name( mpair.state.current_rxn_state));

      outputter.end_trajectory( fate, 
				reaction_name,
				mpair.common.pathway->state_name( mpair.state.current_rxn_state), 
				mpair.state.min_rxn_coord);

      traj_file.flush();
    }
    
    pthread_mutex_lock( &mutex);
    if ((n_trajs_completed+0) % n_trajs_per_output == 0){

      std::ofstream outp( output_name.c_str());
      begin_output( outp);

      outp << "  <reactions>\n";
      outp << "    <n-trajectories> " << n_trajs_completed << " </n-trajectories>\n";
      outp << "    <stuck> " << n_stuck << " </stuck>\n";
      outp << "    <escaped> " << n_escaped << " </escaped>\n";

      const size_type nrxns = mpair.common.n_reactions();
      for( size_type irxn = 0; irxn < nrxns; ++irxn){
	outp << "    <completed>\n";
	outp << "      <name> " << 
	  mpair.common.pathway->reaction_name( irxn).c_str() << " </name>\n";
	outp << "      <n> " << completed_rxns[ irxn] << " </n>\n"; 
	outp << "    </completed>\n";
      }

      outp << "  </reactions>\n";
      outp << "</rates>\n";
      outp.flush();
      outp.close();
    }
    pthread_mutex_unlock( &mutex);
  }

  if (output_trajectories){
    outputter.end_trajectories();
  }
}

void NAM_Multi_Interface::do_move( NAM_Simulator* sim, 
				   unsigned int ithread, Molecule_Pair* mpair){
  sim->run_individual( *mpair);
}

//**************************************************************
// Initialization code

namespace JP = JAM_XML_Pull_Parser;

void NAM_Simulator::initialize( const char* file){
  typedef Jam_String::String< char> Str;

  std::ifstream input( file);
  if (!input.is_open())
    error( "file ", file, " could not be opened");

  JP::Parser parser( input);
  JP::Node* node = initialized_node( parser);

  n_trajs = int_from_node( node, "n-trajectories");

  bool found;
  get_value_from_node( node, "n-steps-per-output", n_steps_per_output, found); 
  get_value_from_node( node, "n-trajectories-per-output", 
		       n_trajs_per_output, found); 
  get_value_from_node( node, "max-n-steps", max_n_steps, found);

  get_value_from_node( node, "trajectory-file", traj_file_name);

  Str dors;
  get_value_from_node( node, "print-rng-state", dors);
  do_output_rng_state = (dors == Str("yes"));

  for( unsigned int i = 0; i < mthreads.size(); i++){
    Molecule_Pair_State* new_state = new Molecule_Pair_State;
    states.insert( new_state);
  }
    
  typedef std::set< Molecule_Pair_State*>::iterator Itr;
  size_type i = 0;
  for (Itr itr = states.begin(); itr != states.end(); ++itr){
    Molecule_Pair pair( common, mthreads[i], **itr);
    pair.number = i;
    pairs.push_back( pair);
    ++i;
  }

  multi_mover.set_number_of_threads( mthreads.size());

  multi_mover.set_objects( this);

  pthread_mutex_init( &mutex, NULL);
}

NAM_Simulator::~NAM_Simulator(){
  pthread_mutex_destroy( &mutex);
}
