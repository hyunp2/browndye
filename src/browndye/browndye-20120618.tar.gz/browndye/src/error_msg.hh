/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/

#ifndef __ERROR_MSG_HH__
#define __ERROR_MSG_HH__

/*
Error-handling code.  There are templated and overloaded "error" functions that
take 1 through 5 printable arguments, concatenate them into a message, and
throw an exception. 

*/


#include <stdio.h>
#include <exception>

#include "jam_string.hh"

class Jam_Exception: public std::exception{
public:
  Jam_Exception( const Jam_String::String< char>& msg): message( msg){}

  virtual const char* what() const throw(){
    return message.c_str();
  }

  virtual ~Jam_Exception() throw(){}


private:
  const Jam_String::String< char> message;
};

class Thrower{
public:
  Thrower& operator<<( const char* msg){
    Jam_String::String< char> s( msg);
    message = message + s;
    return *this;
  }

  Thrower& operator<<( double x){
    Jam_String::String< char> s = float_string( x);
    message = message + s;
    return *this;
  }


  void execute(){
    fprintf( stderr, "%s\n", message.c_str());
    throw Jam_Exception( message);
  }

  Thrower(): message(""){}


private:
  Jam_String::String< char> message;


  static
  Jam_String::String< char> float_string( double x){
    char number[21];
    snprintf( number, 20, "%g", x);
    return Jam_String::String< char>( number);
  }

};

template< class T0>
void error( const T0& s0){
  Thrower th;
  th << s0;
  th.execute();
}

template< class T0, class T1>
void error( const T0& s0, const T1& s1){
  Thrower th;
  th << s0 << s1;
  th.execute();
}

template< class T0, class T1, class T2>
void error( const T0& s0, const T1& s1, const T2& s2){
  Thrower th;
  th << s0 << s1 << s2;
  th.execute();
}

template< class T0, class T1, class T2, class T3>
void error( const T0& s0, const T1& s1, const T2& s2, const T3& s3){
  Thrower th;
  th << s0 << s1 << s2 << s3;
  th.execute();
}

template< class T0, class T1, class T2, class T3, class T4>
void error( const T0& s0, const T1& s1, const T2& s2, const T3& s3,
	    const T4& s4){
  Thrower th;
  th << s0 << s1 << s2 << s3 << s4;
  th.execute();
}

template< class T0, class T1, class T2, class T3, class T4, class T5>
void error( const T0& s0, const T1& s1, const T2& s2, const T3& s3,
	    const T4& s4, const T5& s5){
  Thrower th;
  th << s0 << s1 << s2 << s3 << s4 << s5;
  th.execute();
}




#endif

