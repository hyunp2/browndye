#ifndef __ATTR_HH__
#define __ATTR_HH__

/*
Defines class Attr for containing the attributes of an XML element.
*/

#include "str.hh"

namespace JAM_XML_Parser{

template< class Key, class Value>
class Dict: public std::map< Key, Value>{
public:

  Value* value( const Key& key) const{
    typename std::map< Key, Value>::const_iterator itr = find( key);
    if (!(itr == this->end()))
      return &((*itr).second);
    else
      return false;
  }
 
private:
  Value& operator[]( const Key& key){
    return this->operator[]( key);
  }
}; 

class Attrs: public JAM_XML_Parser::Dict< String, const String>{
public:
  typedef JAM_XML_Parser::Dict< String, const String> Super;

  const char* value( const char* key) const{
    String skey( key);
    const String* svalue = Super::value( skey);
    if (svalue == NULL)
      return NULL;
    else
      return svalue->c_str();
  }

};
}

#endif
