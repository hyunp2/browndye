#ifndef __STR_HH__
#define __STR_HH__

// Simple typedef for XML parsers

#include <expat.h>
#include "jam_string.hh"

namespace JAM_XML_Parser{
  typedef Jam_String::String< XML_Char> String;
}

#endif
