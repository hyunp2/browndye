/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/

#ifndef __FIELD_HH__
#define __FIELD_HH__


/*
The Field class contains nested grids (Single_Grid::Grid) 
and the multipole field (Multipole_Field::Field) beyond the outermost
grid. It is initialized with the names of the data files, and is
used to get the potential and its gradient at a point.

It is templated with a user-defined Interface class, which has
the following: Potential, Charge, Permittivity, Potential_Gradient

This allows it to be used for the desolvation fields as well as
electric fields.

*/

#include <algorithm>
#include "error_msg.hh"
#include "single_grid.hh"
#include <iostream>
#include "multipole_field.hh"

namespace Field{

template< class Interface>
class Field{
public:
  typedef typename Interface::Potential Potential;
  typedef typename Interface::Charge Charge;
  typedef typename Interface::Permittivity Permittivity;
  typedef typename Interface::Potential_Gradient Potential_Gradient;

  Field();
  ~Field();

  // Names of files. "sfiles" go from outer to inner.
  void initialize( const char* mpole, const Vector< const char*>& sfiles);

  // with no multipole field
  void initialize( const Vector< const char*>& sfiles);

  void get_gradient( const Vec3< Length>& pos, 
		     Vec3< Potential_Gradient>& f) const;
  Potential potential( const Vec3< Length>& pos) const;

  Length debye_length() const;
  Permittivity vacuum_permittivity() const;
  double solvent_dielectric() const;
  Charge charge() const;

  void shift_position( const Vec3< Length>&);

  bool has_solvent_info() const;

private:
  typedef Single_Grid::Grid< Potential> SGrid;
  typedef Multipole_Field::Field MField;

  MField* mfield;
  // stored inside to out
  Vector< Single_Grid::Grid< Potential>*> sfields;
};

}

#include "field_impl.hh"

#endif
