/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/


#ifndef __LMZ_PROPAGATOR_HH__
#define __LMZ_PROPAGATOR_HH__

/*
Used to propagate the molecules in the region outside the b-sphere.
The Propagator object is initialized from the data output by the Ocaml program 
"sphere_return_distribution" 
(see notes in ../aux/sphere_return_distribution.ml)

The arguments to the "propagate" function are as follows:
Inputs:
rng - random number generator
r0b, rot0b - position and rotational state of Molecule 0 at beginning
r1b, rot1b - position and rotational state of Molecule 1 at beginning

Outputs:
escaped - "true" if escaped
rot0 - rotational state of Molecule 0 at end (position stays the same)
r1, rot1 position and rotational state of Molecule 1 at end
t - elapsed time
*/

#include "lmz_propagator_pre.hh"

namespace LMZ{

class Propagator{
public:
  void initialize( JP::Node* node);
  
  void propagate( Browndye_RNG& rng, 
		  const Vec3< Length>& r0b, const Mat3< double>& rot0b,
		  const Vec3< Length>& r1b, const Mat3< double>& rot1b,
		  bool& escaped, Mat3< double>& rot0, 
		  Vec3< Length>& r1, Mat3< double>& rot1, 
		  Time& t) const; 

private:
  typedef Vector< Shell_Distribution>::size_type size_type;

  Vector< Shell_Distribution> shell_dists;
  double outer_prob_return;
  Inv_Time rdiff0, rdiff1;
  Length inner_radius;
};

}

#endif
