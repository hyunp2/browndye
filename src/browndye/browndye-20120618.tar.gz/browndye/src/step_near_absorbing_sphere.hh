/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/


/* Resolves motion of particle moving near inner surface of an absorbing
sphere under a radial force.  Computes 1) whether particle is absorbed in
next time step, and 2) if not, its new radial position.

Assume that units are chosen so that radial diffusivity, radius, and kT are 
unity.

Interface:

typedef ... RNG
double gaussian( RNG&) - gaussian with zero mean and unit variance
double uniform( RNG&) - uniform between 0 and 1

*/

#ifndef __STEP_NEAR_ABSORBING_SPHERE_HH__
#define __STEP_NEAR_ABSORBING_SPHERE_HH__

#include <math.h>

template< class Interface>
void step_near_absorbing_sphere( typename Interface::RNG& rng,
				 double r, double F, double t,
				 bool& survives, double& new_r){

  double b = F + 2/r;
  
  double dr = Interface::gaussian( rng)*sqrt( 2*t) + b*t;
  new_r = r + dr;
  if (new_r > 1.0){
    survives = false;
  }
  else{
    double absorb_prob = exp(-(1.0 - r)*(1.0 - new_r)/t);
    survives = !(Interface::uniform( rng) < absorb_prob);
  }
}

#endif
