/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/

/*
Reference-counted "smart pointer".  Maintains a count of
references, and deletes the object when the last reference 
is freed.
*/

#ifndef __RC_PTR_HH__
#define __RC_PTR_HH__

template< class T>
class Inner{
public:
  Inner( T* obj){
    count = 1;
    ptr = obj;
  }

  ~Inner(){
    delete ptr;
  }

  T* ptr;
  unsigned int count;
};


template< class T>
class RC_Ptr{
public:
  RC_Ptr(){
    inner = NULL;
  }

  explicit RC_Ptr( T* obj){
    inner = new Inner<T>( obj);
  }

  ~RC_Ptr(){
    release();
  }

  T& operator*(){
    if (inner == NULL)
      error( "RC_Ptr*: not pointing to an object");

    return *(inner->ptr);    
  }

  T* operator->(){
    if (inner == NULL)
      return NULL;
    else
      return inner->ptr;    
  }
    
  const T& operator*() const{
    if (inner == NULL)
      error( "RC_Ptr*: not pointing to an object");

    return *(inner->ptr);
  }

  const T* operator->() const{
    if (inner == NULL)
      return NULL;
    else
      return inner.ptr;
  }
    
  RC_Ptr( const RC_Ptr<T>& other){
    inner = other.inner;
    ++(inner->count);
  }

  RC_Ptr<T>& operator=( const RC_Ptr<T>& other){    
    if (other.inner != inner)
      release();

    inner = other.inner;
    if (inner != NULL)
      ++(inner->count);
  
    return *this;
  }

  T* get(){
    if (inner == NULL)
      return NULL;
    else
      return inner->ptr;
  }

  const T* get() const{
    if (inner == NULL)
      error( "RC_Ptr*: not pointing to an object");

    return inner->ptr;
  }

  void reset( T* obj){
    release();
    inner = new Inner<T>( obj);
  }

private:

  void release(){
    if (inner != NULL){
      --(inner->count);
      if (inner->count == 0){
	delete inner;
	inner = NULL;
      }
    }        
  }

  Inner<T>* inner;
};

#endif




