/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/


#ifndef __JAM_STRING_HH__
#define __JAM_STRING_HH__

/*
class Jam_String::String, templated by character type, is
a reference-counted string data structure. It can be 
passed around and copied without worrying about managing memory.

*/

#include <stdlib.h>
#include <string.h>

template< class T>
class Vector;

template< class T0>
void error( const T0& s0);

namespace Jam_String{

template< class C>
class Inner_String;

template< class Char>
class String{

public:
  String();
  explicit String( const Char*);
  String( const Char*, size_t);
  String( const String&);
  String( const Vector< Char>&);

  String& operator=( const String&);
  bool operator==( const String&) const;
  bool operator<( const String&) const;
  String operator+( const String&) const;
  ~String();
  const Char* c_str() const;
  size_t size() const;

  void copy_from( const Char*);

  bool has_value() const;

private:
  Inner_String< Char>* inner;

  void free_inner();
  String( Char*, bool);

};

  // has actual data and reference count. Several String's can
  // point to an Inner_String.
template< class Char>
class Inner_String{
public:
  Char* data;
  unsigned int n; // not really used, but there for debugging
  size_t ref_count;

  Inner_String( const Char*);
  Inner_String( const Char*, size_t);
  Inner_String( const Vector< Char>&);
  ~Inner_String();

private:
  Inner_String(){}

};

template< class Char>
void String< Char>::copy_from( const Char* chars){
  if (inner != NULL)
    free_inner();
  inner = new Inner_String< Char>( chars);
}

template< class Char>
Inner_String< Char>::~Inner_String(){
  if (data != NULL)
    delete [] data;
}

template< class Char>
Inner_String< Char>::Inner_String( const Char* _data){
  n = strlen( _data);
  data = new Char [n+1];
  strcpy( data, _data);
  ref_count = 1;
}


template< class Char>
Inner_String< Char>::Inner_String( const Char* _data, size_t _n){
  n = _n;
  data = new Char [n+1];
  strncpy( data, _data, n);
  data[n] = (Char)0;
  ref_count = 1;
}

template< class Char>
Inner_String< Char>::Inner_String( const Vector< Char>& _data){
  n = _data.size();
  data = new Char [n+1];
  for( unsigned int i = 0; i < n; i++)
    data[i] = _data[i];

  data[n] = (Char)0;
  ref_count = 1;  
}

  // When the last link is gone, free it up
template< class Char>
void String< Char>::free_inner(){
  if (inner != NULL){
    --(inner->ref_count);
    if (inner->ref_count == 0){
      delete inner;
      inner = NULL;
    }
  }
}

template< class Char>
const Char* String< Char>::c_str() const{
  if (inner == NULL)
    return NULL;
  else
    return inner->data;
}

  // constructor
template< class Char>
String< Char>::String( const Char* chars){
  inner = new Inner_String< Char>( chars);
}  

  // constructor
template< class Char>
String< Char>::String( const Vector< Char>& chars){
  inner = new Inner_String< Char>( chars);
}  

  // constructor
template< class Char>
String< Char>::String(){
  inner = NULL;
}  

  // constructor
template< class Char>
String< Char>::String( const Char* chars, size_t n){
  inner = new Inner_String< Char>( chars, n);
}  

  // constructor
template< class Char>
String< Char>::String( const String& str){
  if (str.inner != NULL){
    inner = str.inner;
    ++(inner->ref_count);
  }
  else
    inner = NULL;
}

template< class Char>
String< Char>& String< Char>::operator=( const String& str){
  if (str.inner == NULL){
    free_inner();
    inner = NULL;
  }
  else {
    if (inner != str.inner){
      free_inner();
      inner = str.inner;
      ++(inner->ref_count);
    }
  }
  return *this;
}

template< class Char>
String< Char> String< Char>::operator+( const String& str) const{

  if (this->inner == NULL)
    return String< Char>( str);
  else if (str.inner == NULL)
    return String< Char>( *this);
  else {
    size_t n0 = strlen( this->inner->data);
    size_t n1 = strlen( str.inner->data);
    Char* cdata = new Char [ n0 + n1 + 1];
    strcpy( cdata, this->inner->data);
    strcat( cdata, str.inner->data);
    String< Char> new_str( cdata);
    delete [] cdata;
    return new_str;
  }
}


template< class Char>
String< Char>::~String(){
  free_inner();
}

template< class Char>
size_t String< Char>::size() const{
  if (inner == NULL)
    return 0;
  else
    return strlen( inner->data);
}

template< class Char>
bool String< Char>::operator==( const String< Char>& str) const{
  if (this->inner != NULL){
    if (str.inner != NULL){
      int res = strcmp( this->inner->data, str.inner->data);
      return (res == 0);
    }
    else
      return false;
  }
  else
    return (str.inner == NULL);
}

template< class Char>
bool String< Char>::operator<( const String< Char>& str) const{
  if ((this->inner == NULL) || (str.inner == NULL))
    error( "string operator <: one of the strings is not assigned");

  int res = strcmp( this->inner->data, str.inner->data);
  return (res < 0); 
}

template< class Char>
bool String< Char>::has_value() const{
  return (inner != NULL);
}

}  
  
#endif

