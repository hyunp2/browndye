/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/

/*
Included by "molecule_pair.hh"
Defines interface classes for "wiener.hh" and "pathways.cc"
 */

#include "molecule.hh"
#include "pathways.hh"
#include "two_sphere_brownian.hh"
#include "wiener.hh"
#include "browndye_rng.hh"
#include "parameter_info.hh"
#include "lmz_propagator.hh"

//**************************************************************
// Interface for wiener.hh

class Wiener_Interface{
public:
  typedef ::Time Time;
  typedef ::Sqrt_Time Sqrt_Time;

  typedef Sqrt_Time Vector12[12];
  typedef Vector12 Vector;
  typedef Browndye_RNG* Gaussian;
  
  static
  void initialize( Vector12&, unsigned int n){}

  static 
  void copy( const Vector12& a, Vector12& b){
    for( unsigned int i=0; i<12; i++)
      b[i] = a[i];
  }

  static 
  void set_difference( const Vector12& a, const Vector12& b, Vector12& c){
    for( unsigned int i=0; i<12; i++)
      c[i] = a[i] - b[i];
  }

  static 
  void set_half( const Vector12& a, Vector12& b){
    for( unsigned int i=0; i<12; i++)
      b[i] = 0.5*a[i];
  }

  static 
  void set_mean( const Vector12& a, const Vector12& b, Vector12& c){
    for( unsigned int i=0; i<12; i++)
      c[i] = 0.5*( a[i] + b[i]);
  }

  static 
  void set_gaussian( Gaussian& gaussian, Sqrt_Time sdev, Vector12& w){
    for( unsigned int i=0; i<12; i++)
      w[i] = sdev*gaussian->gaussian();
  }

  static 
  void add_gaussian( Gaussian& gaussian, Sqrt_Time sdev, Vector12& w){
    for( unsigned int i=0; i<12; i++)
      w[i] += sdev*gaussian->gaussian();
  }

  static
  void set_null( Gaussian& gptr){
    gptr = NULL;
  }

};

//***************************************************
// Interface for "pathways.hh"

class Molecule_Pair;

class Rxn_Interface{
public:
  typedef const ::Molecule_Pair Molecule_Pair;
  typedef Vector< int>::size_type size_type;

  static 
  Length distance( Molecule_Pair& mpair, size_type i0, size_type i1);

};
