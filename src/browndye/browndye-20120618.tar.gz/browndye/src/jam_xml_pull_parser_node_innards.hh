/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/

/*
Private portion of JAM_XML_Pull_Parser::Node class; included by
"jam_xml_pull_parser.hh"

 */

  friend 
  void begin_tag( State&, const char*, const JP::Attrs&);

  friend 
  void end_tag( State&, const char*, JP::Str_Stream&);

  friend
  class Parser;

  String ttag;
  JP::Attrs attrs;

  mutable RC_Ptr< JP::Str_Stream> strm;

  std::multimap< String, RC_Ptr< Node> > children;
  std::queue< RC_Ptr< Node> > child_nodes;
  Node* parent;
  bool completed;
  bool merged;
  bool traversed;

  typedef std::multimap< String, RC_Ptr< Node> >::iterator Miterator;
