/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/

// Interface class to Gaussian_Generator to make the Browndye_RNG class


#ifndef __BROWNDYE_RNG_HH__
#define __BROWNDYE_RNG_HH__

#include "mersenne.hh"
#include "gaussian.hh"


class Browndye_Gaussian_Interface{
public:
  typedef uint32_t seed_type;
  typedef Mersenne::State State;
  typedef Mersenne::Generator RNG;
  
  static
  double uniform( RNG& rng){
    return rng.genrand_real3();
  }

  static
  void set_seed( RNG& rng, seed_type seed){
    rng.init_genrand( seed);
  }

  static
  void copy_rng_to( const RNG& in, RNG& out){
    out = in;
  }

  static
  void get_new_rng( RNG&){}

  static
  void delete_rng( RNG&){}

  static
  void set_state( RNG& rng, const State& state){
    rng.set_state( state);
  }

  static
  void get_state( const RNG& rng, State& state){
    rng.get_state( state);
  }
  
};

typedef Gaussian_Generator< Browndye_Gaussian_Interface> Browndye_RNG;

#endif
