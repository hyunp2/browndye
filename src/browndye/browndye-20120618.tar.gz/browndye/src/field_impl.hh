/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/

// Implementation of the Field class

#include "field.hh"
#include "error_msg.hh"
#include "jam_xml_pull_parser.hh"

namespace Field{

namespace JP = JAM_XML_Pull_Parser;

  //**************************************************************
/*
This class allows the Field< Interface>::potential to be compiled
with UNITS turned on, avoiding a units type clash between the
electrostatic multipole class and the desolvation field.
*/
template< class Potential, class Potential_Gradient>
class Selector{
public:
  static
  Potential potential( const Multipole_Field::Field* mfield,
		      const Vec3< Length>& pos){
    return Potential( 0.0);
  }

  static
  void get_gradient( const Multipole_Field::Field* mfield,
		     const Vec3< Length>& pos,
		     Vec3< Potential_Gradient>& grad){
    grad[0] = grad[1] = grad[2] = Potential_Gradient( 0.0);
  }
};

template<>
class Selector< EPotential, EPotential_Gradient>{
public:
  static
  EPotential potential( const Multipole_Field::Field* mfield,
		       const Vec3< Length>& pos){
    if (mfield != NULL)
      return mfield->potential( pos);
    else
      return EPotential( 0.0);
  }

  static
  void get_gradient( const Multipole_Field::Field* mfield,
		     const Vec3< Length>& pos,
		     Vec3< EPotential_Gradient>& grad){
    if (mfield != NULL)
      mfield->get_gradient( pos, grad);
    else{ // no mpoles
      grad[0] = grad[1] = grad[2] = EPotential_Gradient( 0.0);
    }
  }
};
  //**************************************************************
template< class Interface>
typename Interface::Potential 
Field< Interface>::potential( const Vec3< Length>& pos) const{  
  Potential v;
  bool in_range = false;

  bool in_grid = false;
  for( typename Vector< SGrid*>::const_iterator itr = sfields.begin();
       itr != sfields.end(); ++itr){
    const SGrid* sfield = *itr;
    sfield->get_potential( pos, v, in_range);
    if (in_range){
      in_grid = true;
      break;
    }
  }
  if (in_grid)
    return v;

  return Selector< Potential, Potential_Gradient>::potential( mfield, pos);
}


template< class Interface>
void Field< Interface>::
get_gradient( const Vec3< Length>& pos,
	      Vec3< typename Interface::Potential_Gradient>& grad) const{  

  bool in_range = false;

  bool in_grid = false;
  for( typename Vector< SGrid*>::const_iterator itr = sfields.begin();
       itr != sfields.end(); ++itr){
    const SGrid* sfield = *itr;
    sfield->get_gradient( pos, grad, in_range);

    if (in_range){
      in_grid = true;
      break;
    }
  }

  if (in_grid)
    return;
  else
    Selector< Potential, Potential_Gradient>::get_gradient( mfield, pos, grad);
}

  // destructor
template< class Interface>
Field< Interface>::~Field(){
  if (mfield != NULL)
    delete mfield;

  for( typename Vector< SGrid*>::iterator itr = sfields.begin();
       itr != sfields.end(); ++itr){
    delete (*itr);
  }
}

  // constructor
template< class Interface>
Field< Interface>::Field(){
  mfield = NULL;
}


  // Sorts the electric fields to make sure they are nested correctly
template< class Interface>
class SField_Sorter{
public:
  typedef Single_Grid::Grid< typename Interface::Potential> SField;

  int bracketed( Length l0, Length h0, Length l1, Length h1){
    if (l0 < l1 && h1 < h0)
      return 1;
    else if (l1 < l0 && h0 < h1)
      return 0;
    else
      return -1;	       	      
  }

  // less than operator; the one inside is considered less
  bool operator()( const SField* sf0, const SField* sf1){
    Vec3< Length> c0, h0, c1, h1;
    sf0->get_low_corner( c0);
    sf0->get_high_corner( h0);
    sf1->get_low_corner( c1);
    sf1->get_high_corner( h1);

    int xb = bracketed( c0[0], h0[0], c1[0], h1[0]);
    int yb = bracketed( c0[1], h0[1], c1[1], h1[1]);
    int zb = bracketed( c0[2], h0[2], c1[2], h1[2]);

    if (xb == 0 && yb == 0 && zb == 0){
      return true;
    }
    else if (xb == 1 && yb == 1 && zb == 1){
      return false;
    }
    else {
      error( "Field: component single grids do not nest");
      return false;
    }
  }

};

  // automatically ordered the correct way re nesting
template< class Interface>
void Field< Interface>::initialize( const Vector< const char*>& files){
  typedef Vector< const char*>::size_type size_type;

  if (files.size() == 0)
    error( "no files for electric field");

  for( size_type i = 0; i < files.size(); ++i)
    fprintf( stderr, "Field::initialize %s\n", files[i]); fflush( stderr);

  size_type nf = files.size();
  sfields.resize( nf);
  for( size_type i = 0; i<nf; i++){
    const char* file = files[i];
    SGrid* grid = new SGrid( file);
    sfields[ nf-i-1] = grid; 
  }

  std::cout << "n fields " << sfields.size() << "\n";
  SField_Sorter< Interface> sfs;
  std::sort( sfields.begin(), sfields.end(), sfs);

}

template< class Interface>
void Field< Interface>::initialize( const char* mpole, 
				     const Vector< const char*>& files){
  
  fprintf( stderr, "Field::initialize mf %s\n", files[0]); fflush( stderr);

  mfield = new MField( mpole);
  initialize( files);
}

template< class Interface>
Length Field< Interface>::debye_length() const{
  if (mfield == NULL)
    error( "Field::debye_length: need multipole for this");

  return mfield->debye_length();
}

template< class Interface>
bool Field< Interface>::has_solvent_info() const {
  return (mfield != NULL);
}

template< class Interface>
double Field< Interface>::solvent_dielectric() const{
  if (mfield == NULL)
    error( "Field::solvent_dielectric: need multipole for this");

  return mfield->solvent_dielectric();
}

template< class Interface>
typename Interface::Permittivity 
Field< Interface>::vacuum_permittivity() const{
  if (mfield == NULL)
    error( "Field::vacuum_permittivity: need multipole for this");

  return mfield->vacuum_permittivity();
}

template< class Interface>
typename Interface::Charge 
Field< Interface>::charge() const{

  const double pi = 3.1415926;
  return mfield->eff_charge()*4.0*pi*vacuum_permittivity()*solvent_dielectric();
}

template< class Interface>
void Field< Interface>::shift_position( const Vec3< Length>& offset){

  if (mfield != NULL)
    mfield->shift_position( offset);

  for( typename Vector< SGrid*>::iterator itr = sfields.begin(); 
       itr != sfields.end(); ++itr)
    (*itr)->shift_position( offset);

}
}
