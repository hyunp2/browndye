/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/

// Implementation of "node_info" functions

#include "node_info.hh"

namespace JP = JAM_XML_Pull_Parser;
typedef Jam_String::String< char> String;

template< class Value>
void get_checked_value_from_node( JP::Node* node, 
				  const char* tag, Value& value){
  JP::Node* cnode = node->child( tag);
  
  if (cnode == NULL)
    error( "get_value_from_node: tag ", tag, " not found"); 

  JP::Str_Stream& stm = cnode->stream();
  stm >> value;
  if (stm.fail())
    error( "get_value_from_node: nothing found in ", tag, " tag");
}

double double_from_node( JP::Node* node, const char* tag){
  double res = NAN;
  get_double_from_node( node, tag, res);
  return res;
}

double double_from_node( JP::Node* node){
  double res = NAN;
  get_double_from_node( node, res);
  return res;
}

int int_from_node( JP::Node* node, const char* tag){
  int res;
  get_checked_value_from_node( node, tag, res);
  return res;
}

int int_from_node( JP::Node* node){
  int res;
  get_value_from_node( node, res);
  return res;
}

String string_from_node( JP::Node* node, const char* tag){
  String res;
  get_checked_value_from_node( node, tag, res);
  return res;
}

String string_from_node( JP::Node* node){
  String res;
  get_value_from_node( node, res);
  return res;
}

JAM_XML_Pull_Parser::Node* checked_child( JAM_XML_Pull_Parser::Node* node, 
					  const char* tag){

  JP::Node* res = node->child( tag);
  if (res == NULL)
    error( "node of ", tag, " not found");
  
  return res;
}

