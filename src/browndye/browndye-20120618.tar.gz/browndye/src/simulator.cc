/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/

/*
Implementation of Simulator.
*/

#include <time.h>
#include "simulator.hh"
#include "node_info.hh"

void Simulator::begin_output( std::ofstream& outp){
  
  outp << "<rates>\n";

  outp << "  <solvent>\n";
  outtag( outp, "debye-length", common.debye_length);
  outtag( outp, "dielectric", common.dielectric);
  outtag( outp, "vacuum-permittivity", common.vacuum_permittivity);
  outtag( outp, "water-viscosity", common.water_viscosity);
  outtag( outp, "relative-viscosity", common.relative_viscosity);
  outp << "  </solvent>\n";

  outp << "  <molecule-info>\n";

  outtag( outp,"charge-molecule0", common.mol0.charge());
  outtag( outp,"charge-molecule1", common.mol1.charge());
  
  outtag( outp,"b-radius", common.b_radius);
  outtag( outp,"radius-molecule0", common.mol0.hydro_radius());
  outtag( outp,"radius-molecule1", common.mol1.hydro_radius());

  outp << "    <hydrodynamic-interactions> ";
  if (common.no_hi)
    outp << "false";
  else
    outp << "true";
  outp << "   </hydrodynamic-interactions>\n";
  outp << "  </molecule-info>\n";  

  // make more modular
  outp << "  <time-step-tolerances>\n";
  outtag( outp,"minimum-dt", common.minimum_dt(), 4);
  outtag( outp, "minimum-dx", common.dx_min, 4);
  outtag( outp, "force", common.ftol, 4);
  outtag( outp, "reaction", common.rtol, 4);
  outtag( outp, "collision", common.gtol, 4);
  outp << "  </time-step-tolerances>\n";

  const size_type nrxns = common.n_reactions();
  outtag( outp,"n-reactions", nrxns);
}

// constructor
Simulator::Simulator(){
  vacuum_permittivity = Permittivity( 0.000142);
  solvent_dielectric = NAN;
  debye_length = Length( INFINITY);
};


// destructor
Simulator::~Simulator(){
  /*
  if (output != NULL)
    delete output;
  */

  typedef std::set< Molecule_Pair_State*>::iterator Itr;
  for (Itr itr = states.begin(); itr != states.end(); ++itr)
    delete (*itr);
}


// make sure mthreads are allocated first
void Simulator::initialize_rngs( uint32_t seed){
  size_type n = mthreads.size();

  Vector< Mersenne::Generator*> rngs( n);

  for( size_type i=0; i<n; i++)
    rngs[i] = &(mthreads[i].rng.base_rng());

  Mersenne::init_genrands( seed, rngs);
}

typedef Jam_String::String< char> String;
namespace JP = JAM_XML_Pull_Parser;

template< class U>
void get_unit_from_node( JP::Node* node, const char* tag, U& value, bool& found){
  double fval;
  get_value_from_node( node, tag, fval, found);
  if (found)
    set_fvalue( value, fval);
}

JAM_XML_Pull_Parser::Node* Simulator::initialized_node( JP::Parser& parser){

  parser.complete_current_node();
  Node* node = parser.current_node();

  bool tfound;
  size_type nthreads;
  get_value_from_node( node, "n-threads", nthreads, tfound);
  if (!tfound)
    nthreads = 1;

  mthreads.resize( nthreads);

  bool sfound;
  uint32_t seed;
  get_value_from_node( node, "seed", seed, sfound);

  if (sfound){
      initialize_rngs( seed);
  }
  else{
      initialize_rngs( clock());
  }

  Node* mp_node = checked_child( node, "molecule-pair");

  String solvent_file; 
  get_value_from_node( node, "solvent-file", solvent_file);

  common.initialize( mp_node, solvent_file.c_str());


  std::cout << "n-threads " << nthreads << "\n";
  printf( "initialize mthreads\n");
  for( size_type i = 0; i < nthreads; i++){
    mthreads[i].initialize( common, mp_node);
    mthreads[i].n = i;
  }
  printf( "end initialize mthreads\n");

  output_name = string_from_node( node, "output");

  renormalize_reactions();
  return node;
}

void psp( std::ofstream& out, unsigned int n){
  for( unsigned int i = 0; i < n; i++)
    out << " ";
}

template< class Atom>
const Vector<  Vector< int>::size_type > atom_indices( const Vector< Atom>& atoms){
  typedef Vector< int>::size_type size_type;
  size_type n = atoms.size();
  Vector< size_type> indices( n);
  for( size_type i = 0; i < n; i++)
    indices[i] = atoms[i].number;
  return indices;
}

// necessary to renumber atoms because only surface atoms are included.
void Simulator::renormalize_reactions(){
  const Vector< Atom_Large>& atoms0 = common.mol0.atoms;
  const Vector< size_type> indices0 = atom_indices( atoms0);

  const Vector< Atom_Small>& atoms1 = mthreads[0].mol1.atoms;
  const Vector< size_type> indices1 = atom_indices( atoms1);
  
  common.pathway->remap_molecule0( indices0);
  common.pathway->remap_molecule1( indices1);
}
