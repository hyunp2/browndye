/* Copyright (c) 2008 Gary A. Huber, Howard Hughes Medical Institute 
   See the file COPYRIGHT for copying permission
*/

#ifndef __WIENER_HH__
#define __WIENER_HH__


/*
The Wiener::Process class implements the back-stepping Wiener process
as described in the paper.

The Interface class has the following types and static functions:

Vector
Gaussian - must have = operator defined
Time
Sqrt_Time

void copy( const Vector&, Vector&);
void set_mean( const Vector&, const Vector&, Vector&);
void set_half( const Vector&, Vector&);
void set_difference( const Vector&, const Vector&, Vector&);
void set_gaussian( Gaussian&, const Sqrt_Time& scale, Vector&);
void add_gaussian( Gaussian&, const Sqrt_Time& scale, Vector&);
void initialize( Vector&, unsigned int n);
void set_null( Gaussian&); 

 */

#include "wiener_pre.hh"

namespace Wiener{

template< class Interface>
class Process{
public:
  typedef typename Interface::Vector Vector;
  typedef typename Interface::Gaussian Gaussian;
  typedef typename Interface::Time Time;
  typedef typename Interface::Sqrt_Time Sqrt_Time;

  void backstep();
  void step_forward( Time dt);
  
  Time time_step() const;
  Time time() const;
  
  bool in_chain() const;
  
  const Vector& dW() const;
  
  void set_dim( unsigned int);
  void set_gaussian_generator( Gaussian);

  Process();
  Process( const Process< Interface>&);
  Process< Interface>& operator=( const Process< Interface>&);

  ~Process();

  //**********************************
private: 

  static
  void set_mean( const Vector& w0, const Vector& w1, Vector& wh){
    Interface::set_mean( w0, w1, wh);
  }
  
  static
  void set_difference( const Vector& w0, const Vector& w1, 
		       Vector& dw){
    Interface::set_difference( w0, w1, dw);
  }
  
  static
  void add_gaussian( Gaussian& gaussian, Sqrt_Time a, Vector& w){
    Interface::add_gaussian( gaussian, a, w);
  }

  static
  void set_gaussian( Gaussian& gaussian, Sqrt_Time a, Vector& w){
    Interface::set_gaussian( gaussian, a, w);
  }
  
  static
  void initialize( Vector& w, unsigned int n){
    Interface::initialize( w, n);
  }

  static
  void copy( const Vector& w0, Vector& w1){
    Interface::copy( w0, w1);
  }

  static
  void set_half( const Vector& w0, Vector& w1){
    Interface::set_half( w0, w1);
  }


  //**************************
  void copy_to_new_owner( const Process& other);
  void clear();

  Gaussian gaussian;

  W_Info< Interface>* prev;
  W_Info< Interface>* current;
  Vector* dw;
  Vector dw0;

  std::list< W_Info< Interface>* > ws;
  unsigned int dim;
  Time prev_dt;

};

  // constructor
template< class Interface>
Process< Interface>::Process(){
  prev = NULL;
  current = new W_Info< Interface>;
  current->t = Time( 0.0);
  dw = &(current->w);
  dim = 1;
  Interface::set_null( gaussian);
  prev_dt = Time( NAN);
}

template< class Interface>
void Process< Interface>::copy_to_new_owner( const Process& other){

  dim = other.dim;
  gaussian = other.gaussian;
  prev_dt = other.prev_dt;
  initialize( dw0, dim);

  typedef typename std::list< W_Info< Interface>*>::const_iterator CItr;
  typedef typename std::list< W_Info< Interface>*>::iterator Itr;

  for( CItr itr = other.ws.begin(); itr != other.ws.end(); ++itr){
    W_Info< Interface>* info = new W_Info< Interface>( **itr);
    ws.push_back( info);
  }

  current = new W_Info< Interface>( *(other.current));

  if (other.prev == NULL)
    prev = NULL;
  else{
    prev = new W_Info< Interface>( *(other.prev));
  }

  if (other.dw == &(other.dw0)){
    copy( other.dw0, dw0);
    dw = &dw0;    
  }
  else{
    dw = &(current->w);
  }  
}

  // not suitable if both old and new processes are still to be used
  // copy constructor
template< class Interface>
Process< Interface>::Process( const Process& other){
  copy_to_new_owner( other);
}

template< class Interface>
void Process< Interface>::clear(){
  if (prev != NULL)
    delete prev;
  
  delete current;
  
  while (!ws.empty()){
    current = ws.back();
    ws.pop_back();
    delete current;
  }
  
#ifdef DEBUG
  current = NULL;
  prev = NULL;
#endif
}

template< class Interface>
Process< Interface>& Process< Interface>::operator=( const Process& other){
  if (&other != this){
    clear();
    copy_to_new_owner( other);
  }
  return *this;
}

  // destructor
template< class Interface>
Process< Interface>::~Process(){
  clear();
}
  
template< class Interface>
void Process< Interface>::backstep(){
  ws.push_back( current);
  W_Info< Interface>* mid = new W_Info< Interface>;
  initialize( mid->w, dim);

  if (prev != NULL){
    Sqrt_Time s = sqrt( 0.5*prev->dt);
    prev->dt /= 2;
    mid->dt = prev->dt;
    mid->t = prev->t + mid->dt;
    set_mean( prev->w, current->w, mid->w);

    add_gaussian( gaussian, s, mid->w);
    set_difference( mid->w, prev->w, *dw);
    current = mid;
  }

  else{
    Sqrt_Time s = sqrt( 0.5*prev_dt);
    prev_dt /= 2;
    mid->dt = prev_dt;
    mid->t = current->t - prev_dt;
    set_half( current->w, mid->w);
    add_gaussian( gaussian, s, mid->w);
    dw = &dw0;
    copy( mid->w, *dw);
    current = mid;
  }
}


template< class Interface>
void Process< Interface>::step_forward( Time dt){
  if (ws.empty()){ 
    if (prev != NULL){ // at end of chain
      prev_dt = dt;
      delete prev;
      prev = NULL;
      dw = &(current->w);
    }
    else // most common case
      prev_dt = dt;
    
#ifdef DEBUG
    current->dt = Time( NAN);
#endif

    current->t += dt;
    set_gaussian( gaussian, sqrt( 2.0*dt), current->w);
  }

  else{ // in chain
    delete prev;
    prev = current;
    current = ws.back();
    ws.pop_back();
    set_difference( current->w, prev->w, *dw);
  }
}


template< class Interface>
void Process< Interface>::set_dim( unsigned int _dim){
  dim = _dim;
}

template< class Interface>
void Process< Interface>::
set_gaussian_generator( typename Interface::Gaussian g){
  gaussian = g;
}

template< class Interface>
typename Interface::Time Process< Interface>::time_step() const{
  if (prev == NULL)
    return prev_dt;
  else
    return prev->dt;
}

template< class Interface>
typename Interface::Time Process< Interface>::time() const{
  return current->t;
}

template< class Interface>
bool Process< Interface>::in_chain() const{
  return (prev != NULL);
}

template< class Interface>
const typename Interface::Vector& 
Process< Interface>::dW() const{
  if (prev == NULL)
    return current->w;
  else
    return *dw;
}

}

#endif
